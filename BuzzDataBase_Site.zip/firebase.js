import { initializeApp } from "https://www.gstatic.com/firebasejs/13.1.0/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  writeBatch,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCwZ7b0jcJbkPr-ZITmuLNOw3CgNYqV7-4",
  authDomain: "buzzdatabase0.firebaseapp.com",
  projectId: "buzzdatabase0",
  storageBucket: "buzzdatabase0.firebasestorage.app",
  messagingSenderId: "960232212219",
  appId: "1:960232212219:web:a7309f66eb1daa4bbe125e",
  measurementId: "G-Z6VDBNRKF4"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const provider = new GoogleAuthProvider();
provider.setCustomParameters({ prompt: "select_account" });

// Mantém o login no aparelho até o usuário tocar em Sair.
const persistenceReady = setPersistence(auth, browserLocalPersistence).catch(error => {
  console.warn("BuzzDataBase: não foi possível definir persistência local do login.", error);
  return false;
});

let currentUser = null;
let authCallback = null;
let authInitialized = false;
let pendingSync = null;
let syncRunning = false;
let syncPromise = null;

function metaRef(uid) { return doc(db, "users", uid); }
function itemsRef(uid) { return collection(db, "users", uid, "items"); }

function safeItem(item) {
  const image = typeof item.image === "string" ? item.image : "";
  return {
    id: String(item.id ?? ""),
    title: String(item.title || ""),
    section: String(item.section || ""),
    rating: Number.isFinite(Number(item.rating)) ? Math.max(0, Math.min(10, Math.round(Number(item.rating)))) : 0,
    createdAt: Number.isFinite(Number(item.createdAt)) ? Number(item.createdAt) : Date.now(),
    // Todas as capas do backup atual cabem abaixo deste limite por documento.
    image: image.length <= 850000 ? image : ""
  };
}

function explainFirebaseError(error) {
  const code = String(error?.code || "");
  if (code.includes("permission-denied")) return "O Firestore recusou o acesso. Confira se publicou as regras de segurança para users/{uid}.";
  if (code.includes("unauthorized-domain")) return "O domínio lobopidaokk.github.io não está autorizado no Firebase Authentication.";
  if (code.includes("operation-not-allowed")) return "O provedor Google não está ativado no Firebase Authentication.";
  if (code.includes("unavailable") || code.includes("network-request-failed")) return "Sem conexão com o Firebase. Seus dados locais continuam disponíveis; a nuvem será tentada novamente.";
  if (code.includes("failed-precondition")) return "O Firestore não está pronto. Confira se o banco foi criado no projeto buzzdatabase0.";
  if (code.includes("resource-exhausted")) return "O limite de uso do Firestore foi atingido. Seus dados locais continuam preservados.";
  return error?.message ? `Falha na sincronização: ${error.message}` : "Não foi possível sincronizar com o Firebase.";
}

async function writeCloudSnapshot(job) {
  const uid = job.uid;
  const ref = itemsRef(uid);
  const existing = await getDocs(ref);
  const wanted = new Map((job.state.items || []).map(item => [String(item.id), safeItem(item)]));
  let operations = [];

  const flush = async () => {
    if (!operations.length) return;
    const batch = writeBatch(db);
    for (const operation of operations) {
      if (operation.type === "set") batch.set(operation.ref, operation.data);
      else batch.delete(operation.ref);
    }
    await batch.commit();
    operations = [];
  };

  for (const [id, item] of wanted) {
    operations.push({ type: "set", ref: doc(ref, id), data: item });
    if (operations.length >= 400) await flush();
  }
  for (const oldDoc of existing.docs) {
    if (!wanted.has(oldDoc.id)) {
      operations.push({ type: "delete", ref: oldDoc.ref });
      if (operations.length >= 400) await flush();
    }
  }
  await flush();

  await setDoc(metaRef(uid), {
    initialized: true,
    sections: Array.isArray(job.state.sections) ? job.state.sections : [],
    favorites: Array.isArray(job.state.favorites) ? job.state.favorites.map(String) : [],
    email: job.email,
    displayName: job.displayName,
    photoURL: job.photoURL,
    updatedAt: serverTimestamp()
  }, { merge: true });
}

// Coalesce rapid edits but never drop the final state while a previous sync is in flight.
function syncState(state) {
  if (!currentUser) return Promise.resolve(false);
  const user = currentUser;
  pendingSync = {
    uid: user.uid,
    email: user.email || "",
    displayName: user.displayName || "",
    photoURL: user.photoURL || "",
    state: {
      items: (state.items || []).map(item => ({ ...item })),
      sections: Array.isArray(state.sections) ? [...state.sections] : [],
      favorites: Array.isArray(state.favorites) ? state.favorites.map(String) : []
    }
  };

  if (syncRunning) return syncPromise;
  syncRunning = true;
  syncPromise = (async () => {
    try {
      while (pendingSync) {
        const job = pendingSync;
        pendingSync = null;
        if (window.BuzzApp?.updateCloudStatus) window.BuzzApp.updateCloudStatus("☁️ Sincronizando sua coleção com o Google...");
        await writeCloudSnapshot(job);
      }
      if (currentUser) window.BuzzApp?.updateCloudStatus?.("☁️ Sua coleção está sincronizada com o Google.");
      return true;
    } catch (error) {
      pendingSync = null;
      console.error("BuzzDataBase Firebase sync failed:", error);
      window.BuzzApp?.updateCloudStatus?.("⚠️ " + explainFirebaseError(error));
      return false;
    } finally {
      syncRunning = false;
      syncPromise = null;
    }
  })();
  return syncPromise;
}

async function getCloudState(uid = currentUser?.uid) {
  if (!uid) return null;
  const snapshot = await getDoc(metaRef(uid));
  if (!snapshot.exists() || snapshot.data()?.initialized !== true) return null;
  const itemSnapshot = await getDocs(itemsRef(uid));
  const items = itemSnapshot.docs.map(document => {
    const value = document.data() || {};
    return {
      id: String(value.id ?? document.id),
      title: String(value.title || "Sem título"),
      section: String(value.section || ""),
      image: typeof value.image === "string" ? value.image : "",
      rating: Number.isFinite(Number(value.rating)) ? Number(value.rating) : 0,
      createdAt: Number.isFinite(Number(value.createdAt)) ? Number(value.createdAt) : Date.now()
    };
  });
  const meta = snapshot.data() || {};
  return {
    initialized: true,
    items,
    sections: Array.isArray(meta.sections) ? meta.sections : [],
    favorites: Array.isArray(meta.favorites) ? meta.favorites.map(String) : []
  };
}

async function handleLogin(localState) {
  if (!currentUser || !window.BuzzApp) return;
  const user = currentUser;
  try {
    const cloud = await getCloudState(user.uid);
    const localOwner = localState?.cloudOwnerUid || null;
    if (cloud) {
      await window.BuzzApp.applyCloudState(cloud, user);
      window.BuzzApp.showCloudMessage("☁️ Coleção carregada da sua conta Google neste aparelho.");
      return;
    }

    const belongsToThisUser = !localOwner || localOwner === user.uid;
    const initialState = belongsToThisUser
      ? localState
      : { items: [], sections: [], favorites: [] };
    const hasUserData = (initialState.items || []).length > 0 ||
      (initialState.sections || []).some(section => ![
        "Anime🇯🇵", "YouTube ▶️", "DC 🔵", "Marvel 🔴", "Star Wars 🌠",
        "Desenhos 🪀", "Filmes e Séries🍿", "Tão ruim que nem Assisti 🗑️",
        "Atores👨‍🎤", "Games Zerados 🎮"
      ].includes(section)) || (initialState.favorites || []).length > 0;

    if (!belongsToThisUser) {
      // Never copy another account's local collection into this account.
      await window.BuzzApp.applyCloudState(initialState, user);
      window.BuzzApp.showCloudMessage("☁️ Esta conta está separada. Adicione ou importe obras para começar a sincronizar.");
      return;
    }

    if (!hasUserData) {
      // A blank device must not create an empty cloud collection before the main device arrives.
      await window.BuzzApp.markCloudOwner(user.uid);
      window.BuzzApp.showCloudMessage("☁️ Google conectado. Esta coleção está vazia neste aparelho; quando você adicionar ou importar obras, elas serão sincronizadas.");
      return;
    }

    const synced = await syncState(initialState);
    if (!synced) throw new Error("A primeira sincronização não foi concluída.");
    await window.BuzzApp.markCloudOwner(user.uid);
    window.BuzzApp.showCloudMessage("☁️ Sua coleção deste aparelho foi vinculada à conta Google.");
  } catch (error) {
    console.error("BuzzDataBase: não foi possível carregar a conta na nuvem.", error);
    window.BuzzApp.showCloudMessage("⚠️ " + explainFirebaseError(error));
  }
}

async function login() {
  try {
    await persistenceReady;
    const isMobileOrInstalled = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent || "") ||
      window.matchMedia?.("(display-mode: standalone)").matches || window.navigator.standalone === true;
    if (isMobileOrInstalled) {
      await signInWithRedirect(auth, provider);
    } else {
      await signInWithPopup(auth, provider);
    }
  } catch (error) {
    console.error("BuzzDataBase Google sign-in failed:", error);
    window.BuzzApp?.showCloudMessage?.("⚠️ " + explainFirebaseError(error));
  }
}

async function logout() {
  try {
    await signOut(auth);
  } catch (error) {
    console.error("BuzzDataBase Firebase sign-out failed:", error);
    window.BuzzApp?.showCloudMessage?.("Não foi possível desconectar a conta. Tente novamente.");
  }
}

window.BuzzFirebase = {
  firebaseConfig,
  login,
  logout,
  getCurrentUser: () => currentUser,
  syncState,
  getCloudState,
  handleLogin,
  setAuthCallback(callback) {
    authCallback = callback;
    if (authInitialized && typeof authCallback === "function") {
      Promise.resolve().then(() => authCallback(currentUser));
    }
  }
};

onAuthStateChanged(auth, async user => {
  currentUser = user || null;
  authInitialized = true;
  if (typeof authCallback === "function") {
    try { await authCallback(currentUser); }
    catch (error) { console.error("BuzzDataBase auth callback failed:", error); }
  }
});

// Completa o fluxo de login por redirecionamento em navegadores móveis/PWA.
persistenceReady.then(() => getRedirectResult(auth)).catch(error => {
  console.error("BuzzDataBase Google redirect result failed:", error);
  window.BuzzApp?.showCloudMessage?.("⚠️ " + explainFirebaseError(error));
});

window.dispatchEvent(new Event("buzzfirebase-ready"));
