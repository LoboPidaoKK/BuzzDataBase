import { initializeApp } from "https://www.gstatic.com/firebasejs/13.1.0/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/13.1.0/firebase-auth.js";
import { getFirestore, collection, doc, getDoc, getDocs, setDoc, writeBatch, serverTimestamp } from "https://www.gstatic.com/firebasejs/13.1.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCwZ7b0jcJbkPr-ZITmuLNOw3CgNYqV7-4",
  authDomain: "buzzdatabase0.firebaseapp.com",
  projectId: "buzzdatabase0",
  storageBucket: "buzzdatabase0.firebasestorage.app",
  messagingSenderId: "960232212219",
  appId: "1:960232212219:web:a7309f66eb1daa4bbe125e",
  measurementId: "G-Z6VDBNRKF4"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const provider = new GoogleAuthProvider();
provider.setCustomParameters({prompt:"select_account"});

let currentUser = null;
let authCallback = null;
let syncBusy = false;

function metaRef(uid){return doc(db,"users",uid);}
function itemsRef(uid){return collection(db,"users",uid,"items");}

function safeItem(item){
  const image = typeof item.image === "string" ? item.image : "";
  return {
    id:String(item.id ?? ""),
    title:String(item.title || ""),
    section:String(item.section || ""),
    rating:Number.isFinite(Number(item.rating)) ? Math.max(0,Math.min(10,Math.round(Number(item.rating)))) : 0,
    createdAt:Number.isFinite(Number(item.createdAt)) ? Number(item.createdAt) : Date.now(),
    // Firestore documents have a 1 MiB hard limit. Very large local covers stay local.
    image:image.length <= 850000 ? image : ""
  };
}

async function syncState(state){
  if(!currentUser || syncBusy)return;
  syncBusy=true;
  try{
    const uid=currentUser.uid;
    const existing=await getDocs(itemsRef(uid));
    const wanted=new Map((state.items||[]).map(item=>[String(item.id),safeItem(item)]));
    let ops=[];
    const flush=async()=>{
      if(!ops.length)return;
      const batch=writeBatch(db);
      for(const op of ops){
        if(op.type==="set")batch.set(op.ref,op.data);
        else batch.delete(op.ref);
      }
      await batch.commit();
      ops=[];
    };
    for(const [id,item] of wanted){
      ops.push({type:"set",ref:doc(itemsRef(uid),id),data:item});
      if(ops.length>=400)await flush();
    }
    for(const d of existing.docs){
      if(!wanted.has(d.id)){
        ops.push({type:"delete",ref:d.ref});
        if(ops.length>=400)await flush();
      }
    }
    await flush();
    await setDoc(metaRef(uid),{
      initialized:true,
      sections:Array.isArray(state.sections)?state.sections:[],
      favorites:Array.isArray(state.favorites)?state.favorites.map(String):[],
      email:currentUser.email||"",
      displayName:currentUser.displayName||"",
      photoURL:currentUser.photoURL||"",
      updatedAt:serverTimestamp()
    },{merge:true});
  }finally{
    syncBusy=false;
  }
}

async function getCloudState(){
  if(!currentUser)return null;
  const snap=await getDoc(metaRef(currentUser.uid));
  if(!snap.exists() || snap.data()?.initialized!==true)return null;
  const itemSnap=await getDocs(itemsRef(currentUser.uid));
  const items=itemSnap.docs.map(d=>{
    const x=d.data()||{};
    return {
      id:String(x.id??d.id),
      title:String(x.title||"Sem título"),
      section:String(x.section||""),
      image:typeof x.image==="string"?x.image:"",
      rating:Number.isFinite(Number(x.rating))?Number(x.rating):0,
      createdAt:Number.isFinite(Number(x.createdAt))?Number(x.createdAt):Date.now()
    };
  });
  const meta=snap.data()||{};
  return {
    initialized:true,
    items,
    sections:Array.isArray(meta.sections)?meta.sections:[],
    favorites:Array.isArray(meta.favorites)?meta.favorites.map(String):[]
  };
}

async function handleLogin(localState){
  if(!currentUser || !window.BuzzApp)return;
  try{
    const cloud=await getCloudState();
    const localOwner=localState?.cloudOwnerUid||null;
    if(cloud){
      await window.BuzzApp.applyCloudState(cloud,currentUser);
      window.BuzzApp.showCloudMessage("☁️ Coleção carregada da sua conta Google.");
    }else if(!localOwner || localOwner===currentUser.uid){
      await syncState(localState);
      await window.BuzzApp.markCloudOwner(currentUser.uid);
      window.BuzzApp.showCloudMessage("☁️ Sua coleção foi sincronizada com o Google.");
    }else{
      // A different account starts isolated instead of receiving another user's local data.
      const empty={items:[],sections:[],favorites:[]};
      await syncState(empty);
      await window.BuzzApp.applyCloudState(empty,currentUser);
      await window.BuzzApp.markCloudOwner(currentUser.uid);
      window.BuzzApp.showCloudMessage("☁️ Nova conta Google: coleção iniciada vazia.");
    }
  }catch(error){
    console.error("BuzzDataBase Firebase sync failed:",error);
    window.BuzzApp.showCloudMessage("⚠️ Login feito, mas a sincronização falhou. Seus dados locais continuam preservados.");
  }
}

async function login(){
  try{await signInWithPopup(auth,provider);}
  catch(error){
    console.error("BuzzDataBase Google sign-in failed:",error);
    const code=error?.code||"";
    let message="Não foi possível entrar com Google.";
    if(code.includes("popup-blocked"))message="O navegador bloqueou a janela do Google. Permita pop-ups e tente novamente.";
    else if(code.includes("unauthorized-domain"))message="Este domínio ainda não está autorizado no Firebase Authentication.";
    else if(code.includes("operation-not-allowed"))message="O login Google ainda não está ativado no Firebase.";
    window.BuzzApp?.showCloudMessage(message);
  }
}
async function logout(){try{await signOut(auth);}catch(error){console.error("BuzzDataBase Firebase sign-out failed:",error);}}

window.BuzzFirebase={firebaseConfig,login,logout,getCurrentUser:()=>currentUser,syncState,getCloudState,handleLogin};

onAuthStateChanged(auth,async user=>{
  currentUser=user||null;
  if(authCallback)await authCallback(currentUser);
});

window.BuzzFirebase.setAuthCallback=callback=>{
  authCallback=callback;
  if(currentUser)Promise.resolve(callback(currentUser));
};

window.dispatchEvent(new Event("buzzfirebase-ready"));
