import { initializeApp } from "https://www.gstatic.com/firebasejs/13.1.0/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  getRedirectResult,
  signOut,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  writeBatch,
  serverTimestamp,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCwZ7b0jcJbkPr-ZITmuLNOw3CgNYqV7-4",
  authDomain: "buzzdatabase0.firebaseapp.com",
  projectId: "buzzdatabase0",
  storageBucket: "buzzdatabase0.firebasestorage.app",
  messagingSenderId: "960232212219",
  appId: "1:960232212219:web:a7309f66eb1daa4bbe125e",
  measurementId: "G-Z6VDBNRKF4"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const provider = new GoogleAuthProvider();
provider.setCustomParameters({ prompt: "select_account" });

let persistenceReady = false;
const persistenceReadyPromise = setPersistence(auth, browserLocalPersistence)
  .catch(error => {
    // Firebase keeps its default LOCAL persistence if this explicit setting fails.
    console.warn("BuzzDataBase: usando a persistência padrão do Firebase Auth.", error);
  })
  .finally(() => {
    persistenceReady = true;
    window.dispatchEvent(new Event("buzzfirebase-login-ready"));
  });

let currentUser = null;
let authCallback = null;
let authInitialized = false;
let authStateKnown = false;
let lastAuthUid = undefined;
let authEventVersion = 0;
let authSessionVersion = 0;
let authQueue = Promise.resolve();
let loginInProgress = false;
let logoutInProgress = false;
let pendingSync = null;
let syncRunning = false;
let syncPromise = null;
let cloudUnsubscribe = null;
let cloudWatchUid = null;
let cloudWatchVersion = 0;

function metaRef(uid) { return doc(db, "users", uid); }
function itemsRef(uid) { return collection(db, "users", uid, "items"); }

function safeItem(item) {
  const image = typeof item.image === "string" ? item.image : "";
  return {
    id: String(item.id ?? ""),
    title: String(item.title || ""),
    section: String(item.section || ""),
    rating: Number.isFinite(Number(item.rating)) ? Math.max(0, Math.min(10, Math.round(Number(item.rating)))) : 0,
    createdAt: Number.isFinite(Number(item.createdAt)) ? Number(item.createdAt) : Date.now(),
    image: image.length <= 850000 ? image : ""
  };
}

function explainFirebaseError(error) {
  const code = String(error?.code || "");
  if (code.includes("permission-denied")) return "O Firestore recusou o acesso. Confira as regras de segurança de users/{uid}.";
  if (code.includes("unauthorized-domain")) return "O domínio lobopidaokk.github.io não está autorizado no Firebase Authentication.";
  if (code.includes("operation-not-allowed")) return "O provedor Google não está ativado no Firebase Authentication.";
  if (code.includes("popup-blocked")) return "O navegador bloqueou a janela de login. Permita pop-ups para lobopidaokk.github.io e tente novamente.";
  if (code.includes("popup-closed-by-user")) return "A janela de login foi fechada antes de concluir. Toque em Entrar com Google para tentar novamente.";
  if (code.includes("cancelled-popup-request")) return "Já existe uma janela de login aberta. Conclua-a ou feche-a e tente novamente.";
  if (code.includes("network-request-failed") || code.includes("unavailable")) return "Sem conexão com o Firebase. Seus dados locais continuam disponíveis; tente novamente quando a conexão voltar.";
  if (code.includes("failed-precondition")) return "O Firestore não está pronto. Confira se o banco foi criado no projeto buzzdatabase0.";
  if (code.includes("resource-exhausted")) return "O limite de uso do Firestore foi atingido. Seus dados locais continuam preservados.";
  return error?.message ? `Falha na sincronização: ${error.message}` : "Não foi possível conectar ao Firebase.";
}

function stopCloudWatcher() {
  cloudWatchVersion++;
  if (typeof cloudUnsubscribe === "function") {
    try { cloudUnsubscribe(); } catch (error) { console.warn("BuzzDataBase: erro ao encerrar a sincronização em tempo real.", error); }
  }
  cloudUnsubscribe = null;
  cloudWatchUid = null;
}

function enqueueAuthState(user, force = false) {
  const nextUser = user || null;
  const nextUid = nextUser?.uid || null;
  const previousUid = currentUser?.uid || null;
  currentUser = nextUser;

  if (previousUid !== nextUid) {
    authSessionVersion++;
    pendingSync = null;
    stopCloudWatcher();
  }

  authInitialized = true;
  if (!force && authStateKnown && lastAuthUid === nextUid) return authQueue;

  authStateKnown = true;
  lastAuthUid = nextUid;
  const eventVersion = ++authEventVersion;
  authQueue = authQueue.catch(() => {}).then(async () => {
    // Ignore an obsolete transition if the user changed again while an async callback was running.
    if (eventVersion !== authEventVersion) return;
    if (typeof authCallback === "function") await authCallback(nextUser);
  });
  return authQueue;
}

function jobIsCurrent(job) {
  return !!currentUser && currentUser.uid === job.uid && authSessionVersion === job.sessionVersion;
}

async function writeCloudSnapshot(job) {
  if (!jobIsCurrent(job)) return false;
  const ref = itemsRef(job.uid);
  const existing = await getDocs(ref);
  if (!jobIsCurrent(job)) return false;

  const wanted = new Map((job.state.items || []).map(item => [String(item.id), safeItem(item)]));
  let operations = [];

  const flush = async () => {
    if (!operations.length) return;
    if (!jobIsCurrent(job)) throw Object.assign(new Error("A conta mudou antes de concluir a sincronização."), { code: "buzzdatabase/session-changed" });
    const batch = writeBatch(db);
    for (const operation of operations) {
      if (operation.type === "set") batch.set(operation.ref, operation.data);
      else batch.delete(operation.ref);
    }
    await batch.commit();
    operations = [];
  };

  for (const [id, item] of wanted) {
    operations.push({ type: "set", ref: doc(ref, id), data: item });
    if (operations.length >= 400) await flush();
  }
  for (const oldDoc of existing.docs) {
    if (!wanted.has(oldDoc.id)) {
      operations.push({ type: "delete", ref: oldDoc.ref });
      if (operations.length >= 400) await flush();
    }
  }
  await flush();
  if (!jobIsCurrent(job)) return false;

  await setDoc(metaRef(job.uid), {
    initialized: true,
    sections: Array.isArray(job.state.sections) ? job.state.sections : [],
    favorites: Array.isArray(job.state.favorites) ? job.state.favorites.map(String) : [],
    email: job.email,
    displayName: job.displayName,
    photoURL: job.photoURL,
    updatedAt: serverTimestamp()
  }, { merge: true });
  return true;
}

// Keep the newest complete snapshot. A later edit is never discarded just because a write is running.
function syncState(state, userOverride = currentUser) {
  if (!userOverride || !currentUser || userOverride.uid !== currentUser.uid) return Promise.resolve(false);
  const user = userOverride;
  pendingSync = {
    uid: user.uid,
    sessionVersion: authSessionVersion,
    email: user.email || "",
    displayName: user.displayName || "",
    photoURL: user.photoURL || "",
    state: {
      items: (state.items || []).map(item => ({ ...item })),
      sections: Array.isArray(state.sections) ? [...state.sections] : [],
      favorites: Array.isArray(state.favorites) ? state.favorites.map(String) : []
    }
  };

  if (syncRunning) return syncPromise;
  syncRunning = true;
  syncPromise = (async () => {
    let lastError = null;
    while (pendingSync) {
      const job = pendingSync;
      pendingSync = null;
      try {
        await writeCloudSnapshot(job);
      } catch (error) {
        lastError = error;
        // If a newer complete snapshot arrived while this write failed, prefer the newest one.
        if (pendingSync) continue;
        throw error;
      }
    }
    if (currentUser?.uid === user.uid && !lastError) {
      window.BuzzApp?.updateCloudStatus?.("☁️ Sua coleção está sincronizada com o Google.");
    }
    return !lastError;
  })().catch(error => {
    console.error("BuzzDataBase Firebase sync failed:", error);
    if (currentUser?.uid === user.uid && error?.code !== "buzzdatabase/session-changed") {
      window.BuzzApp?.updateCloudStatus?.("⚠️ " + explainFirebaseError(error));
    }
    return false;
  }).finally(() => {
    syncRunning = false;
    syncPromise = null;
    if (pendingSync && currentUser?.uid === pendingSync.uid) {
      const next = pendingSync;
      queueMicrotask(() => syncState(next.state, currentUser));
    }
  });
  return syncPromise;
}

async function getCloudState(uid = currentUser?.uid) {
  if (!uid) return null;
  const snapshot = await getDoc(metaRef(uid));
  if (!snapshot.exists() || snapshot.data()?.initialized !== true) return null;
  const itemSnapshot = await getDocs(itemsRef(uid));
  const items = itemSnapshot.docs.map(document => {
    const value = document.data() || {};
    return {
      id: String(value.id ?? document.id),
      title: String(value.title || "Sem título"),
      section: String(value.section || ""),
      image: typeof value.image === "string" ? value.image : "",
      rating: Number.isFinite(Number(value.rating)) ? Number(value.rating) : 0,
      createdAt: Number.isFinite(Number(value.createdAt)) ? Number(value.createdAt) : Date.now()
    };
  });
  const meta = snapshot.data() || {};
  return {
    initialized: true,
    items,
    sections: Array.isArray(meta.sections) ? meta.sections : [],
    favorites: Array.isArray(meta.favorites) ? meta.favorites.map(String) : []
  };
}

function startCloudWatcher(user) {
  if (!user?.uid || currentUser?.uid !== user.uid || cloudWatchUid === user.uid) return;
  stopCloudWatcher();
  const uid = user.uid;
  const version = cloudWatchVersion;
  cloudWatchUid = uid;

  // Metadata is written only after every item batch commits, so it acts as the snapshot marker.
  cloudUnsubscribe = onSnapshot(metaRef(uid), async snapshot => {
    if (version !== cloudWatchVersion || currentUser?.uid !== uid) return;
    if (!snapshot.exists() || snapshot.data()?.initialized !== true) return;
    // Local changes are already in the outgoing full snapshot. Do not replace them mid-write.
    if (syncRunning || pendingSync) return;
    try {
      const cloud = await getCloudState(uid);
      if (!cloud || version !== cloudWatchVersion || currentUser?.uid !== uid) return;
      if (syncRunning || pendingSync) return;
      await window.BuzzApp?.applyCloudState?.(cloud, user);
      if (version === cloudWatchVersion && currentUser?.uid === uid) {
        window.BuzzApp?.updateCloudStatus?.("☁️ Coleção atualizada e sincronizada com sua conta Google.");
      }
    } catch (error) {
      console.error("BuzzDataBase realtime sync failed:", error);
      if (currentUser?.uid === uid) window.BuzzApp?.updateCloudStatus?.("⚠️ " + explainFirebaseError(error));
    }
  }, error => {
    console.error("BuzzDataBase Firestore listener failed:", error);
    if (currentUser?.uid === uid) window.BuzzApp?.updateCloudStatus?.("⚠️ " + explainFirebaseError(error));
  });
}

async function handleLogin(localState, expectedUser = currentUser) {
  const user = expectedUser;
  if (!user || !window.BuzzApp || currentUser?.uid !== user.uid) return;
  const stillThisUser = () => currentUser?.uid === user.uid;
  try {
    const cloud = await getCloudState(user.uid);
    if (!stillThisUser()) return;
    const localOwner = localState?.cloudOwnerUid || null;

    // Never mix unsynced guest edits from a different account into the active Google account.
    if (localState?.guestDirty === true && localOwner && localOwner !== user.uid) {
      window.BuzzApp.setCloudSyncAllowed?.(false);
      window.BuzzApp.showCloudMessage("⚠️ Há alterações locais sem conta vinculadas a outra conta Google. Para preservar sua coleção, saia desta conta e entre com a conta que já era usada neste aparelho.");
      return;
    }

    if (cloud) {
      if (localState?.guestDirty === true) {
        const keepLocal = window.BuzzApp.resolveGuestCloudConflict?.() === true;
        if (!stillThisUser()) return;
        if (keepLocal) {
          const synced = await syncState(localState, user);
          if (!stillThisUser()) return;
          if (!synced) throw new Error("As alterações feitas sem conta não foram enviadas para a nuvem.");
          await window.BuzzApp.markCloudOwner(user.uid);
          await window.BuzzApp.clearGuestChanges?.();
          if (!stillThisUser()) return;
          startCloudWatcher(user);
          window.BuzzApp.showCloudMessage("☁️ Suas alterações feitas sem conta foram preservadas e enviadas ao Google.");
          return;
        }
      }
      await window.BuzzApp.applyCloudState(cloud, user);
      if (!stillThisUser()) return;
      startCloudWatcher(user);
      window.BuzzApp.showCloudMessage("☁️ Coleção carregada e conectada à sua conta Google.");
      return;
    }

    const belongsToThisUser = !localOwner || localOwner === user.uid;
    const initialState = belongsToThisUser
      ? localState
      : { items: [], sections: [], favorites: [] };
    const defaultSections = [
      "Anime🇯🇵", "YouTube ▶️", "DC 🔵", "Marvel 🔴", "Star Wars 🌠",
      "Desenhos 🪀", "Filmes e Séries🍿", "Tão ruim que nem Assisti 🗑️",
      "Atores👨‍🎤", "Games Zerados 🎮"
    ];
    const hasUserData = (initialState.items || []).length > 0 ||
      (initialState.sections || []).some(section => !defaultSections.includes(section)) ||
      (initialState.favorites || []).length > 0;

    if (!belongsToThisUser) {
      await window.BuzzApp.applyCloudState(initialState, user);
      if (!stillThisUser()) return;
      startCloudWatcher(user);
      window.BuzzApp.showCloudMessage("☁️ Esta conta está separada. Adicione ou importe obras para começar a sincronizar.");
      return;
    }

    if (!hasUserData) {
      await window.BuzzApp.markCloudOwner(user.uid);
      await window.BuzzApp.clearGuestChanges?.();
      if (!stillThisUser()) return;
      startCloudWatcher(user);
      window.BuzzApp.showCloudMessage("☁️ Google conectado. Esta coleção está vazia neste aparelho; quando você adicionar ou importar obras, elas serão sincronizadas.");
      return;
    }

    const synced = await syncState(initialState, user);
    if (!stillThisUser()) return;
    if (!synced) throw new Error("A primeira sincronização não foi concluída.");
    await window.BuzzApp.markCloudOwner(user.uid);
    await window.BuzzApp.clearGuestChanges?.();
    if (!stillThisUser()) return;
    startCloudWatcher(user);
    window.BuzzApp.showCloudMessage("☁️ Sua coleção deste aparelho foi vinculada à conta Google.");
  } catch (error) {
    console.error("BuzzDataBase: não foi possível carregar a conta na nuvem.", error);
    if (stillThisUser()) window.BuzzApp.showCloudMessage("⚠️ " + explainFirebaseError(error));
  }
}

// Popup works on GitHub Pages without the third-party-storage redirect dependency.
// It is invoked synchronously from the user's click (no await before opening the popup).
function login(forceAccountPicker = false) {
  if (!persistenceReady) {
    window.BuzzApp?.showCloudMessage?.("Aguarde a inicialização do login Google e tente novamente.");
    return Promise.resolve(false);
  }
  if (loginInProgress) return Promise.resolve(false);
  if (currentUser && !forceAccountPicker) {
    return enqueueAuthState(currentUser).then(() => true);
  }

  loginInProgress = true;
  provider.setCustomParameters({ prompt: "select_account" });
  let signInRequest;
  try {
    signInRequest = signInWithPopup(auth, provider);
  } catch (error) {
    loginInProgress = false;
    window.BuzzApp?.showCloudMessage?.("⚠️ " + explainFirebaseError(error));
    return Promise.resolve(false);
  }

  return Promise.resolve(signInRequest)
    .then(async credential => {
      if (credential?.user) await enqueueAuthState(credential.user);
      return true;
    })
    .catch(error => {
      console.error("BuzzDataBase Google sign-in failed:", error);
      window.BuzzApp?.showCloudMessage?.("⚠️ " + explainFirebaseError(error));
      return false;
    })
    .finally(() => { loginInProgress = false; });
}

async function logout(options = {}) {
  if (logoutInProgress) return false;
  logoutInProgress = true;
  const keepCloud = options?.preserveCloud === true;
  const userAtStart = currentUser;
  try {
    // Device reset must not issue any Firestore write or delete. If a sync is already
    // running/queued, abort the reset so that the user can retry after it finishes.
    if (keepCloud && userAtStart && (syncPromise || pendingSync)) {
      throw new Error('Há uma sincronização em andamento. Aguarde a confirmação de sincronização e tente Reiniciar novamente. Nenhum dado local foi apagado.');
    }

    pendingSync = null;
    stopCloudWatcher();
    await signOut(auth);
    // Explicitly publish signed-out state as well; the observer's duplicate event is deduplicated.
    await enqueueAuthState(null);
    loginInProgress = false;
    return true;
  } catch (error) {
    console.error("BuzzDataBase Firebase sign-out failed:", error);
    if (keepCloud && userAtStart && currentUser?.uid === userAtStart.uid) startCloudWatcher(userAtStart);
    window.BuzzApp?.showCloudMessage?.(error?.message || "Não foi possível desconectar a conta. Tente novamente.");
    return false;
  } finally {
    logoutInProgress = false;
  }
}

window.BuzzFirebase = {
  firebaseConfig,
  login,
  switchAccount: () => login(true),
  logout,
  isReady: () => persistenceReady,
  getCurrentUser: () => currentUser,
  syncState,
  getCloudState,
  handleLogin,
  setAuthCallback(callback) {
    authCallback = callback;
    if (authInitialized && typeof authCallback === "function") {
      return enqueueAuthState(currentUser, true);
    }
  }
};

onAuthStateChanged(auth, user => {
  enqueueAuthState(user).catch(error => console.error("BuzzDataBase auth callback failed:", error));
});

// If a device edited while offline, push its current local snapshot after the connection returns.
window.addEventListener("online", () => {
  if (!currentUser) return;
  const localState = window.BuzzApp?.getLocalCloudState?.();
  if (localState) syncState(localState, currentUser);
});

// Processa eventuais retornos de um fluxo redirect antigo usado em versões anteriores.
persistenceReadyPromise.then(() => getRedirectResult(auth)).then(result => {
  if (result?.user) return enqueueAuthState(result.user);
}).catch(error => {
  console.error("BuzzDataBase Google redirect result failed:", error);
  window.BuzzApp?.showCloudMessage?.("⚠️ " + explainFirebaseError(error));
});

window.dispatchEvent(new Event("buzzfirebase-ready"));
