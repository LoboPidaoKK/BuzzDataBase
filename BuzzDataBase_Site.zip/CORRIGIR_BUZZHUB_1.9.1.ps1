$ErrorActionPreference = 'Stop'

$Root = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$Required = @(
  'index.html',
  'hub-auth.js',
  'sw.js',
  'apps\tier\index.html',
  'apps\tier\sw.js',
  'apps\tier\tier-cloud.js'
)
foreach ($relative in $Required) {
  $full = Join-Path $Root $relative
  if (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
    throw "Arquivo obrigatório não encontrado: $relative. Extraia o BuzzHub v1.9 completo e execute este patch na pasta raiz dele."
  }
}

$Stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$BackupDir = Join-Path $Root ("BUZZHUB_BACKUP_ANTES_1.9.1_" + $Stamp)
New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
$Changed = New-Object System.Collections.Generic.List[string]

function Read-Text([string]$Relative) {
  return [System.IO.File]::ReadAllText((Join-Path $Root $Relative))
}
function Write-Text([string]$Relative, [string]$Content) {
  $Path = Join-Path $Root $Relative
  $Old = [System.IO.File]::ReadAllText($Path)
  if ($Old -ceq $Content) { return }
  $BackupPath = Join-Path $BackupDir $Relative
  $BackupParent = Split-Path -Parent $BackupPath
  New-Item -ItemType Directory -Path $BackupParent -Force | Out-Null
  Copy-Item -LiteralPath $Path -Destination $BackupPath -Force
  $Utf8NoBom = [System.Text.UTF8Encoding]::new($false)
  [System.IO.File]::WriteAllText($Path, $Content, $Utf8NoBom)
  $Changed.Add($Relative)
}

# 1) Remove the obsolete hard-coded 30 MB rejection if it still exists.
$TierCloud = Read-Text 'apps\tier\tier-cloud.js'
$GuardPatterns = @(
  '(?s)\s*if\s*\(\s*json\.length\s*>\s*(?:30000000|30_000_000|30\s*\*\s*1024\s*\*\s*1024)\s*\)\s*throw\s+new\s+Error\([^;]*\)\s*;?',
  '(?s)\s*if\s*\(\s*json\.length\s*>\s*(?:30000000|30_000_000|30\s*\*\s*1024\s*\*\s*1024)\s*\)\s*\{\s*throw\s+new\s+Error\([^;]*\)\s*;?\s*\}'
)
foreach ($pattern in $GuardPatterns) {
  $GuardRegex = [regex]::new($pattern, [System.Text.RegularExpressions.RegexOptions]::Singleline)
  $TierCloud = $GuardRegex.Replace($TierCloud, "`r`n", 1)
}
if ($TierCloud -match 'O backup do BuzzTier passou de 30 MB' -or $TierCloud -match 'json\.length\s*>\s*30000000') {
  throw 'A trava antiga de 30 MB ainda aparece em um formato não reconhecido. Nenhuma versão foi empacotada; preserve a pasta e envie o relatório para análise.'
}
if ($TierCloud -notmatch 'BUZZHUB_TIER_CLOUD_BUILD_1_9_1') {
  $TierCloud = "/* BUZZHUB_TIER_CLOUD_BUILD_1_9_1 — cache refresh */`r`n" + $TierCloud
}
Write-Text 'apps\tier\tier-cloud.js' $TierCloud

# 2) Change every cached reference to tier-cloud.js to a unique release URL.
$TierIndex = Read-Text 'apps\tier\index.html'
$TierIndex = [regex]::Replace($TierIndex, 'tier-cloud\.js\?v=[^''"\s)&]+', 'tier-cloud.js?v=1.9.1')

# 3) Force the Tier service worker to check for a new script and reload once
# after the new controller takes over. This prevents stale app JS from surviving.
$RefreshBlock = @'
<script id="buzzhub-tier-sw-refresh-v1-9-1">
(() => {
  if (!('serviceWorker' in navigator)) return;
  let reloadedForThisController = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (reloadedForThisController) return;
    reloadedForThisController = true;
    const marker = 'buzzhub-tier-controller-reloaded-v1-9-1';
    try {
      if (sessionStorage.getItem(marker) === '1') return;
      sessionStorage.setItem(marker, '1');
    } catch (_) {}
    window.location.reload();
  });
  const refreshWorker = async () => {
    try {
      const registration = await navigator.serviceWorker.register('./sw.js', { updateViaCache: 'none' });
      await registration.update();
    } catch (error) {
      console.warn('BuzzHub: não foi possível verificar a atualização do Service Worker do BuzzTier.', error);
    }
  };
  if (document.readyState === 'complete') refreshWorker();
  else window.addEventListener('load', refreshWorker, { once: true });
})();
</script>
'@
if ($TierIndex -notmatch 'buzzhub-tier-sw-refresh-v1-9-1') {
  if ($TierIndex -notmatch '</body>') { throw 'Não encontrei </body> em apps/tier/index.html para instalar a verificação de atualização.' }
  $TierIndex = $TierIndex -replace '</body>', ($RefreshBlock + "`r`n</body>")
}
Write-Text 'apps\tier\index.html' $TierIndex

# 4) Change Tier and Hub cache names, and update the module URLs inside the SW files.
$TierSw = Read-Text 'apps\tier\sw.js'
if ($TierSw -notmatch 'const\s+CACHE_NAME\s*=') { throw 'Não encontrei CACHE_NAME no Service Worker do BuzzTier.' }
$CacheNamePattern = 'const\s+CACHE_NAME\s*=\s*(["''])(.*?)\1\s*;'
$TierCacheRegex = [regex]::new($CacheNamePattern)
$TierSw = $TierCacheRegex.Replace($TierSw, "const CACHE_NAME = 'buzzhub-tier-v1-9-1';", 1)
$TierSw = [regex]::Replace($TierSw, 'tier-cloud\.js\?v=[^''"\s)&]+', 'tier-cloud.js?v=1.9.1')
if ($TierSw -notmatch 'BUZZHUB_TIER_SW_REFRESH_1_9_1') {
  $Hooks = @'

// BUZZHUB_TIER_SW_REFRESH_1_9_1: activate the new Hub cache immediately.
self.addEventListener('install', event => { event.waitUntil(self.skipWaiting()); });
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys
      .filter(key => (key.startsWith('buzzhub-tier-') || key.startsWith('buzztier-v1-21-buzzhub-')) && key !== CACHE_NAME)
      .map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});
'@
  $TierSw = $TierSw + $Hooks
}
Write-Text 'apps\tier\sw.js' $TierSw

$RootSw = Read-Text 'sw.js'
if ($RootSw -notmatch 'const\s+CACHE_NAME\s*=') { throw 'Não encontrei CACHE_NAME no Service Worker principal do BuzzHub.' }
$RootCacheRegex = [regex]::new($CacheNamePattern)
$RootSw = $RootCacheRegex.Replace($RootSw, "const CACHE_NAME = 'buzzhub-shell-v1-9-1';", 1)
$RootSw = [regex]::Replace($RootSw, 'hub-auth\.js\?v=[^''"\s)&]+', 'hub-auth.js?v=1.9.1')
if ($RootSw -notmatch 'BUZZHUB_ROOT_SW_REFRESH_1_9_1') {
  $RootHooks = @'

// BUZZHUB_ROOT_SW_REFRESH_1_9_1: refresh the Hub shell cache immediately.
self.addEventListener('install', event => { event.waitUntil(self.skipWaiting()); });
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys
      .filter(key => key.startsWith('buzzhub-shell-') && key !== CACHE_NAME)
      .map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});
'@
  $RootSw = $RootSw + $RootHooks
}
Write-Text 'sw.js' $RootSw

# 5) Bump the visible release and force the root Service Worker to revalidate.
$RootIndex = Read-Text 'index.html'
$RootIndex = [regex]::Replace($RootIndex, 'hub-auth\.js\?v=[^''"\s)&]+', 'hub-auth.js?v=1.9.1')
$RootIndex = [regex]::Replace($RootIndex, 'BuzzHub v1\.9(?![.\d])', 'BuzzHub v1.9.1')
$RootRefreshBlock = @'
<script id="buzzhub-root-sw-refresh-v1-9-1">
(() => {
  if (!('serviceWorker' in navigator)) return;
  let reloadedForThisController = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (reloadedForThisController) return;
    reloadedForThisController = true;
    const marker = 'buzzhub-root-controller-reloaded-v1-9-1';
    try {
      if (sessionStorage.getItem(marker) === '1') return;
      sessionStorage.setItem(marker, '1');
    } catch (_) {}
    window.location.reload();
  });
  const refreshWorker = async () => {
    try {
      const registration = await navigator.serviceWorker.register('./sw.js', { updateViaCache: 'none' });
      await registration.update();
    } catch (error) {
      console.warn('BuzzHub: não foi possível verificar a atualização da Central.', error);
    }
  };
  if (document.readyState === 'complete') refreshWorker();
  else window.addEventListener('load', refreshWorker, { once: true });
})();
</script>
'@
if ($RootIndex -notmatch 'buzzhub-root-sw-refresh-v1-9-1') {
  if ($RootIndex -notmatch '</body>') { throw 'Não encontrei </body> em index.html para instalar a verificação da Central.' }
  $RootIndex = $RootIndex -replace '</body>', ($RootRefreshBlock + "`r`n</body>")
}
Write-Text 'index.html' $RootIndex

$HubAuth = Read-Text 'hub-auth.js'
$HubAuth = $HubAuth.Replace("hubVersion: '1.9'", "hubVersion: '1.9.1'")
Write-Text 'hub-auth.js' $HubAuth

# 6) Verify the stale error message is absent from the runtime sources.
$RuntimeFiles = @(
  'apps\tier\index.html',
  'apps\tier\sw.js',
  'apps\tier\tier-cloud.js'
)
foreach ($relative in $RuntimeFiles) {
  $content = Read-Text $relative
  if ($content -match 'O backup do BuzzTier passou de 30 MB' -or $content -match 'json\.length\s*>\s*30000000') {
    throw "A referência à trava antiga ainda existe em $relative. O ZIP final não foi criado."
  }
}
if ((Read-Text 'apps\tier\index.html') -notmatch 'tier-cloud\.js\?v=1\.9\.1') { throw 'A referência do módulo do BuzzTier não foi atualizada.' }
if ((Read-Text 'apps\tier\sw.js') -notmatch 'buzzhub-tier-v1-9-1') { throw 'O cache do BuzzTier não foi atualizado.' }

# 7) Create a complete deployable ZIP from the patched project, excluding the
# patch utility and the safety copies. Original files remain in the backup folder.
$Parent = Split-Path -Parent $Root
$OutputZip = Join-Path $Parent 'BuzzHub_v1.9.1_Corrigido.zip'
if (Test-Path -LiteralPath $OutputZip) { Remove-Item -LiteralPath $OutputZip -Force }
$Stage = Join-Path $env:TEMP ("BuzzHub_191_stage_" + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $Stage -Force | Out-Null
try {
  Get-ChildItem -LiteralPath $Root -Force | Where-Object { $_.Name -notin @('CORRIGIR_BUZZHUB_1.9.1.ps1', 'CORRIGIR_BUZZHUB_1.9.1.bat', 'LEIA-ME_CORRECAO_1.9.1.txt') -and $_.Name -notlike 'BUZZHUB_BACKUP_ANTES_1.9.1_*' } | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $Stage -Recurse -Force
  }
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [System.IO.Compression.ZipFile]::CreateFromDirectory($Stage, $OutputZip, [System.IO.Compression.CompressionLevel]::Optimal, $false)
} finally {
  if (Test-Path -LiteralPath $Stage) { Remove-Item -LiteralPath $Stage -Recurse -Force }
}

Write-Host ''
Write-Host 'CORREÇÃO CONCLUÍDA — BUZZHUB v1.9.1' -ForegroundColor Green
Write-Host 'Arquivos atualizados:' -ForegroundColor Cyan
if ($Changed.Count -eq 0) { Write-Host '  Nenhum arquivo precisava de alteração; os arquivos já estavam atualizados.' }
else { $Changed | Sort-Object -Unique | ForEach-Object { Write-Host "  - $_" } }
Write-Host "Backup dos arquivos anteriores: $BackupDir" -ForegroundColor Yellow
Write-Host "ZIP pronto para publicar: $OutputZip" -ForegroundColor Green
Write-Host 'A trava antiga de 30 MB não aparece nos arquivos de execução.' -ForegroundColor Green
