const CACHE_NAME = 'buzzhub-shell-v3-0-local';
const SHELL = ['./', './index.html', './hub-auth.js?v=3.0-local', './theme-runtime.js?v=3.0', './manifest.webmanifest', './icon-192.png', './icon-512.png', './apps/dash/icon-home.png'];
self.addEventListener('install', event => event.waitUntil((async () => {
  const cache = await caches.open(CACHE_NAME);
  await cache.addAll(SHELL);
  await self.skipWaiting();
})()));
self.addEventListener('activate', event => event.waitUntil((async () => {
  const keys = await caches.keys();
  await Promise.all(keys.filter(key => key.startsWith('buzzhub-shell-') && key !== CACHE_NAME).map(key => caches.delete(key)));
  await self.clients.claim();
})()));
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  const scopePath = new URL(self.registration.scope).pathname;
  if (!url.pathname.startsWith(scopePath)) return;
  const relativePath = url.pathname.slice(scopePath.length);
  if (relativePath.startsWith('apps/') && relativePath !== 'apps/dash/icon-home.png') return;
  if (request.mode === 'navigate' || relativePath === '' || relativePath === 'index.html') {
    event.respondWith((async () => {
      try {
        const response = await fetch(request, { cache: 'no-store' });
        if (response?.ok) caches.open(CACHE_NAME).then(cache => cache.put(request, response.clone())).catch(() => {});
        return response;
      } catch (_) { return (await caches.match(request)) || (await caches.match('./index.html')) || Response.error(); }
    })());
    return;
  }
  event.respondWith((async () => {
    const cached = await caches.match(request);
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response?.ok) caches.open(CACHE_NAME).then(cache => cache.put(request, response.clone())).catch(() => {});
      return response;
    } catch (_) { return Response.error(); }
  })());
});
