import { initializeApp } from "https://www.gstatic.com/firebasejs/13.1.0/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  getRedirectResult,
  signOut,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  getDocFromServer,
  getDocsFromServer,
  setDoc,
  writeBatch,
  serverTimestamp,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCwZ7b0jcJbkPr-ZITmuLNOw3CgNYqV7-4",
  authDomain: "buzzdatabase0.firebaseapp.com",
  projectId: "buzzdatabase0",
  storageBucket: "buzzdatabase0.firebasestorage.app",
  messagingSenderId: "960232212219",
  appId: "1:960232212219:web:a7309f66eb1daa4bbe125e",
  measurementId: "G-Z6VDBNRKF4"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const provider = new GoogleAuthProvider();
provider.setCustomParameters({ prompt: "select_account" });

let persistenceReady = false;
const persistenceReadyPromise = setPersistence(auth, browserLocalPersistence)
  .catch(error => {
    // Firebase keeps its default LOCAL persistence if this explicit setting fails.
    console.warn("BuzzDataBase: usando a persistência padrão do Firebase Auth.", error);
  })
  .finally(() => {
    persistenceReady = true;
    window.dispatchEvent(new Event("buzzfirebase-login-ready"));
  });

let currentUser = null;
let authCallback = null;
let authInitialized = false;
let authStateKnown = false;
let lastAuthUid = undefined;
let authEventVersion = 0;
let authSessionVersion = 0;
let authQueue = Promise.resolve();
let loginInProgress = false;
let logoutInProgress = false;
let pendingSync = null;
let syncRunning = false;
let syncPromise = null;
let confirmationLock = false;
let confirmationPromise = null;
let cloudUnsubscribe = null;
let cloudWatchUid = null;
let cloudWatchVersion = 0;

function metaRef(uid) { return doc(db, "users", uid); }
function itemsRef(uid) { return collection(db, "users", uid, "items"); }

function safeItem(item) {
  const image = typeof item.image === "string" ? item.image : "";
  if (image.length > 850000) {
    throw Object.assign(new Error(`A capa da obra "${String(item.title || "Sem título")}" é grande demais para ser gravada com segurança no Firestore. A versão local foi preservada.`), { code: "buzzdatabase/image-too-large" });
  }
  return {
    id: String(item.id ?? ""),
    title: String(item.title || ""),
    section: String(item.section || ""),
    rating: Number.isFinite(Number(item.rating)) ? Math.max(0, Math.min(10, Math.round(Number(item.rating)))) : 0,
    createdAt: Number.isFinite(Number(item.createdAt)) ? Number(item.createdAt) : Date.now(),
    image
  };
}

function explainFirebaseError(error) {
  const code = String(error?.code || "");
  if (code.includes("permission-denied")) return "O Firestore recusou o acesso. Confira as regras de segurança de users/{uid}.";
  if (code.includes("unauthorized-domain")) return "O domínio lobopidaokk.github.io não está autorizado no Firebase Authentication.";
  if (code.includes("operation-not-allowed")) return "O provedor Google não está ativado no Firebase Authentication.";
  if (code.includes("popup-blocked")) return "O navegador bloqueou a janela de login. Permita pop-ups para lobopidaokk.github.io e tente novamente.";
  if (code.includes("popup-closed-by-user")) return "A janela de login foi fechada antes de concluir. Toque em Entrar com Google para tentar novamente.";
  if (code.includes("cancelled-popup-request")) return "Já existe uma janela de login aberta. Conclua-a ou feche-a e tente novamente.";
  if (code.includes("network-request-failed") || code.includes("unavailable")) return "Sem conexão com o Firebase. Seus dados locais continuam disponíveis; tente novamente quando a conexão voltar.";
  if (code.includes("failed-precondition")) return "O Firestore não está pronto. Confira se o banco foi criado no projeto buzzdatabase0.";
  if (code.includes("resource-exhausted")) return "O limite de uso do Firestore foi atingido. Seus dados locais continuam preservados.";
  if (code.includes("buzzdatabase/image-too-large")) return error?.message || "Uma das capas excede o tamanho aceito para sincronização. Seus dados locais continuam preservados.";
  if (code.includes("buzzdatabase/session-changed")) return "A conta Google mudou durante a gravação. Nenhuma confirmação foi emitida.";
  return error?.message ? `Falha na sincronização: ${error.message}` : "Não foi possível conectar ao Firebase.";
}

function stopCloudWatcher() {
  cloudWatchVersion++;
  if (typeof cloudUnsubscribe === "function") {
    try { cloudUnsubscribe(); } catch (error) { console.warn("BuzzDataBase: erro ao encerrar a sincronização em tempo real.", error); }
  }
  cloudUnsubscribe = null;
  cloudWatchUid = null;
}

function enqueueAuthState(user, force = false) {
  const nextUser = user || null;
  const nextUid = nextUser?.uid || null;
  const previousUid = currentUser?.uid || null;
  currentUser = nextUser;

  if (previousUid !== nextUid) {
    authSessionVersion++;
    pendingSync = null;
    stopCloudWatcher();
  }

  authInitialized = true;
  if (!force && authStateKnown && lastAuthUid === nextUid) return authQueue;

  authStateKnown = true;
  lastAuthUid = nextUid;
  const eventVersion = ++authEventVersion;
  authQueue = authQueue.catch(() => {}).then(async () => {
    // Ignore an obsolete transition if the user changed again while an async callback was running.
    if (eventVersion !== authEventVersion) return;
    if (typeof authCallback === "function") await authCallback(nextUser);
  });
  return authQueue;
}

function jobIsCurrent(job) {
  return !!currentUser && currentUser.uid === job.uid && authSessionVersion === job.sessionVersion;
}

function comparableCloudState(state) {
  const normalizedItems = (state?.items || []).map(safeItem).sort((a, b) => a.id.localeCompare(b.id));
  const sections = Array.isArray(state?.sections) ? state.sections.map(String) : [];
  const favorites = Array.isArray(state?.favorites) ? state.favorites.map(String).sort() : [];
  return JSON.stringify({ items: normalizedItems, sections, favorites });
}

function sameCloudState(a, b) {
  try { return comparableCloudState(a) === comparableCloudState(b); }
  catch (_) { return false; }
}

function createSyncJob(state, user = currentUser) {
  if (!user || !currentUser || user.uid !== currentUser.uid) throw Object.assign(new Error("A conta Google não está mais conectada."), { code: "buzzdatabase/session-changed" });
  const sourceItems = Array.isArray(state?.items) ? state.items : [];
  const ids = sourceItems.map(item => String(item?.id ?? ""));
  if (ids.some(id => !id)) throw new Error("A coleção contém uma obra sem identificador. Nenhum dado foi enviado.");
  if (new Set(ids).size !== ids.length) throw new Error("A coleção contém identificadores repetidos. Nenhum dado foi enviado.");
  return {
    uid: user.uid,
    sessionVersion: authSessionVersion,
    email: user.email || "",
    displayName: user.displayName || "",
    photoURL: user.photoURL || "",
    snapshotId: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
    state: {
      items: sourceItems.map(item => ({ ...item })),
      sections: Array.isArray(state?.sections) ? [...state.sections].map(String) : [],
      favorites: Array.isArray(state?.favorites) ? state.favorites.map(String) : []
    }
  };
}

function emitConfirmProgress(callback, percent, message) {
  if (typeof callback !== "function") return;
  try { callback(Math.max(0, Math.min(99, Math.round(percent))), String(message || "")); }
  catch (error) { console.warn("BuzzDataBase: callback de progresso falhou.", error); }
}

function mapCloudItem(document) {
  const value = document.data() || {};
  return {
    id: String(value.id ?? document.id),
    docId: document.id,
    title: String(value.title || "Sem título"),
    section: String(value.section || ""),
    image: typeof value.image === "string" ? value.image : "",
    rating: Number.isFinite(Number(value.rating)) ? Number(value.rating) : 0,
    createdAt: Number.isFinite(Number(value.createdAt)) ? Number(value.createdAt) : Date.now()
  };
}

function sameStoredItem(a, b) {
  const left = safeItem(a);
  const right = safeItem(b);
  return left.id === right.id &&
    left.title === right.title &&
    left.section === right.section &&
    left.rating === right.rating &&
    left.createdAt === right.createdAt &&
    left.image === right.image;
}

async function readCloudSnapshotFromServer(uid) {
  const [metaSnapshot, itemSnapshot] = await Promise.all([
    getDocFromServer(metaRef(uid)),
    getDocsFromServer(itemsRef(uid))
  ]);
  const meta = metaSnapshot.exists() ? (metaSnapshot.data() || {}) : {};
  return {
    initialized: meta.initialized === true,
    items: itemSnapshot.docs.map(mapCloudItem),
    sections: Array.isArray(meta.sections) ? meta.sections.map(String) : [],
    favorites: Array.isArray(meta.favorites) ? meta.favorites.map(String) : [],
    snapshotId: typeof meta.snapshotId === "string" ? meta.snapshotId : null,
    itemCount: Number.isFinite(Number(meta.itemCount)) ? Number(meta.itemCount) : itemSnapshot.size
  };
}

async function writeCloudSnapshot(job, existingItems = null, onProgress = null) {
  if (!jobIsCurrent(job)) throw Object.assign(new Error("A conta mudou antes de iniciar a sincronização."), { code: "buzzdatabase/session-changed" });
  const ref = itemsRef(job.uid);
  let currentItems = existingItems;
  if (!Array.isArray(currentItems)) {
    const existing = await getDocs(ref);
    currentItems = existing.docs.map(mapCloudItem);
  }
  if (!jobIsCurrent(job)) throw Object.assign(new Error("A conta mudou antes de concluir a sincronização."), { code: "buzzdatabase/session-changed" });

  const wanted = new Map();
  for (const sourceItem of (job.state.items || [])) {
    const item = safeItem(sourceItem);
    if (!item.id) throw new Error("A coleção contém uma obra sem identificador.");
    wanted.set(item.id, item);
  }

  const existingById = new Map(currentItems.map(item => [String(item.id), item]));
  const operations = [];
  let unchangedCount = 0;
  for (const [id, item] of wanted) {
    const oldItem = existingById.get(id);
    if (oldItem && sameStoredItem(oldItem, item)) {
      unchangedCount++;
      continue;
    }
    operations.push({ type: "set", ref: doc(ref, id), data: item });
  }
  for (const oldItem of currentItems) {
    const id = String(oldItem.id ?? "");
    if (!wanted.has(id)) {
      operations.push({ type: "delete", ref: doc(ref, String(oldItem.docId || id)) });
    }
  }

  const totalOperations = operations.length;
  let completedOperations = 0;
  const batchSize = 400;
  for (let offset = 0; offset < operations.length; offset += batchSize) {
    if (!jobIsCurrent(job)) throw Object.assign(new Error("A conta Google mudou antes de concluir a sincronização."), { code: "buzzdatabase/session-changed" });
    const slice = operations.slice(offset, offset + batchSize);
    const batch = writeBatch(db);
    for (const operation of slice) {
      if (operation.type === "set") batch.set(operation.ref, operation.data);
      else batch.delete(operation.ref);
    }
    await batch.commit();
    completedOperations += slice.length;
    const fraction = totalOperations ? completedOperations / totalOperations : 1;
    emitConfirmProgress(onProgress, 18 + fraction * 60,
      `Enviando alterações: ${completedOperations}/${totalOperations} operações confirmadas…`);
  }

  if (!jobIsCurrent(job)) throw Object.assign(new Error("A conta mudou antes de finalizar o estado na nuvem."), { code: "buzzdatabase/session-changed" });
  emitConfirmProgress(onProgress, 81, totalOperations
    ? "Obras atualizadas. Gravando tópicos e favoritos…"
    : "As obras já estavam iguais. Atualizando o registro de sincronização…");

  await setDoc(metaRef(job.uid), {
    initialized: true,
    snapshotId: job.snapshotId,
    itemCount: wanted.size,
    sections: Array.isArray(job.state.sections) ? job.state.sections : [],
    favorites: Array.isArray(job.state.favorites) ? job.state.favorites.map(String) : [],
    email: job.email,
    displayName: job.displayName,
    photoURL: job.photoURL,
    updatedAt: serverTimestamp()
  }, { merge: true });
  if (!jobIsCurrent(job)) throw Object.assign(new Error("A conta Google mudou depois da gravação."), { code: "buzzdatabase/session-changed" });
  return {
    snapshotId: job.snapshotId,
    itemCount: wanted.size,
    writtenCount: operations.filter(operation => operation.type === "set").length,
    deletedCount: operations.filter(operation => operation.type === "delete").length,
    unchangedCount
  };
}

// Autosaves are serialized. The newest complete snapshot waits behind an active write.
function syncState(state, userOverride = currentUser) {
  if (!userOverride || !currentUser || userOverride.uid !== currentUser.uid) return Promise.resolve(false);
  let job;
  try { job = createSyncJob(state, userOverride); }
  catch (error) {
    window.BuzzApp?.updateCloudStatus?.("⚠️ " + explainFirebaseError(error));
    return Promise.resolve(false);
  }
  pendingSync = job;
  if (confirmationLock) return confirmationPromise || Promise.resolve(false);
  if (syncRunning) return syncPromise;
  syncRunning = true;
  syncPromise = (async () => {
    let lastError = null;
    while (pendingSync) {
      const nextJob = pendingSync;
      pendingSync = null;
      try {
        const written = await writeCloudSnapshot(nextJob);
        if (!written || !jobIsCurrent(nextJob)) throw Object.assign(new Error("A gravação não foi concluída para a conta ativa."), { code: "buzzdatabase/session-changed" });
        lastError = null;
        const marked = await window.BuzzApp?.markCloudSynced?.(nextJob.state, nextJob.uid);
        if (marked === false) {
          if (pendingSync) continue;
          throw new Error("A coleção mudou enquanto a gravação estava em andamento. A versão atual ainda precisa ser sincronizada.");
        }
      } catch (error) {
        lastError = error;
        if (pendingSync) continue;
        throw error;
      }
    }
    if (currentUser?.uid === userOverride.uid && !lastError) {
      window.BuzzApp?.updateCloudStatus?.("☁️ Sua coleção está sincronizada com o Google.");
    }
    return !lastError;
  })().catch(error => {
    console.error("BuzzDataBase Firebase sync failed:", error);
    if (currentUser?.uid === userOverride.uid && error?.code !== "buzzdatabase/session-changed") {
      window.BuzzApp?.updateCloudStatus?.("⚠️ " + explainFirebaseError(error));
    }
    return false;
  }).finally(() => {
    syncRunning = false;
    syncPromise = null;
    if (pendingSync && currentUser?.uid === pendingSync.uid && !confirmationLock) {
      const next = pendingSync;
      pendingSync = null;
      queueMicrotask(() => syncState(next.state, currentUser));
    }
  });
  return syncPromise;
}

async function confirmState(state, userOverride = currentUser, options = {}) {
  if (confirmationPromise) await confirmationPromise.catch(() => false);
  if (!userOverride || !currentUser || userOverride.uid !== currentUser.uid) throw Object.assign(new Error("Entre com a conta Google correta antes de confirmar o estado."), { code: "buzzdatabase/session-changed" });
  const onProgress = typeof options?.onProgress === "function" ? options.onProgress : null;
  const report = (percent, message) => emitConfirmProgress(onProgress, percent, message);

  const operation = (async () => {
    report(3, "Aguardando gravações anteriores…");
    let drainAttempts = 0;
    while ((syncRunning || pendingSync) && drainAttempts++ < 12) {
      if (syncRunning && syncPromise) await syncPromise.catch(() => false);
      else if (pendingSync) await syncState(pendingSync.state, userOverride).catch(() => false);
      if (currentUser?.uid !== userOverride.uid) throw Object.assign(new Error("A conta Google mudou durante a confirmação."), { code: "buzzdatabase/session-changed" });
      report(8, "Preparando a versão mais recente da coleção…");
    }
    if (syncRunning || pendingSync) throw new Error("A sincronização automática não terminou. Tente Confirmar Estado novamente.");

    confirmationLock = true;
    try {
      let source = window.BuzzApp?.getLocalCloudState?.() || state;
      let confirmedJob = null;
      let finalWrite = null;
      for (let attempt = 0; attempt < 4; attempt++) {
        if (!currentUser || currentUser.uid !== userOverride.uid) throw Object.assign(new Error("A conta Google mudou durante a confirmação."), { code: "buzzdatabase/session-changed" });
        const job = createSyncJob(source, userOverride);
        report(10, "Lendo a coleção atual da nuvem…");
        const remote = await readCloudSnapshotFromServer(userOverride.uid);
        report(17, "Comparando obras locais e obras da nuvem…");

        const latestBeforeWrite = window.BuzzApp?.getLocalCloudState?.() || source;
        if (!sameCloudState(latestBeforeWrite, job.state)) {
          source = latestBeforeWrite;
          report(18, "A coleção mudou durante a preparação. Atualizando a confirmação…");
          pendingSync = null;
          continue;
        }

        const localIds = new Set(job.state.items.map(item => String(item.id)));
        const cloudOnly = remote.items.filter(item => !localIds.has(String(item.id)));
        if (cloudOnly.length && typeof options?.onCloudConflict === "function") {
          const accepted = await options.onCloudConflict(cloudOnly, remote);
          if (accepted !== true) return { ok: false, cancelled: true };
        }

        report(18, "Enviando somente as alterações necessárias…");
        const writeResult = await writeCloudSnapshot(job, remote.items, (percent, message) => report(percent, message));
        if (!jobIsCurrent(job)) throw Object.assign(new Error("A conta mudou durante a gravação."), { code: "buzzdatabase/session-changed" });

        const latestLocal = window.BuzzApp?.getLocalCloudState?.() || job.state;
        if (!sameCloudState(latestLocal, job.state)) {
          source = latestLocal;
          pendingSync = null;
          report(82, "Houve uma alteração durante o envio. Atualizando a versão a confirmar…");
          continue;
        }
        if (pendingSync && !sameCloudState(pendingSync.state, job.state)) {
          source = window.BuzzApp?.getLocalCloudState?.() || latestLocal;
          pendingSync = null;
          report(82, "Uma edição recente foi detectada. Incluindo-a na confirmação…");
          continue;
        }

        report(88, "Conferindo a confirmação da nuvem…");
        const confirmedMeta = await getDocFromServer(metaRef(userOverride.uid));
        const meta = confirmedMeta.exists() ? (confirmedMeta.data() || {}) : {};
        const metadataMatches = meta.initialized === true &&
          meta.snapshotId === job.snapshotId &&
          Number(meta.itemCount) === job.state.items.length &&
          JSON.stringify(Array.isArray(meta.sections) ? meta.sections.map(String) : []) === JSON.stringify(job.state.sections) &&
          JSON.stringify(Array.isArray(meta.favorites) ? meta.favorites.map(String).sort() : []) === JSON.stringify([...job.state.favorites].sort());
        if (!metadataMatches) {
          source = window.BuzzApp?.getLocalCloudState?.() || latestLocal;
          pendingSync = null;
          report(89, "A nuvem ainda não confirmou o registro. Tentando novamente…");
          continue;
        }
        confirmedJob = job;
        finalWrite = writeResult;
        break;
      }
      if (!confirmedJob) throw new Error("O estado mudou durante o envio ou o servidor não confirmou a gravação. Nenhuma confirmação foi emitida; tente novamente.");

      const marked = await window.BuzzApp?.markCloudSynced?.(confirmedJob.state, userOverride.uid);
      if (marked === false) throw new Error("A coleção local mudou antes da confirmação final. Tente novamente para gravar a versão atualizada.");
      report(100, "Sincronização confirmada!");
      return {
        ok: true,
        snapshotId: confirmedJob.snapshotId,
        itemCount: confirmedJob.state.items.length,
        sectionCount: confirmedJob.state.sections.length,
        favoriteCount: confirmedJob.state.favorites.length,
        writtenCount: finalWrite?.writtenCount || 0,
        deletedCount: finalWrite?.deletedCount || 0,
        unchangedCount: finalWrite?.unchangedCount || 0
      };
    } finally {
      confirmationLock = false;
    }
  })();
  confirmationPromise = operation;
  try {
    return await operation;
  } finally {
    confirmationPromise = null;
    if (pendingSync && currentUser?.uid === pendingSync.uid && !syncRunning) {
      const next = pendingSync;
      pendingSync = null;
      queueMicrotask(() => syncState(next.state, currentUser));
    }
  }
}

async function getCloudState(uid = currentUser?.uid, options = {}) {
  if (!uid) return null;
  const serverOnly = options?.serverOnly === true;
  const [metaSnapshot, itemSnapshot] = await Promise.all([
    serverOnly ? getDocFromServer(metaRef(uid)) : getDoc(metaRef(uid)),
    serverOnly ? getDocsFromServer(itemsRef(uid)) : getDocs(itemsRef(uid))
  ]);
  if (!metaSnapshot.exists() || metaSnapshot.data()?.initialized !== true) return null;
  const meta = metaSnapshot.data() || {};
  return {
    initialized: true,
    items: itemSnapshot.docs.map(mapCloudItem),
    sections: Array.isArray(meta.sections) ? meta.sections : [],
    favorites: Array.isArray(meta.favorites) ? meta.favorites.map(String) : [],
    snapshotId: typeof meta.snapshotId === "string" ? meta.snapshotId : null,
    itemCount: Number.isFinite(Number(meta.itemCount)) ? Number(meta.itemCount) : itemSnapshot.size
  };
}

function startCloudWatcher(user) {
  if (!user?.uid || currentUser?.uid !== user.uid || cloudWatchUid === user.uid) return;
  stopCloudWatcher();
  const uid = user.uid;
  const version = cloudWatchVersion;
  cloudWatchUid = uid;

  // Metadata is written only after every item batch commits, so it acts as the snapshot marker.
  cloudUnsubscribe = onSnapshot(metaRef(uid), async snapshot => {
    if (version !== cloudWatchVersion || currentUser?.uid !== uid) return;
    if (!snapshot.exists() || snapshot.data()?.initialized !== true) return;
    // Never replace local edits that have not been confirmed by the server.
    const localBeforeRead = window.BuzzApp?.getLocalCloudState?.();
    if (localBeforeRead?.cloudDirty === true || localBeforeRead?.guestDirty === true) {
      window.BuzzApp?.updateCloudStatus?.("⚠️ Há alterações locais pendentes. Elas foram preservadas; use Confirmar Estado para enviá-las ao Google.");
      return;
    }
    if (syncRunning || pendingSync || confirmationLock) return;
    try {
      const cloud = await getCloudState(uid);
      if (!cloud || version !== cloudWatchVersion || currentUser?.uid !== uid) return;
      const localBeforeApply = window.BuzzApp?.getLocalCloudState?.();
      if (syncRunning || pendingSync || confirmationLock || localBeforeApply?.cloudDirty === true || localBeforeApply?.guestDirty === true) return;
      await window.BuzzApp?.applyCloudState?.(cloud, user);
      if (version === cloudWatchVersion && currentUser?.uid === uid) {
        window.BuzzApp?.updateCloudStatus?.("☁️ Coleção atualizada e sincronizada com sua conta Google.");
      }
    } catch (error) {
      console.error("BuzzDataBase realtime sync failed:", error);
      if (currentUser?.uid === uid) window.BuzzApp?.updateCloudStatus?.("⚠️ " + explainFirebaseError(error));
    }
  }, error => {
    console.error("BuzzDataBase Firestore listener failed:", error);
    if (currentUser?.uid === uid) window.BuzzApp?.updateCloudStatus?.("⚠️ " + explainFirebaseError(error));
  });
}

async function handleLogin(localState, expectedUser = currentUser) {
  const user = expectedUser;
  if (!user || !window.BuzzApp || currentUser?.uid !== user.uid) return;
  const stillThisUser = () => currentUser?.uid === user.uid;
  try {
    const cloud = await getCloudState(user.uid);
    if (!stillThisUser()) return;
    const localOwner = localState?.cloudOwnerUid || null;

    // Never mix unsynced guest edits from a different account into the active Google account.
    if ((localState?.guestDirty === true || localState?.cloudDirty === true) && localOwner && localOwner !== user.uid) {
      window.BuzzApp.setCloudSyncAllowed?.(false);
      window.BuzzApp.showCloudMessage("⚠️ Há alterações locais vinculadas a outra conta Google. Para preservar sua coleção, saia desta conta e entre com a conta que já era usada neste aparelho.");
      return;
    }

    if (cloud) {
      if (localState?.cloudDirty === true && (!localOwner || localOwner === user.uid)) {
        const keepLocal = window.BuzzApp.resolveGuestCloudConflict?.("cloud") === true;
        if (!stillThisUser()) return;
        if (keepLocal) {
          const synced = await syncState(localState, user);
          if (!stillThisUser()) return;
          if (!synced) throw new Error("As alterações locais pendentes não foram enviadas para a nuvem.");
          const verified = await getCloudState(user.uid, { serverOnly: true });
          if (!verified || !sameCloudState(verified, localState)) throw new Error("A nuvem não retornou a coleção local completa após a sincronização.");
          await window.BuzzApp.markCloudSynced?.(localState, user.uid);
          if (!stillThisUser()) return;
          startCloudWatcher(user);
          window.BuzzApp.showCloudMessage("☁️ Alterações locais recuperadas e confirmadas na sua conta Google.");
          return;
        }
      }
      if (localState?.guestDirty === true) {
        const keepLocal = window.BuzzApp.resolveGuestCloudConflict?.() === true;
        if (!stillThisUser()) return;
        if (keepLocal) {
          const synced = await syncState(localState, user);
          if (!stillThisUser()) return;
          if (!synced) throw new Error("As alterações feitas sem conta não foram enviadas para a nuvem.");
          await window.BuzzApp.markCloudOwner(user.uid);
          await window.BuzzApp.clearGuestChanges?.();
          if (!stillThisUser()) return;
          startCloudWatcher(user);
          window.BuzzApp.showCloudMessage("☁️ Suas alterações feitas sem conta foram preservadas e enviadas ao Google.");
          return;
        }
      }
      await window.BuzzApp.applyCloudState(cloud, user);
      if (!stillThisUser()) return;
      startCloudWatcher(user);
      window.BuzzApp.showCloudMessage("☁️ Coleção carregada e conectada à sua conta Google.");
      return;
    }

    const belongsToThisUser = !localOwner || localOwner === user.uid;
    const initialState = belongsToThisUser
      ? localState
      : { items: [], sections: [], favorites: [] };
    const defaultSections = [
      "Anime🇯🇵", "YouTube ▶️", "DC 🔵", "Marvel 🔴", "Star Wars 🌠",
      "Desenhos 🪀", "Filmes e Séries🍿", "Tão ruim que nem Assisti 🗑️",
      "Atores👨‍🎤", "Games Zerados 🎮"
    ];
    const hasUserData = (initialState.items || []).length > 0 ||
      (initialState.sections || []).some(section => !defaultSections.includes(section)) ||
      (initialState.favorites || []).length > 0;

    if (!belongsToThisUser) {
      await window.BuzzApp.applyCloudState(initialState, user);
      if (!stillThisUser()) return;
      startCloudWatcher(user);
      window.BuzzApp.showCloudMessage("☁️ Esta conta está separada. Adicione ou importe obras para começar a sincronizar.");
      return;
    }

    if (!hasUserData) {
      if (localState?.cloudDirty === true) {
        const synced = await syncState(initialState, user);
        if (!stillThisUser()) return;
        if (!synced) throw new Error("O estado vazio deste aparelho ainda não foi confirmado na nuvem.");
      } else {
        await window.BuzzApp.markCloudOwner(user.uid);
        await window.BuzzApp.clearGuestChanges?.();
      }
      if (!stillThisUser()) return;
      startCloudWatcher(user);
      window.BuzzApp.showCloudMessage("☁️ Google conectado. Esta coleção está vazia neste aparelho; quando você adicionar ou importar obras, elas serão sincronizadas.");
      return;
    }

    const synced = await syncState(initialState, user);
    if (!stillThisUser()) return;
    if (!synced) throw new Error("A primeira sincronização não foi concluída.");
    await window.BuzzApp.markCloudOwner(user.uid);
    await window.BuzzApp.clearGuestChanges?.();
    if (!stillThisUser()) return;
    startCloudWatcher(user);
    window.BuzzApp.showCloudMessage("☁️ Sua coleção deste aparelho foi vinculada à conta Google.");
  } catch (error) {
    console.error("BuzzDataBase: não foi possível carregar a conta na nuvem.", error);
    if (stillThisUser()) window.BuzzApp.showCloudMessage("⚠️ " + explainFirebaseError(error));
  }
}

// Popup works on GitHub Pages without the third-party-storage redirect dependency.
// It is invoked synchronously from the user's click (no await before opening the popup).
function login(forceAccountPicker = false) {
  if (!persistenceReady) {
    window.BuzzApp?.showCloudMessage?.("Aguarde a inicialização do login Google e tente novamente.");
    return Promise.resolve(false);
  }
  if (loginInProgress) return Promise.resolve(false);
  if (currentUser && !forceAccountPicker) {
    return enqueueAuthState(currentUser).then(() => true);
  }

  loginInProgress = true;
  provider.setCustomParameters({ prompt: "select_account" });
  let signInRequest;
  try {
    signInRequest = signInWithPopup(auth, provider);
  } catch (error) {
    loginInProgress = false;
    window.BuzzApp?.showCloudMessage?.("⚠️ " + explainFirebaseError(error));
    return Promise.resolve(false);
  }

  return Promise.resolve(signInRequest)
    .then(async credential => {
      if (credential?.user) await enqueueAuthState(credential.user);
      return true;
    })
    .catch(error => {
      console.error("BuzzDataBase Google sign-in failed:", error);
      window.BuzzApp?.showCloudMessage?.("⚠️ " + explainFirebaseError(error));
      return false;
    })
    .finally(() => { loginInProgress = false; });
}

async function logout(options = {}) {
  if (logoutInProgress) return false;
  logoutInProgress = true;
  const keepCloud = options?.preserveCloud === true;
  const userAtStart = currentUser;
  try {
    // Device reset must not issue any Firestore write or delete. If a sync is already
    // running/queued, abort the reset so that the user can retry after it finishes.
    if (keepCloud && userAtStart && (syncPromise || pendingSync)) {
      throw new Error('Há uma sincronização em andamento. Aguarde a confirmação de sincronização e tente Reiniciar novamente. Nenhum dado local foi apagado.');
    }

    pendingSync = null;
    stopCloudWatcher();
    await signOut(auth);
    // Explicitly publish signed-out state as well; the observer's duplicate event is deduplicated.
    await enqueueAuthState(null);
    loginInProgress = false;
    return true;
  } catch (error) {
    console.error("BuzzDataBase Firebase sign-out failed:", error);
    if (keepCloud && userAtStart && currentUser?.uid === userAtStart.uid) startCloudWatcher(userAtStart);
    window.BuzzApp?.showCloudMessage?.(error?.message || "Não foi possível desconectar a conta. Tente novamente.");
    return false;
  } finally {
    logoutInProgress = false;
  }
}

window.BuzzFirebase = {
  firebaseConfig,
  login,
  switchAccount: () => login(true),
  logout,
  isReady: () => persistenceReady,
  getCurrentUser: () => currentUser,
  syncState,
  confirmState,
  getCloudState,
  handleLogin,
  setAuthCallback(callback) {
    authCallback = callback;
    if (authInitialized && typeof authCallback === "function") {
      return enqueueAuthState(currentUser, true);
    }
  }
};

onAuthStateChanged(auth, user => {
  enqueueAuthState(user).catch(error => console.error("BuzzDataBase auth callback failed:", error));
});

// If a device edited while offline, push its current local snapshot after the connection returns.
window.addEventListener("online", () => {
  if (!currentUser) return;
  const localState = window.BuzzApp?.getLocalCloudState?.();
  if (localState) syncState(localState, currentUser);
});

// Processa eventuais retornos de um fluxo redirect antigo usado em versões anteriores.
persistenceReadyPromise.then(() => getRedirectResult(auth)).then(result => {
  if (result?.user) return enqueueAuthState(result.user);
}).catch(error => {
  console.error("BuzzDataBase Google redirect result failed:", error);
  window.BuzzApp?.showCloudMessage?.("⚠️ " + explainFirebaseError(error));
});

window.dispatchEvent(new Event("buzzfirebase-ready"));
