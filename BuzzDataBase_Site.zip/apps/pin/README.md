# BuzzPin v0.1 — dentro do BuzzHub 1.7

O BuzzPin aparece como terceiro aplicativo na tela inicial do BuzzHub.

### Recursos disponíveis
- Adicionar imagens locais em lote.
- Visualizar as imagens em grade e selecionar individualmente.
- Exportar as selecionadas em ZIP.
- Interface responsiva com tema roxo/escuro.

### Limite desta versão
A conexão com o Pinterest ainda não está implementada. O protótipo trabalha com arquivos que o usuário seleciona no próprio aparelho. A integração futura deverá usar a API oficial, OAuth e um backend para proteger as credenciais, respeitando permissões e autorização sobre o conteúdo. Não há raspagem automatizada de páginas.

O ZIP usa JSZip via CDN; a criação do arquivo requer conexão à internet para carregar a biblioteca.
