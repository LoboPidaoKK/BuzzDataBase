/* BuzzHub 2.7 — aparência compartilhada entre o Hub e os três aplicativos. */
(() => {
  'use strict';
  const STORAGE_KEY = 'buzzhub.appearance.v1';
  const ACCENTS = {
    purple: { name: 'Roxo', main: '#a66aff', deep: '#7138ba', rgb: '166,106,255', contrast: '#ffffff' },
    blue:   { name: 'Azul', main: '#3998ff', deep: '#1761c4', rgb: '57,152,255', contrast: '#ffffff' },
    red:    { name: 'Vermelho', main: '#ff5968', deep: '#c92d43', rgb: '255,89,104', contrast: '#ffffff' },
    pink:   { name: 'Rosa', main: '#ff78c4', deep: '#cc438e', rgb: '255,120,196', contrast: '#24101c' },
    green:  { name: 'Verde', main: '#45d483', deep: '#208c58', rgb: '69,212,131', contrast: '#092316' },
    yellow: { name: 'Amarelo', main: '#f4ca46', deep: '#b68a18', rgb: '244,202,70', contrast: '#211a05' },
    orange: { name: 'Laranja', main: '#ff963d', deep: '#d26716', rgb: '255,150,61', contrast: '#261407' },
    'purple-vivid': { name: 'Roxo intenso', main: '#a020f0', deep: '#6500b5', rgb: '160,32,240', contrast: '#ffffff' },
    'blue-vivid':   { name: 'Azul intenso', main: '#006bff', deep: '#0045bd', rgb: '0,107,255', contrast: '#ffffff' },
    'red-vivid':    { name: 'Vermelho intenso', main: '#f0143d', deep: '#b9002b', rgb: '240,20,61', contrast: '#ffffff' },
    'pink-vivid':   { name: 'Rosa intenso', main: '#ff1493', deep: '#c00068', rgb: '255,20,147', contrast: '#ffffff' },
    'green-vivid':  { name: 'Verde intenso', main: '#00c853', deep: '#008f3b', rgb: '0,200,83', contrast: '#062414' },
    'yellow-vivid': { name: 'Amarelo intenso', main: '#ffd600', deep: '#e2a900', rgb: '255,214,0', contrast: '#241b00' },
    'orange-vivid': { name: 'Laranja intenso', main: '#ff6d00', deep: '#d94b00', rgb: '255,109,0', contrast: '#ffffff' }
  };

  function normalize(value) {
    const input = value && typeof value === 'object' ? value : {};
    return {
      accent: Object.prototype.hasOwnProperty.call(ACCENTS, input.accent) ? input.accent : 'purple',
      mode: ['black', 'tinted'].includes(input.mode) ? input.mode : 'dark'
    };
  }

  function read() {
    try { return normalize(JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}')); }
    catch (_) { return normalize(null); }
  }

  function hueAndSaturation(rgbText) {
    const parts = String(rgbText).split(',').map(Number);
    const [r0, g0, b0] = parts.length === 3 ? parts.map(v => v / 255) : [0.65, 0.42, 1];
    const max = Math.max(r0, g0, b0), min = Math.min(r0, g0, b0);
    const delta = max - min;
    let hue = 0;
    if (delta) {
      if (max === r0) hue = 60 * (((g0 - b0) / delta) % 6);
      else if (max === g0) hue = 60 * ((b0 - r0) / delta + 2);
      else hue = 60 * ((r0 - g0) / delta + 4);
    }
    if (hue < 0) hue += 360;
    const lightness = (max + min) / 2;
    const saturation = delta === 0 ? 0 : delta / (1 - Math.abs(2 * lightness - 1));
    return { hue: Math.round(hue), saturation: Math.round(Math.max(42, Math.min(62, saturation * 58))) };
  }

  function cssFor(theme) {
    const accent = ACCENTS[theme.accent];
    const isBlack = theme.mode === 'black';
    const isTinted = theme.mode === 'tinted';
    const tint = hueAndSaturation(accent.rgb);
    const tintColor = `hsl(${tint.hue} ${tint.saturation}%`;
    const bg = isBlack ? '#000000' : isTinted ? `${tintColor} 8%)` : '#100e15';
    const panel = isBlack ? '#050505' : isTinted ? `${tintColor} 11%)` : '#19151f';
    const panel2 = isBlack ? '#0b0b0b' : isTinted ? `${tintColor} 15%)` : '#221b29';
    const panel3 = isBlack ? '#111111' : isTinted ? `${tintColor} 19%)` : '#2a2232';
    const line = isBlack ? '#242424' : isTinted ? `${tintColor} 27%)` : '#3b3046';
    const glow = isBlack ? `hsla(${tint.hue},${tint.saturation}%,48%,.14)` : isTinted ? `hsla(${tint.hue},${tint.saturation}%,48%,.30)` : `rgba(${accent.rgb},.19)`;
    const pageBackground = isTinted
      ? `radial-gradient(ellipse at 50% -18%,hsla(${tint.hue},${tint.saturation}%,44%,.34) 0,transparent 52%),linear-gradient(145deg,${tintColor} 10%),${tintColor} 7%))`
      : isBlack ? '#000000' : `radial-gradient(ellipse at 50% -18%,${glow} 0,transparent 46%),${bg}`;
    return `
      :root {
        color-scheme: dark !important;
        --buzz-accent:${accent.main}; --buzz-accent-deep:${accent.deep};
        --buzz-accent-rgb:${accent.rgb}; --buzz-accent-glow:${glow};
        --buzz-accent-contrast:${accent.contrast};
        --buzz-page-bg:${bg}; --buzz-panel-bg:${panel}; --buzz-panel2-bg:${panel2}; --buzz-panel3-bg:${panel3};
        --bg:${bg} !important; --panel:${panel} !important; --panel2:${panel2} !important;
        --surface:${panel} !important; --surface-2:${panel2} !important; --surface-3:${panel3} !important;
        --line:${line} !important; --purple:${accent.main} !important; --purple2:${accent.deep} !important;
        --purple-2:${accent.deep} !important; --purple-glow:${glow} !important; --pink:${accent.main} !important;
        --text:${isBlack ? '#f5f5f5' : '#f5f1fa'} !important;
        --muted:${isBlack ? '#a5a5a5' : '#b6acbf'} !important;
      }
      html,body { background:${pageBackground} !important; color:var(--text) !important; }
      button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible { outline-color:var(--buzz-accent) !important; }
      .brand-name span,.hero h1 span,.eyebrow,.footer b { color:var(--buzz-accent) !important; }
      .btn.primary,.btn-primary,.primary,.save,.install-hub-btn,.action-btn.primary,#applyRestoreBtn,
      .toolbar #addItemBtn,.folder-add,.fab,.btn-camera,.pool-add-btn {
        background:linear-gradient(125deg,var(--buzz-accent),var(--buzz-accent-deep)) !important;
        border-color:var(--buzz-accent) !important; color:var(--buzz-accent-contrast) !important;
      }
      .btn:hover,.tool-btn:hover,.card:hover,.app-card:hover,.folder-mini:hover,.mini-tool:hover {
        border-color:var(--buzz-accent) !important;
      }
      .chip.active,.manual-source-filter.active,.folder-pill.active {
        background:color-mix(in srgb,var(--buzz-accent) 24%,var(--panel2)) !important;
        border-color:var(--buzz-accent) !important; color:var(--text) !important;
      }
      .manual-image-card.selected {
        border-color:var(--buzz-accent) !important;
        background:color-mix(in srgb,var(--buzz-accent) 17%,var(--panel2)) !important;
        box-shadow:0 0 0 2px color-mix(in srgb,var(--buzz-accent) 35%,transparent) !important;
      }
      .hero { border-color:color-mix(in srgb,var(--buzz-accent) 38%,var(--line)) !important;
        background:linear-gradient(115deg,color-mix(in srgb,var(--buzz-accent) 15%,var(--panel2)),var(--panel) 68%,var(--panel2)) !important; }
      .logo,.install-hub-icon,.action-btn .action-icon { background:linear-gradient(135deg,var(--buzz-accent-deep),var(--buzz-accent)) !important; }
      .btn-camera { color:var(--buzz-accent-contrast) !important; }
      .fab { box-shadow:0 10px 30px color-mix(in srgb,var(--buzz-accent) 42%,transparent),0 0 0 1px #ffffff10 inset !important; }
      .app-card,.action-btn,.progress-box,.restore-option,.restore-dialog { border-color:var(--line) !important; }
      .app-card { background:linear-gradient(145deg,var(--panel2),var(--panel)) !important; }
      .action-btn,.restore-option,.progress-box { background:var(--panel2) !important; }
      .restore-dialog,dialog,.modal,.editor-modal { background:var(--panel) !important; color:var(--text) !important; border-color:var(--line) !important; }
      .searchbox input,.search,.field,select,.tool-btn,.secondary,.folder-select,.mini-tool,.manual-source-filter {
        background-color:var(--panel2) !important; border-color:var(--line) !important; color:var(--text) !important;
      }
      .card,.manual-image-card,.pool,.tier-menu-grid,.empty,.folder-pill,.folder-section {
        border-color:var(--line) !important;
      }
      ${isTinted ? `
        html,body { background:${pageBackground} !important; }
        .home-shell,.home-content,.app-view,.app,.wrap,.shell { background:transparent !important; }
        .hero { background:linear-gradient(125deg,${tintColor} 18%),var(--panel2),var(--panel)) !important; border-color:${line} !important; }
        .stat,.card,.image-card,.list-card,.pool,.tier-menu-grid,.tier-row,.section-row,
        .folder-pill,.folder-tag,.app-card,.empty,.progress-box,.restore-option,
        .manual-image-card,.manual-source-filter,.menu-option,.tier-dropzone,.pool-empty {
          background:linear-gradient(145deg,var(--panel3),var(--panel2)) !important;
          border-color:var(--line) !important;
        }
        .stat,.section-row,.folder-pill,.folder-tag { box-shadow:0 5px 18px hsla(${tint.hue},${tint.saturation}%,30%,.10) !important; }
        .toolbar,.collection-tools,.folder-section,.topbar { border-color:var(--line) !important; }
        .field,.search,.search-wrap input,.searchbox input,select,.tool-btn,.secondary,
        .folder-select,.mini-tool,.card-actions button,.tier-menu-footer,.manual-picker-actions {
          background-color:var(--panel2) !important; border-color:var(--line) !important;
        }
      ` : ''}
      ${isBlack ? `
        html,body,.home-shell,.home-content,.app-view,.app,.wrap,.shell { background:#000000 !important; }
        .app-card,.action-btn,.progress-box,.restore-option,.restore-dialog,.hero,.stat,.chip,.card,.modal,
        dialog,.field,.searchbox input,.search,.tool-btn,.empty,.manual-image-card,.manual-source-filter,
        .pool,.tier-menu-grid,.menu-option,.tier-row,.tier-dropzone,.folder-pill,.folder-section,
        .folder-add,.card-actions button,.secondary,.toast,.manual-image-grid,.manual-picker-actions {
          background-color:#080808 !important; background-image:none !important;
        }
        .hero { border-color:#252525 !important; }
        .app-card,.action-btn,.card,.manual-image-card,.folder-pill,.empty,dialog { border-color:#252525 !important; }
        .app-icon,.brand img { background:#080808 !important; }
      ` : ''}
    `;
  }

  function apply(value) {
    const theme = normalize(value);
    let style = document.getElementById('buzz-user-theme');
    if (!style) {
      style = document.createElement('style');
      style.id = 'buzz-user-theme';
      document.head.appendChild(style);
    }
    style.textContent = cssFor(theme);
    document.documentElement.dataset.buzzAccent = theme.accent;
    document.documentElement.dataset.buzzMode = theme.mode;
    const themeColor = document.querySelector('meta[name="theme-color"]');
    if (themeColor) { const accent = ACCENTS[theme.accent]; const tint = hueAndSaturation(accent.rgb); themeColor.setAttribute('content', theme.mode === 'black' ? '#000000' : theme.mode === 'tinted' ? `hsl(${tint.hue} ${tint.saturation}% 8%)` : '#100e15'); }
    return theme;
  }

  window.BuzzTheme = {
    storageKey: STORAGE_KEY,
    accents: ACCENTS,
    read,
    apply,
    save(value) {
      const theme = normalize(value);
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(theme)); } catch (_) {}
      apply(theme);
      document.querySelectorAll('iframe').forEach(frame => {
        try { frame.contentWindow?.postMessage({ type: 'BUZZHUB_THEME', theme }, location.origin); } catch (_) {}
      });
      return theme;
    }
  };

  apply(read());
  window.addEventListener('storage', event => {
    if (event.key === STORAGE_KEY) apply(read());
  });
  window.addEventListener('message', event => {
    if (event.origin !== location.origin || event.data?.type !== 'BUZZHUB_THEME') return;
    apply(event.data.theme);
  });
})();
