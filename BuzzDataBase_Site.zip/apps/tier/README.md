# BuzzTier — BuzzHub 2.0 local

O BuzzTier cria Tier Lists, Ranking Lists e comparações entre imagens. As listas e imagens são salvas localmente neste navegador/aparelho.

Use **Backup** para exportar um JSON do BuzzTier e **Restaurar** para importar um backup. O BuzzHub também oferece um backup combinado dos aplicativos.

Não há login, contas, Firebase, sincronização automática ou nuvem nesta versão. Exporte backups periodicamente e guarde-os fora do aparelho.

MIGRAÇÃO DE DADOS NA NUVEM
A versão 2.0 não acessa nem importa dados que existam somente na antiga nuvem. Ela também não envia comandos para apagar esses dados remotos. Antes de publicar a versão 2.0, abra a versão antiga e exporte os backups disponíveis. Se algum conteúdo existir apenas na nuvem e não estiver presente no armazenamento local ou nos arquivos exportados, ele não aparecerá na versão 2.0.


BUZZHUB — MODO 1V1
No BuzzHub, a quarta opção de criação é 1v1 manual. Escolha duas imagens vindas do BuzzDataBase, BuzzTier ou capas do BuzzLinks. Ao votar, a vencedora fica destacada em verde e um PNG comparativo é baixado automaticamente.

BUZZTIER 1V1 — ATUALIZAR CATÁLOGO
- No modo 1v1, arraste a tela para baixo a partir do topo e solte.
- O catálogo é consultado novamente nos três aplicativos do BuzzHub.
- A lista e os contadores dos filtros são atualizados sem fechar o modo 1v1.
- Seleções ainda disponíveis são preservadas; um confronto em andamento permanece na tela.
