# BuzzTier v1.23

O BuzzTier é o aplicativo de Tier Lists e Ranking Lists integrado ao BuzzHub. Nesta instalação ele fica em `apps/tier/`.

## Novidades v1.23
- Seleção de imagens compatível com o gerenciador de arquivos do Android, inclusive arquivos com MIME genérico ou ausente; o tipo é reconhecido pela extensão e, quando necessário, pelo cabeçalho.
- Rota e lista atual preservadas antes de abrir o seletor de arquivos. O Hub tenta restaurar o último aplicativo se o Android recriar a página.
- Importações em lote salvam checkpoints locais a cada três imagens e agrupam a sincronização na nuvem para evitar uma gravação por imagem.
- Consultas aos blocos do Firestore são agrupadas em lotes de até 30 IDs, com concorrência limitada para poupar memória.
- Manifestos novos usam hashes para reaproveitar blocos idênticos. Confirmações sem alterações não regravam a nuvem.
- A confirmação evita leituras redundantes do manifesto e remove blocos antigos em segundo plano, mantendo a validação transacional.

## Recursos mantidos
- Tier Lists tradicionais, com níveis, cores, imagens e rodapé.
- Ranking Lists em modo compacto ou visual.
- Ordenação por arrastar, capas personalizadas e screenshot PNG com largura ajustável.
- Backup JSON e armazenamento local no IndexedDB.
- Compatibilidade com manifestos e dados antigos do BuzzTier.

## Publicar no BuzzHub
1. Exporte um backup JSON pelo BuzzHub antes de atualizar.
2. Extraia o ZIP completo do BuzzHub na raiz do repositório `BuzzDataBase`, mantendo `apps/tier/` e `apps/database/`.
3. Publique pelo GitHub Pages.
4. Feche e abra novamente o BuzzHub para instalar a nova versão do Service Worker.

Não publique esta pasta como substituta da raiz do BuzzHub e não use o workflow antigo do site independente do BuzzTier para atualizar esta instalação. Não limpe os dados do navegador nem o IndexedDB.

## Armazenamento
As listas e imagens locais ficam no IndexedDB. A sincronização Firebase fica separada por UID em `users/{uid}/apps/buzztier`; o login é compartilhado com o BuzzDataBase, mas as coleções não são misturadas.

Feito com 💜 por Mika · BuzzTier v1.23
