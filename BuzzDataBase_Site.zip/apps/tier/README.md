<div align="center">
  <img src="icon.png" alt="Ícone do BuzzTier" width="112" height="112" />
  <h1>BuzzTier v1.21</h1>
  <p><strong>Rank · Organize · Compare</strong></p>
  <p>Crie Tier Lists tradicionais e Ranking Lists com imagens, nomes e posições reordenáveis.</p>
</div>

---

## Novidades da versão 1.21

- **Esse ou Esse também inclui as imagens do rodapé.** Quando uma Tier List está com o botão Esse ou Esse ativado, entram na disputa tanto as imagens classificadas nos níveis quanto as imagens ainda não classificadas que permanecem no rodapé.
- As imagens do rodapé são identificadas como **Rodapé** na comparação e no PNG gerado automaticamente.
- Capas e imagens de Ranking Lists continuam fora do sorteio. Tier Lists com Esse ou Esse desligado também não participam.

## Recursos mantidos na v1.21

- **Criar Tier Comum:** mantém o editor tradicional de níveis, imagens e cores.
- **Criar Ranking List:** cada entrada tem imagem, nome e posição numerada automaticamente.
- **Dois modos de Ranking List:** compacto ou visual, com imagem grande e nome abaixo. A preferência é salva por lista.
- **Ordenação:** arraste itens para mudar suas posições; a numeração é recalculada automaticamente.
- **Capas personalizadas:** escolha capas para cada lista, sem selo redundante sobre a imagem.
- **Bandeja expandível:** imagens não classificadas em grade de cinco colunas e rolagem vertical.
- **Screenshot PNG:** a exportação permite escolher de 3 a 15 imagens por linha.
- **Backup e restauração:** listas e imagens são armazenadas no IndexedDB local.
- **PWA:** instalável pelo navegador e com cache offline após a primeira visita.

## Publicar no GitHub Pages usando somente BuzzTier.zip

O repositório pode manter o site compactado em um único arquivo na raiz. O workflow `.github/workflows/deploy.yml` extrai o ZIP, valida a versão, publica o site e gera um artefato ZIP da versão.

### Atualizar o site

1. Faça um backup JSON das listas antes de trocar a versão.
2. Substitua `BuzzTier.zip` na raiz do repositório pelo pacote v1.21.
3. Substitua também `.github/workflows/deploy.yml` pelo workflow que acompanha esta versão.
4. Atualize o `README.md` da raiz, se quiser manter a documentação do repositório alinhada.
5. Faça commit na branch `main`.
6. Em **Settings → Pages → Build and deployment → Source**, confirme **GitHub Actions**.
7. Abra **Actions** e confira a execução **Gerar ZIP e publicar Buzz-Tier**. Os trabalhos de preparação e publicação devem terminar com sucesso.
8. O artefato `BuzzTier-v1.21-ZIP` fica disponível na seção *Artifacts* da execução.

O site será publicado em:

`https://lobopidaokk.github.io/Buzz-Tier/`

## Seus dados

As listas ficam no IndexedDB do navegador/dispositivo. O GitHub Pages não sincroniza os dados entre aparelhos. Não limpe os dados do navegador para atualizar o site; use Backup JSON antes de atualizar ou trocar de dispositivo.

As listas antigas sem o campo `kind` continuam sendo interpretadas como Tier Lists comuns.

---

Feito com 💜 por Mika · BuzzTier v1.21

## Retomada de importação integrada ao BuzzHub v1.7

- O BuzzTier guarda a Tier List aberta e a posição da tela para retomar após o Android suspender ou recriar a página.
- Durante a seleção em massa, cada imagem que termina de ser processada é registrada em um armazenamento temporário do IndexedDB. Se o processo for encerrado antes do fim, essas imagens são incorporadas à lista na próxima inicialização.
- O armazenamento temporário é associado ao UID da conta Google quando disponível, para não misturar checkpoints entre contas.
- O IndexedDB é atualizado da versão 2 para a 3 sem apagar as listas ou as imagens já existentes.

O navegador não permite que um PWA impeça o Android de suspender/encerrar o processo. A recuperação preserva a tela e as imagens que já foram lidas pelo navegador; os arquivos que ainda não chegaram ao evento de seleção podem precisar ser selecionados novamente.
