const CACHE_NAME = 'buzzhub-tier-v2-2-local';
const APP_FILES = ['./', './index.html', './icon.png', './icon-192.png', './icon-maskable.png', './manifest.webmanifest'];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_FILES)).then(() => self.skipWaiting())));
self.addEventListener('activate', event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('buzzhub-tier-') && key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim())));
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;
  const isPage = event.request.mode === 'navigate' || /\/index\.html$/.test(url.pathname);
  if (isPage) {
    event.respondWith((async () => {
      try { const response = await fetch(event.request, {cache:'no-store'}); if (response?.ok) caches.open(CACHE_NAME).then(cache => cache.put(event.request,response.clone())).catch(()=>{}); return response; }
      catch (_) { return (await caches.match(event.request)) || (await caches.match('./index.html')); }
    })());
    return;
  }
  event.respondWith((async () => {
    const cached = await caches.match(event.request);
    if (cached) return cached;
    try { const response = await fetch(event.request); if (response?.ok) caches.open(CACHE_NAME).then(cache => cache.put(event.request,response.clone())).catch(()=>{}); return response; }
    catch (_) { return caches.match('./index.html'); }
  })());
});
