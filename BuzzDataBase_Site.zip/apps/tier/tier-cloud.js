import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/13.1.0/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-auth.js";
import {
  getFirestore,
  doc,
  collection,
  getDocFromServer,
  getDocsFromServer,
  query,
  where,
  setDoc,
  writeBatch,
  runTransaction,
  onSnapshot,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-firestore.js";

// Uses the same Firebase project and browser-persistent Google session as BuzzDataBase.
const firebaseConfig = {
  apiKey: "AIzaSyCwZ7b0jcJbkPr-ZITmuLNOw3CgNYqV7-4",
  authDomain: "buzzdatabase0.firebaseapp.com",
  projectId: "buzzdatabase0",
  storageBucket: "buzzdatabase0.firebasestorage.app",
  messagingSenderId: "960232212219",
  appId: "1:960232212219:web:a7309f66eb1daa4bbe125e",
  measurementId: "G-Z6VDBNRKF4"
};

const app = getApps().find(candidate => candidate.name === "[DEFAULT]") || initializeApp(firebaseConfig);
const auth = getAuth(app);
const firestore = getFirestore(app);
const CHUNK_SIZE_BYTES = 750000; // 750 KB UTF-8 payload leaves headroom under Firestore's 1 MiB document limit
const BATCH_LIMIT = 10; // at most ~7.5 MB per batch, below Firestore's 10 MiB request limit

const HUB_STORAGE_PREFIX = 'buzzhub_';
let currentUser = null;
let lastSnapshotId = null;
let syncAllowed = false;
let applyingCloud = false;
let syncing = false;
let syncPromise = null;
let syncTimer = null;
let cloudUnsubscribe = null;
let authEventVersion = 0;
let localOwnerUid = safeLocalGet('buzztier_cloud_owner_uid');
let localDirty = safeLocalGet('buzztier_cloud_dirty') === '1';
let localSyncError = '';
let syncAgain = false;

function storageKey(key) { return `${HUB_STORAGE_PREFIX}${key}`; }
function safeLocalGet(key) {
  try {
    let scoped=localStorage.getItem(storageKey(key));
    if(scoped!==null)return scoped;
    // Migrate both v1.6 Hub flags together, once. The old keys are shared
    // with standalone BuzzTier on this GitHub Pages origin; don't re-import
    // them after reset or after the standalone app changes them.
    const marker='buzzhub_tier_keys_migrated_v17';
    if(localStorage.getItem(marker)!=='1'){
      for(const legacyKey of ['buzztier_cloud_owner_uid','buzztier_cloud_dirty']){
        const newKey=storageKey(legacyKey);
        if(localStorage.getItem(newKey)===null){
          const legacy=localStorage.getItem(legacyKey);
          if(legacy!==null)localStorage.setItem(newKey,legacy);
        }
      }
      localStorage.setItem(marker,'1');
    }
    scoped=localStorage.getItem(storageKey(key));
    return scoped===null?'':scoped;
  } catch (_) { return ''; }
}
function safeLocalSet(key,value){try{localStorage.setItem(storageKey(key),value);}catch(_){}}
function safeLocalRemove(key){try{localStorage.removeItem(storageKey(key));}catch(_){}}
function status(message, kind = 'info') {
  try { window.parent?.BuzzHub?.setAppStatus?.('tier', String(message), kind); } catch (_) {}
  try { window.dispatchEvent(new CustomEvent('buzztier-cloud-status', { detail: { message, kind } })); } catch (_) {}
}
function progress(percent, message) {
  try { window.parent?.BuzzHub?.setConfirmProgress?.(percent, message); } catch (_) {}
  try { window.dispatchEvent(new CustomEvent('buzztier-cloud-progress', { detail: { percent, message } })); } catch (_) {}
}
function manifestRef(uid = currentUser?.uid) { return doc(firestore, 'users', uid, 'apps', 'buzztier'); }
function chunksRef(uid = currentUser?.uid) { return collection(firestore, 'users', uid, 'apps', 'buzztier', 'chunks'); }
function cloneState(value) { return JSON.parse(JSON.stringify(value || { schema: 2, lists: [] })); }


// Cache local separado por app e UID: uma conta não herda listas de outra.
const ACCOUNT_CACHE_DB = 'BuzzHubAccountCacheDB';
const ACCOUNT_CACHE_STORE = 'snapshots';
let accountCacheDbPromise = null;
function openAccountCacheDb() {
  if (accountCacheDbPromise) return accountCacheDbPromise;
  accountCacheDbPromise = new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) { reject(new Error('IndexedDB não está disponível para separar as listas por conta.')); return; }
    const request = indexedDB.open(ACCOUNT_CACHE_DB, 1);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(ACCOUNT_CACHE_STORE)) database.createObjectStore(ACCOUNT_CACHE_STORE, { keyPath: 'id' });
    };
    request.onsuccess = () => {
      const database = request.result;
      database.onversionchange = () => database.close();
      resolve(database);
    };
    request.onerror = () => reject(request.error || new Error('Não foi possível abrir o cache separado por conta.'));
    request.onblocked = () => console.warn('BuzzHub: aguardando outra aba terminar de inicializar o cache de contas.');
  }).catch(error => { accountCacheDbPromise = null; throw error; });
  return accountCacheDbPromise;
}
async function saveAccountCache(uid, state, dirty, snapshotId) {
  if (!uid || !state) return false;
  // Preserve each account's last local state even if it was marked clean.
  // A clean marker is not proof that the remote manifest is still complete.
  const database = await openAccountCacheDb();
  const snapshot = {
    id: `buzzhub-buzztier:${uid}`,
    app: 'buzzhub-buzztier',
    uid,
    state: cloneState(state),
    dirty: dirty === true,
    snapshotId: snapshotId || null,
    savedAt: Date.now()
  };
  await new Promise((resolve, reject) => {
    const tx = database.transaction(ACCOUNT_CACHE_STORE, 'readwrite');
    tx.objectStore(ACCOUNT_CACHE_STORE).put(snapshot);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error || new Error('Não foi possível preservar o cache local desta conta.'));
    tx.onabort = () => reject(tx.error || new Error('A gravação do cache local desta conta foi cancelada.'));
  });
  return true;
}
async function readAccountCache(uid) {
  if (!uid) return null;
  const database = await openAccountCacheDb();
  return await new Promise((resolve, reject) => {
    const tx = database.transaction(ACCOUNT_CACHE_STORE, 'readonly');
    const store = tx.objectStore(ACCOUNT_CACHE_STORE);
    const request = store.get(`buzzhub-buzztier:${uid}`);
    request.onsuccess = () => {
      if (request.result) { resolve(request.result); return; }
      // v1.6 used an unscoped cache key. Read it as a migration source, but
      // do not remove it until the account's restore/confirmation succeeds.
      const legacy = store.get(`buzztier:${uid}`);
      legacy.onsuccess = () => resolve(legacy.result || null);
      legacy.onerror = () => reject(legacy.error || new Error('Não foi possível ler o cache antigo desta conta.'));
    };
    request.onerror = () => reject(request.error || new Error('Não foi possível ler o cache local desta conta.'));
  });
}

async function deleteAccountCache(uid) {
  if (!uid) return false;
  const database = await openAccountCacheDb();
  await new Promise((resolve, reject) => {
    const tx = database.transaction(ACCOUNT_CACHE_STORE, 'readwrite');
    tx.objectStore(ACCOUNT_CACHE_STORE).delete(`buzzhub-buzztier:${uid}`);
    tx.objectStore(ACCOUNT_CACHE_STORE).delete(`buzztier:${uid}`);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error || new Error('Não foi possível remover o cache local desta conta.'));
    tx.onabort = () => reject(tx.error || new Error('A remoção do cache local desta conta foi cancelada.'));
  });
  return true;
}

async function clearAccountCache() {
  const database = await openAccountCacheDb();
  await new Promise((resolve, reject) => {
    const tx = database.transaction(ACCOUNT_CACHE_STORE, 'readwrite');
    const store = tx.objectStore(ACCOUNT_CACHE_STORE);
    const request = store.openCursor();
    request.onsuccess = () => {
      const cursor = request.result;
      if (!cursor) return;
      if (cursor.value?.app === 'buzzhub-buzztier') cursor.delete();
      cursor.continue();
    };
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error || new Error('Não foi possível limpar os caches locais do BuzzTier.'));
    tx.onabort = () => reject(tx.error || new Error('A limpeza dos caches locais do BuzzTier foi cancelada.'));
  });
  return true;
}
function currentState() {
  const state = window.BuzzTierBridge?.getBackupState?.();
  return state && Array.isArray(state.lists) ? state : { schema: 2, lists: [] };
}
function hasLocalData(state = currentState()) { return Array.isArray(state?.lists) && state.lists.length > 0; }
function sameState(left, right) {
  try { return JSON.stringify(cloneState(left)) === JSON.stringify(cloneState(right)); }
  catch (_) { return false; }
}
function setOwner(uid) {
  localOwnerUid = uid || '';
  if (uid) safeLocalSet('buzztier_cloud_owner_uid', uid);
  else safeLocalRemove('buzztier_cloud_owner_uid');
}
function setDirty(value) {
  localDirty = !!value;
  safeLocalSet('buzztier_cloud_dirty', localDirty ? '1' : '0');
}
function stopWatcher(resetSnapshot = false) {
  if (typeof cloudUnsubscribe === 'function') {
    try { cloudUnsubscribe(); } catch (error) { console.warn('BuzzTier: erro ao encerrar o observador da nuvem.', error); }
  }
  cloudUnsubscribe = null;
  if (resetSnapshot) lastSnapshotId = null;
}
function isQuotaError(error) {
  const code = String(error?.code || '').toLowerCase();
  const message = String(error?.message || '').toLowerCase();
  return code.includes('resource-exhausted') || code.includes('quota-exceeded') || message.includes('quota exceeded');
}

function failMessage(error) {
  const code = String(error?.code || '').toLowerCase();
  if (code.includes('permission-denied')) return 'O Firestore recusou o acesso ao espaço independente do BuzzTier. Confira as regras users/{uid}/{path=**}.';
  if (code.includes('unauthorized-domain')) return 'O domínio do BuzzHub não está autorizado no Firebase Authentication.';
  if (isQuotaError(error)) return 'A cota diária do Firestore foi atingida. Seus dados continuam neste aparelho; a sincronização foi pausada para evitar novas tentativas.';
  if (code.includes('unavailable') || code.includes('network')) return 'Sem conexão com o Firestore. As alterações continuam salvas neste aparelho.';
  return error?.message || 'Não foi possível sincronizar o BuzzTier com a nuvem.';
}

// New versions store an explicit list of chunk document IDs in the manifest.
// The legacy snapshotId/index format remains readable for existing BuzzHub backups.
async function loadManifestChunks(uid, manifest, onProgress = null) {
  const chunkCount = Math.max(0, Number(manifest?.chunkCount) || 0);
  if (!chunkCount) throw new Error('O estado salvo do BuzzTier está incompleto. Seus dados locais não foram alterados.');

  let ids = [];
  let docs = [];
  if (Array.isArray(manifest.chunkIds) && manifest.chunkIds.length === chunkCount && manifest.chunkIds.every(id => typeof id === 'string' && id.length > 0)) {
    ids = manifest.chunkIds.slice();
    const batchSize = 12;
    for (let offset = 0; offset < ids.length; offset += batchSize) {
      const batchIds = ids.slice(offset, offset + batchSize);
      const batchDocs = await Promise.all(batchIds.map(id => getDocFromServer(doc(chunksRef(uid), id))));
      docs.push(...batchDocs);
      const loaded = Math.min(ids.length, offset + batchDocs.length);
      if (typeof onProgress === 'function') onProgress(Math.round((loaded / ids.length) * 100), `Baixando blocos do BuzzTier (${loaded}/${ids.length})…`);
    }
  } else {
    const snapshotId = String(manifest.snapshotId || '');
    if (!snapshotId) throw new Error('O estado salvo do BuzzTier está incompleto. Seus dados locais não foram alterados.');
    const snapshot = await getDocsFromServer(query(chunksRef(uid), where('snapshotId', '==', snapshotId)));
    const orderedDocs = new Array(chunkCount);
    for (const document of snapshot.docs) {
      const index = Number(document.data()?.index);
      if (Number.isInteger(index) && index >= 0 && index < chunkCount) orderedDocs[index] = document;
    }
    docs = orderedDocs;
    ids = orderedDocs.map(document => document?.id || '');
    if (typeof onProgress === 'function') onProgress(100, `Blocos antigos do BuzzTier recebidos (${snapshot.size})…`);
  }

  const parts = new Array(chunkCount);
  for (let index = 0; index < chunkCount; index++) {
    const document = docs[index];
    if (!document || !document.exists()) throw new Error('A nuvem não entregou todos os blocos do BuzzTier. Nada foi substituído neste aparelho.');
    const value = document.data() || {};
    if (typeof value.data !== 'string') throw new Error('A nuvem não entregou todos os blocos do BuzzTier. Nada foi substituído neste aparelho.');
    parts[index] = value.data;
  }
  if (ids.some(id => !id)) throw new Error('A nuvem não entregou todos os blocos do BuzzTier. Nada foi substituído neste aparelho.');
  return { parts, ids, docs };
}

async function readCloudSnapshot(uid = currentUser?.uid, onProgress = null) {
  if (!uid) throw new Error('Nenhuma conta Google conectada.');
  if (typeof onProgress === 'function') onProgress(5, 'Consultando o backup do BuzzTier no Firebase…');
  const manifestSnapshot = await getDocFromServer(manifestRef(uid));
  if (!manifestSnapshot.exists()) {
    if (typeof onProgress === 'function') onProgress(100, 'Esta conta ainda não tem um backup do BuzzTier.');
    return { exists: false, state: null, snapshotId: null, manifest: null, chunkIds: [], chunkParts: [] };
  }
  const manifest = manifestSnapshot.data() || {};
  const snapshotId = String(manifest.snapshotId || '');
  if (!snapshotId) throw new Error('O estado salvo do BuzzTier está incompleto. Seus dados locais não foram alterados.');
  const declaredChunks = Math.max(0, Number(manifest.chunkCount) || 0);
  // Some older builds left a valid manifest document for an empty collection
  // with zero chunks. Read it as an empty snapshot so Confirmar Estado can
  // replace it with the current lists instead of failing before the upload.
  if (declaredChunks === 0 && Number(manifest.listCount) === 0) {
    if (typeof onProgress === 'function') onProgress(100, 'A nuvem contém um manifesto vazio; pronto para receber o estado atual.');
    return { exists: true, state: { schema: 2, lists: [] }, snapshotId, manifest, chunkIds: [], chunkParts: [] };
  }
  if (typeof onProgress === 'function') onProgress(15, `Backup encontrado: ${declaredChunks} blocos. Iniciando leitura…`);

  const loaded = await loadManifestChunks(uid, manifest, (percent, message) => {
    if (typeof onProgress === 'function') onProgress(15 + Math.round(percent * 0.72), message);
  });
  if (typeof onProgress === 'function') onProgress(91, 'Montando as listas e imagens recebidas…');
  const json=loaded.parts.join('');
  if(Number.isFinite(Number(manifest.jsonLength))&&Number(manifest.jsonLength)>0&&json.length!==Number(manifest.jsonLength))throw new Error(`O backup do BuzzTier está incompleto: o manifesto esperava ${Number(manifest.jsonLength)} caracteres, mas chegaram ${json.length}. O armazenamento local não foi alterado.`);
  let state;try{state=JSON.parse(json);}catch(error){throw new Error(`Os blocos chegaram, mas o JSON do BuzzTier está corrompido (${error?.message||'erro de leitura'}). O armazenamento local não foi alterado.`);}
  if(!state||!Array.isArray(state.lists))throw new Error('A estrutura da cópia do BuzzTier na nuvem é inválida.');
  if(Number.isFinite(Number(manifest.listCount))&&state.lists.length!==Number(manifest.listCount))throw new Error(`O manifesto informa ${Number(manifest.listCount)} listas, mas o backup contém ${state.lists.length}. O armazenamento local não foi alterado.`);
  if(typeof onProgress==='function')onProgress(95,`${state.lists.length} listas recebidas e verificadas. Aplicando ao aplicativo…`);
  return { exists: true, state, snapshotId, manifest, chunkIds: loaded.ids, chunkParts: loaded.parts };
}

function utf8ByteLengthAt(json, index) {
  const point = json.codePointAt(index);
  if (point <= 0x7F) return 1;
  if (point <= 0x7FF) return 2;
  if (point <= 0xFFFF) return 3;
  return 4;
}

function splitJson(json) {
  const parts = [];
  let start = 0;
  let offset = 0;
  let bytes = 0;
  while (offset < json.length) {
    const point = json.codePointAt(offset);
    const chars = point > 0xFFFF ? 2 : 1;
    const nextBytes = utf8ByteLengthAt(json, offset);
    if (bytes + nextBytes > CHUNK_SIZE_BYTES && offset > start) {
      parts.push(json.slice(start, offset));
      start = offset;
      bytes = 0;
    }
    bytes += nextBytes;
    offset += chars;
  }
  if (start < json.length) parts.push(json.slice(start));
  return parts.length ? parts : ['{"schema":2,"lists":[]}'];
}

async function sweepAbandonedChunks(uid, activeChunkIds) {
  const key = `buzztier_orphan_sweep_${uid}`;
  const lastSweep = Number(safeLocalGet(key)) || 0;
  if (Date.now() - lastSweep < 24 * 60 * 60 * 1000) return;
  const cutoff = Date.now() - 30 * 60 * 1000;
  const snapshot = await getDocsFromServer(chunksRef(uid));
  const staleDocs = snapshot.docs.filter(document => {
    if (activeChunkIds.has(document.id)) return false;
    const createdAt = Number(document.data()?.createdAt) || 0;
    return createdAt > 0 && createdAt < cutoff;
  });
  for (let start = 0; start < staleDocs.length; start += 400) {
    const batch = writeBatch(firestore);
    for (const document of staleDocs.slice(start, start + 400)) batch.delete(document.ref);
    await batch.commit();
  }
  safeLocalSet(key, String(Date.now()));
}

async function writeCloudSnapshot(state, { force = false, onProgress = null, expectedSnapshotId: expectedOverride, previousSnapshot = null } = {}) {
  const user = currentUser;
  if (!user) throw new Error('Entre com sua conta Google antes de salvar o BuzzTier na nuvem.');
  const uid = user.uid;
  const manifestBefore = await getDocFromServer(manifestRef(uid));
  const manifestData = manifestBefore.exists() ? (manifestBefore.data() || {}) : null;
  const remoteBefore = { exists: manifestBefore.exists(), snapshotId: manifestBefore.exists() ? String(manifestData?.snapshotId || '') || null : null };
  if (expectedOverride !== undefined && remoteBefore.snapshotId !== expectedOverride) throw new Error('A cópia do BuzzTier na nuvem mudou depois da sua revisão. Leia a versão mais recente e confirme novamente.');
  if (!force && remoteBefore.exists && remoteBefore.snapshotId !== lastSnapshotId) {
    syncAllowed = false;
    throw new Error('A nuvem do BuzzTier foi atualizada em outro dispositivo. Para evitar sobrescrever dados mais recentes, use “Confirmar Estado” depois de conferir suas listas.');
  }
  if (!force && !remoteBefore.exists && lastSnapshotId) {
    syncAllowed = false;
    throw new Error('A cópia do BuzzTier na nuvem mudou ou foi removida. Use “Confirmar Estado” para decidir o que salvar.');
  }

  let previousParts = null;
  let previousIds = [];
  if (remoteBefore.exists && remoteBefore.snapshotId) {
    if (previousSnapshot?.exists && previousSnapshot.snapshotId === remoteBefore.snapshotId && Array.isArray(previousSnapshot.chunkParts) && Array.isArray(previousSnapshot.chunkIds)) {
      previousParts = previousSnapshot.chunkParts;
      previousIds = previousSnapshot.chunkIds;
    } else {
      const loadedPrevious = await loadManifestChunks(uid, manifestData);
      previousParts = loadedPrevious.parts;
      previousIds = loadedPrevious.ids;
    }
  }

  // Remove abandoned upload fragments from earlier failed attempts, but never touch
  // chunks referenced by the currently published manifest or anything newer than 30 min.
  try { await sweepAbandonedChunks(uid, new Set(previousIds)); }
  catch (cleanupError) { console.warn('BuzzTier: limpeza de blocos abandonados adiada.', cleanupError); }

  const stableState = cloneState(state);
  const json = JSON.stringify(stableState);
  // Firestore document/request limits are handled by 750 KB chunks and batches
  // of 10 documents. The old 30 MB cutoff was an arbitrary application limit
  // and rejected valid backups before the first upload. Keep a generous guard
  // only to avoid exhausting memory in a mobile browser while serializing.
  const approximateMB = json.length / (1024 * 1024);
  const MAX_SNAPSHOT_JSON_CHARS = 100_000_000;
  if (json.length > MAX_SNAPSHOT_JSON_CHARS) {
    throw new Error(`O estado do BuzzTier tem aproximadamente ${approximateMB.toFixed(1)} MB e ultrapassa o limite de segurança de 100 MB deste navegador. Nenhum bloco novo foi enviado; seus dados locais continuam preservados.`);
  }
  const parts = splitJson(json);
  let embeddedImageCount = 0;
  const countEmbeddedImages = value => {
    if (typeof value === 'string') { if (value.startsWith('data:image/')) embeddedImageCount++; return; }
    if (Array.isArray(value)) { for (const item of value) countEmbeddedImages(item); return; }
    if (value && typeof value === 'object') { for (const item of Object.values(value)) countEmbeddedImages(item); }
  };
  countEmbeddedImages(stableState);
  const preparingMessage = `Backup do BuzzTier: ${approximateMB.toFixed(1)} MB · ${embeddedImageCount} imagens · ${parts.length} blocos.`;
  if (typeof onProgress === 'function') onProgress(2, preparingMessage);
  else progress(2, preparingMessage);
  const snapshotId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  const nextChunkIds = new Array(parts.length);
  const changedIndexes = [];
  for (let index = 0; index < parts.length; index++) {
    if (previousParts && previousParts[index] === parts[index] && previousIds[index]) {
      // Reuse identical chunk documents instead of writing the whole collection again.
      nextChunkIds[index] = previousIds[index];
    } else {
      nextChunkIds[index] = `${snapshotId}_${String(index).padStart(5, '0')}`;
      changedIndexes.push(index);
    }
  }

  let completed = 0;
  for (let start = 0; start < changedIndexes.length; start += BATCH_LIMIT) {
    if (currentUser?.uid !== uid) throw new Error('A conta Google mudou antes da gravação do BuzzTier terminar.');
    const indexes = changedIndexes.slice(start, start + BATCH_LIMIT);
    const batch = writeBatch(firestore);
    for (const index of indexes) {
      batch.set(doc(chunksRef(uid), nextChunkIds[index]), { snapshotId, index, data: parts[index], createdAt: Date.now() });
    }
    await batch.commit();
    completed += indexes.length;
    const percent = Math.min(88, Math.round((completed / changedIndexes.length) * 88));
    const message = `Enviando BuzzTier (${completed}/${changedIndexes.length} blocos alterados; ${parts.length - changedIndexes.length} reaproveitados)…`;
    if (typeof onProgress === 'function') onProgress(percent, message);
    else progress(percent, message);
  }
  if (!changedIndexes.length) {
    const message = `Os ${parts.length} blocos já estão iguais; atualizando somente o registro da nuvem…`;
    if (typeof onProgress === 'function') onProgress(88, message);
    else progress(88, message);
  }

  // Publish the new manifest only after all changed blocks have been written.
  if (currentUser?.uid !== uid) throw new Error('A conta Google mudou antes de publicar o estado do BuzzTier.');
  const expectedSnapshotId = remoteBefore.snapshotId || null;
  if (typeof onProgress === 'function') onProgress(92, 'Publicando o estado confirmado no Firestore…');
  else progress(92, 'Publicando o estado confirmado no Firestore…');
  await runTransaction(firestore, async transaction => {
    const latest = await transaction.get(manifestRef(uid));
    const latestId = latest.exists() ? String(latest.data()?.snapshotId || '') || null : null;
    if (latestId !== expectedSnapshotId) throw new Error('Outro dispositivo atualizou o BuzzTier durante o envio. Os blocos locais não foram publicados; confira a nuvem e tente novamente.');
    if (currentUser?.uid !== uid) throw new Error('A conta Google mudou antes de publicar o estado do BuzzTier.');
    transaction.set(manifestRef(uid), {
      schema: 2,
      appVersion: '1.21',
      snapshotId,
      chunkCount: parts.length,
      chunkIds: nextChunkIds,
      listCount: stableState.lists.length,
      jsonLength: json.length,
      updatedAt: serverTimestamp()
    });
  });
  lastSnapshotId = snapshotId;
  setOwner(uid);
  setDirty(false);

  // Delete only chunks that are no longer referenced by the newly published manifest.
  // Identical chunks can be shared by successive snapshots and must remain intact.
  try {
    const activeIds = new Set(nextChunkIds);
    const obsoleteIds = [...new Set(previousIds)].filter(id => id && !activeIds.has(id));
    for (let start = 0; start < obsoleteIds.length; start += BATCH_LIMIT) {
      const batch = writeBatch(firestore);
      for (const id of obsoleteIds.slice(start, start + BATCH_LIMIT)) batch.delete(doc(chunksRef(uid), id));
      await batch.commit();
    }
  } catch (cleanupError) {
    console.warn('BuzzTier: a nova cópia foi publicada, mas alguns blocos sem uso ficaram para limpeza posterior.', cleanupError);
  }
  if (typeof onProgress === 'function') onProgress(100, 'BuzzTier confirmado na nuvem.');
  else progress(100, 'BuzzTier confirmado na nuvem.');
  return { ok: true, snapshotId, listCount: stableState.lists.length, chunkCount: parts.length, changedChunkCount: changedIndexes.length };
}

async function applyRemote(remote, uid, onProgress = null) {
  if (currentUser?.uid !== uid) return false;
  if (typeof onProgress === 'function') onProgress(96, 'Aplicando as listas e capas no BuzzTier…');
  await window.BuzzTierBridge.applyCloudState(remote.state);
  if (currentUser?.uid !== uid) return false;
  setOwner(uid);
  setDirty(false);
  syncAllowed = true;
  lastSnapshotId = remote.snapshotId;
  status(`BuzzTier sincronizado: ${remote.state.lists.length} listas carregadas da nuvem.`, 'success');
  if (typeof onProgress === 'function') onProgress(100, 'Backup do BuzzTier atualizado.');
  return true;
}

function startWatcher(uid) {
  stopWatcher(false);
  const version = ++authEventVersion;
  cloudUnsubscribe = onSnapshot(manifestRef(uid), async snapshot => {
    if (currentUser?.uid !== uid || version !== authEventVersion) return;
    if (!snapshot.exists()) return;
    const nextId = String(snapshot.data()?.snapshotId || '');
    if (!nextId || nextId === lastSnapshotId || syncing) return;
    if (localDirty) {
      syncAllowed = false;
      status('O BuzzTier foi alterado em outro dispositivo. Suas alterações locais foram preservadas; use “Confirmar Estado” depois de conferir as listas.', 'warning');
      return;
    }
    try {
      const remote = await readCloudSnapshot(uid);
      if (remote.exists && remote.snapshotId !== lastSnapshotId && !localDirty && currentUser?.uid === uid) await applyRemote(remote, uid);
    } catch (error) {
      status(failMessage(error), 'error');
    }
  }, error => status(failMessage(error), 'error'));
}

function reportAccountLoad(uid, percent, message, state = 'loading') {
  if (!uid) return;
  try { window.parent?.BuzzHub?.reportAccountSyncProgress?.('tier', uid, percent, message, state); }
  catch (error) { console.warn('BuzzTier: não foi possível atualizar o progresso da troca de conta.', error); }
}

async function handleLogin(user, eventVersion, previousAuthUid = null) {
  authLoadFailed = false;
  const report = (percent, message, state = 'loading') => reportAccountLoad(user?.uid, percent, message, state);
  const complete = message => report(100, message || 'Backup do BuzzTier atualizado.', 'complete');
  report(3, 'Iniciando atualização do BuzzTier…');
  await window.BuzzTierBridge.ready();
  if (currentUser?.uid !== user.uid || eventVersion !== authEventVersion) return;
  syncAllowed = false;
  localOwnerUid = safeLocalGet('buzztier_cloud_owner_uid');
  localDirty = safeLocalGet('buzztier_cloud_dirty') === '1';
  status('Google conectado. Atualizando o backup do BuzzTier diretamente do Firebase…', 'info');
  report(9, 'Verificando as listas locais desta conta…');

  const local = currentState();
  const ownerBeforeSwitch = localOwnerUid || (previousAuthUid && previousAuthUid !== user.uid ? previousAuthUid : null);
  const switchingAccount = !!ownerBeforeSwitch && ownerBeforeSwitch !== user.uid;
  let accountCache = null;
  if (switchingAccount) {
    // Preserve the previous UID snapshot before replacing the visible app state.
    report(16, 'Preservando as alterações pendentes da conta anterior…');
    await saveAccountCache(ownerBeforeSwitch, local, localDirty, lastSnapshotId);
    if (currentUser?.uid !== user.uid || eventVersion !== authEventVersion) return;
    report(24, 'Lendo o cache exclusivo deste Gmail…');
    accountCache = await readAccountCache(user.uid);
    if (currentUser?.uid !== user.uid || eventVersion !== authEventVersion) return;
    const safeState = accountCache?.state || { schema: 2, lists: [] };
    report(30, 'Separando as listas da conta selecionada…');
    await window.BuzzTierBridge.applyCloudState(safeState);
    setOwner(user.uid);
    setDirty(accountCache?.dirty === true);
    lastSnapshotId = accountCache?.snapshotId || null;
    if (currentUser?.uid !== user.uid || eventVersion !== authEventVersion) return;
  }

  report(38, 'Buscando o backup mais recente do BuzzTier…');
  const remote = await readCloudSnapshot(user.uid, (percent, message) => {
    report(38 + Math.round(percent * 0.54), message);
  });
  if (currentUser?.uid !== user.uid || eventVersion !== authEventVersion) return;
  if (!remote.exists) report(84, 'A conta foi consultada. Verificando se há um cache local exclusivo…');

  if (switchingAccount) {
    if (remote.exists) {
      // A UID-specific cache wins over an empty cloud snapshot until the user
      // explicitly confirms which current state should be published.
      if (hasLocalData(accountCache?.state) && remote.state.lists.length === 0) {
        report(88, 'A cópia local desta conta tem listas, mas o backup na nuvem está vazio…');
        if (currentUser?.uid !== user.uid || eventVersion !== authEventVersion) return;
        await window.BuzzTierBridge.applyCloudState(accountCache.state);
        setOwner(user.uid); setDirty(true); syncAllowed = false; lastSnapshotId = remote.snapshotId;
        status('As listas desta conta foram preservadas neste aparelho. A nuvem está vazia; use “Confirmar Estado” para salvar estas listas no Gmail atual.', 'warning');
        complete('Listas desta conta preservadas; aguardando confirmação manual.');
        return;
      }
      if (accountCache?.dirty === true && !sameState(accountCache.state, remote.state)) {
        report(88, 'Há alterações pendentes nesta conta. Aguardando sua escolha…');
        const keepCache = confirm(`Esta conta Google tem listas locais ainda não confirmadas e uma cópia diferente na nuvem.\n\nOK: enviar as listas locais desta mesma conta para a nuvem.\nCancelar: carregar a cópia que já está na nuvem.\n\nAs listas do Gmail anterior continuam separadas.`);
        if (currentUser?.uid !== user.uid || eventVersion !== authEventVersion) return;
        if (keepCache) {
          report(90, 'Confirmando as alterações pendentes desta conta…');
          const result = await writeCloudSnapshot(accountCache.state, { force: true, expectedSnapshotId: remote.snapshotId });
          const verify = await readCloudSnapshot(user.uid);
          if (currentUser?.uid !== user.uid || eventVersion !== authEventVersion) return;
          if (!verify.exists || verify.snapshotId !== result.snapshotId || !sameState(verify.state, accountCache.state)) {
            throw new Error('A nuvem não confirmou o cache local desta conta.');
          }
          report(97, 'Aplicando as listas recuperadas…');
          await window.BuzzTierBridge.applyCloudState(accountCache.state);
          await deleteAccountCache(user.uid);
          setOwner(user.uid); setDirty(false); syncAllowed = true; lastSnapshotId = verify.snapshotId;
          startWatcher(user.uid);
          status('As listas locais desta conta foram recuperadas e confirmadas na nuvem.', 'success');
          complete('Listas desta conta confirmadas na nuvem.');
          return;
        }
      }
      await applyRemote(remote, user.uid, (percent, message) => report(percent, message));
      await deleteAccountCache(user.uid);
      complete(`${remote.state.lists.length} listas carregadas da conta selecionada.`);
      return;
    }

    // No remote snapshot: restore only this UID's local cache, never the previous Gmail's lists.
    if (accountCache?.state) {
      report(94, 'Restaurando as listas locais exclusivas desta conta…');
      await window.BuzzTierBridge.applyCloudState(accountCache.state);
      setOwner(user.uid);
      setDirty(hasLocalData(accountCache.state) || accountCache.dirty === true);
      syncAllowed = false;
      lastSnapshotId = null;
      startWatcher(user.uid);
      status('Esta conta ainda não tem cópia na nuvem. O cache local exclusivo dela foi restaurado; revise e use “Confirmar Estado” para salvar.', 'warning');
      complete('Cache exclusivo restaurado; ainda não há backup na nuvem.');
      return;
    }

    report(94, 'Preparando uma coleção vazia para esta conta…');
    await window.BuzzTierBridge.applyCloudState({ schema: 2, lists: [] });
    setOwner(user.uid); setDirty(false); syncAllowed = true; lastSnapshotId = null;
    startWatcher(user.uid);
    status('Esta conta ainda não tem listas na nuvem. Nenhum backup vazio foi enviado; suas listas serão sincronizadas quando você criar a primeira.', 'warning');
    complete('Conta atualizada. Nenhum backup existente foi substituído.');
    return;
  }

  const localHasLists = hasLocalData(local);
  if (remote.exists) {
    if (localHasLists && remote.state.lists.length === 0 && !sameState(local, remote.state)) {
      syncAllowed = false;
      setDirty(true);
      lastSnapshotId = remote.snapshotId;
      status(`O backup do BuzzTier na nuvem está vazio, mas este aparelho tem ${local.lists.length} listas. Mantive os dados locais e pausei a sincronização automática. Use “Confirmar Estado” para salvar estas listas no Gmail atual.`, 'warning');
      complete('Backup vazio detectado; listas locais preservadas.');
      return;
    }
    if (sameState(local, remote.state)) {
      setOwner(user.uid); setDirty(false); syncAllowed = true; lastSnapshotId = remote.snapshotId;
      status(`BuzzTier conectado à nuvem: ${remote.state.lists.length} listas.`, 'success');
      complete(`${remote.state.lists.length} listas já estavam atualizadas.`);
    } else if (localOwnerUid === user.uid && !localDirty) {
      await applyRemote(remote, user.uid, (percent, message) => report(percent, message));
      complete(`${remote.state.lists.length} listas carregadas da nuvem.`);
    } else if (!localHasLists) {
      await applyRemote(remote, user.uid, (percent, message) => report(percent, message));
      complete(`${remote.state.lists.length} listas carregadas da nuvem.`);
    } else {
      report(88, 'Aguardando decisão sobre diferenças entre o aparelho e a nuvem…');
      const loadCloud = confirm(`O BuzzTier encontrou ${remote.state.lists.length} listas na nuvem e ${local.lists.length} listas diferentes neste aparelho.\n\nOK: carregar a versão da nuvem neste aparelho.\nCancelar: manter as listas locais sem sincronizar por enquanto.\n\nNenhuma das duas versões será apagada da nuvem por esta pergunta.`);
      if (loadCloud) {
        await applyRemote(remote, user.uid, (percent, message) => report(percent, message));
        complete(`${remote.state.lists.length} listas carregadas da nuvem.`);
      } else {
        syncAllowed = false;
        lastSnapshotId = remote.snapshotId;
        status('As listas deste aparelho foram preservadas. A sincronização automática ficou pausada para evitar misturar versões; use “Confirmar Estado” quando decidir.', 'warning');
        complete('Nuvem verificada; listas locais preservadas sem substituição.');
      }
    }
  } else {
    if (localHasLists && localOwnerUid && localOwnerUid !== user.uid) {
      // Extra protection for legacy data: never upload a different UID's local lists.
      await window.BuzzTierBridge.applyCloudState({ schema: 2, lists: [] });
      setOwner(user.uid); setDirty(false); syncAllowed = true; lastSnapshotId = null;
      status('Esta conta não tinha listas na nuvem. O espaço local foi separado sem publicar um backup vazio; as listas da outra conta ficaram preservadas.', 'success');
      complete('Conta atualizada e separada. Ainda não há listas neste Gmail.');
    } else if (localHasLists) {
      report(88, 'Não há backup remoto; aguardando confirmação para vincular as listas locais…');
      const uploadLocal = confirm(`O BuzzTier encontrou ${local.lists.length} listas neste aparelho e ainda não encontrou uma cópia na nuvem desta conta.\n\nDeseja salvar essas listas na conta ${user.email || 'atual'}?`);
      if (uploadLocal) {
        report(91, 'Salvando as listas na conta selecionada…');
        syncAllowed = true;
        await writeCloudSnapshot(local, { force: true });
        status(`BuzzTier associado a ${user.email || 'esta conta'}: ${local.lists.length} listas.`, 'success');
        complete('Listas locais vinculadas à conta.');
      } else {
        status('As listas continuam neste aparelho. A sincronização ficou pausada até você confirmar o estado.', 'warning');
        complete('Nuvem verificada; listas locais preservadas.');
      }
    } else {
      setOwner(user.uid); setDirty(false); syncAllowed = true; lastSnapshotId = null;
      // Um aparelho vazio não é prova de que a cópia da nuvem também deva ficar vazia.
      status('BuzzTier conectado. Esta conta ainda não tem listas; nenhum backup vazio foi publicado.', 'warning');
      complete('Conta atualizada sem enviar uma coleção vazia.');
    }
  }
  if (currentUser?.uid === user.uid && syncAllowed) startWatcher(user.uid);
}

function markLocalDirty(options = {}) {
  if (applyingCloud) return;
  setDirty(true);
  if (options?.pauseSync === true) {
    if (syncTimer) { clearTimeout(syncTimer); syncTimer = null; }
    syncAgain = false;
    syncAllowed = false;
    stopWatcher();
    if (currentUser) status('Backup restaurado somente neste aparelho. Revise as listas e use “Confirmar Estado” para publicar na nuvem.', 'warning');
    return;
  }
  if (!currentUser || !syncAllowed) return;
  if (syncing) syncAgain = true;
  if (syncTimer) clearTimeout(syncTimer);
  syncTimer = setTimeout(() => { syncTimer = null; autoSync().catch(error => status(failMessage(error), 'error')); }, 1200);
}

async function autoSync() {
  if (!currentUser || !syncAllowed) return false;
  if (syncing) return syncPromise;
  syncing = true;
  syncPromise = (async () => {
    const user = currentUser;
    const stateAtStart = currentState();
    try {
      const result = await writeCloudSnapshot(stateAtStart, { force: false });
      if (currentUser?.uid !== user.uid) throw new Error('A conta Google mudou durante a sincronização.');
      if (!sameState(currentState(), stateAtStart)) { setDirty(true); syncAgain = true; }
      localSyncError = '';
      status(`BuzzTier salvo na nuvem: ${result.listCount} listas.`, 'success');
      return true;
    } catch (error) {
      localSyncError = failMessage(error);
      if (isQuotaError(error)) {
        if (currentUser?.uid === user?.uid) {
          syncAllowed = false;
          setDirty(true);
          syncAgain = false;
        }
        try { await saveAccountCache(user?.uid, stateAtStart, true, lastSnapshotId); }
        catch (cacheError) { console.warn('BuzzTier: não foi possível duplicar a cópia pendente no cache por conta.', cacheError); }
      }
      status(localSyncError, 'warning');
      throw error;
    }
  })();
  try { return await syncPromise; }
  finally {
    syncing = false; syncPromise = null;
    if (syncAgain && currentUser && syncAllowed) {
      syncAgain = false;
      if (syncTimer) clearTimeout(syncTimer);
      syncTimer = setTimeout(() => { syncTimer = null; autoSync().catch(error => status(failMessage(error), 'error')); }, 650);
    }
  }
}

async function confirmState(options = {}) {
  await window.BuzzTierBridge.ready();
  const user = currentUser || auth.currentUser;
  if (!user) { status('Entre com sua conta Google antes de confirmar o BuzzTier.', 'warning'); return false; }
  const forceCurrentState = options?.forceCurrentState === true;
  const allowUnassignedLocalState = options?.allowUnassignedLocalState === true;
  if (localOwnerUid && localOwnerUid !== user.uid) {
    throw new Error('As listas abertas neste aparelho pertencem a outra conta Google. Troque para o Gmail correto antes de confirmar.');
  }
  if (!localOwnerUid && !allowUnassignedLocalState) {
    throw new Error('As listas deste aparelho ainda não estão vinculadas a uma conta. Confirme a associação ao Gmail atual primeiro.');
  }
  if (syncTimer) { clearTimeout(syncTimer); syncTimer = null; }
  if (syncPromise) {
    try { await syncPromise; } catch (_) {}
  }
  const local = currentState();
  const remote = await readCloudSnapshot(user.uid);
  if (!forceCurrentState && remote.exists && !sameState(local, remote.state)) {
    const accepted = confirm(`A cópia da nuvem do BuzzTier contém uma versão diferente (${remote.state.lists.length} listas).\n\nAo confirmar, as ${local.lists.length} listas deste aparelho substituirão a versão atual da nuvem do BuzzTier. O BuzzDataBase não será alterado.\n\nDeseja continuar?`);
    if (!accepted) { status('Confirmação do BuzzTier cancelada. A nuvem não foi alterada.', 'info'); return false; }
  } else if (!forceCurrentState && !remote.exists && hasLocalData(local)) {
    const accepted = confirm(`Salvar ${local.lists.length} listas do BuzzTier na nuvem desta conta?`);
    if (!accepted) return false;
  }

  syncAllowed = true;
  syncing = true;
  progress(1, 'Preparando a confirmação do BuzzTier…');
  try {
    const result = await writeCloudSnapshot(local, { force: true, onProgress: progress, expectedSnapshotId: remote.snapshotId, previousSnapshot: remote });
    const verify = await readCloudSnapshot(user.uid);
    if (!verify.exists || verify.snapshotId !== result.snapshotId || !sameState(verify.state, local)) {
      throw new Error('O servidor não confirmou que todas as listas e imagens do BuzzTier foram gravadas.');
    }
    setOwner(user.uid); setDirty(false); syncAllowed = true; lastSnapshotId = verify.snapshotId;
    await deleteAccountCache(user.uid);
    startWatcher(user.uid);
    status(`Estado confirmado no BuzzTier: ${result.listCount} listas e ${result.chunkCount} blocos verificados.`, 'success');
    progress(100, 'BuzzTier confirmado e verificado na nuvem.');
    return true;
  } catch (error) {
    if (isQuotaError(error)) {
      if (currentUser?.uid === user.uid) {
        syncAllowed = false;
        setDirty(true);
        syncAgain = false;
      }
      try { await saveAccountCache(user.uid, local, true, lastSnapshotId); }
      catch (cacheError) { console.warn('BuzzTier: não foi possível preservar a confirmação pendente no cache por conta.', cacheError); }
    }
    status(`BuzzTier não confirmado: ${failMessage(error)}`, 'error');
    throw error;
  } finally {
    syncing = false;
    if (syncAgain && currentUser && syncAllowed) { syncAgain = false; if (syncTimer) clearTimeout(syncTimer); syncTimer = setTimeout(() => { syncTimer = null; autoSync().catch(error => status(failMessage(error), 'error')); }, 650); }
  }
}

async function stopWatcherAndPause() {
  if (syncTimer) { clearTimeout(syncTimer); syncTimer = null; }
  syncAllowed = false;
  stopWatcher(true);
  if (syncPromise) {
    try { await syncPromise; } catch (_) {}
  }
}

window.BuzzTierCloud = {
  markLocalDirty,
  setApplying(value) { applyingCloud = !!value; },
  confirmState,
  stopWatcher: stopWatcherAndPause,
  clearAccountCache,
  deleteAccountCache,
  getCurrentUser: () => currentUser,
  getStatus: () => ({ connected: !!currentUser, syncing, allowed: syncAllowed, ownerUid: localOwnerUid, dirty: localDirty, error: localSyncError })
};

const persistenceReady = setPersistence(auth, browserLocalPersistence).catch(error => {
  console.warn('BuzzTier: não foi possível definir persistência local do login.', error);
});

let lastObservedAuthUid = null;
let authLoadFailed = false;
onAuthStateChanged(auth, user => {
  const previousUid = lastObservedAuthUid;
  if (user?.uid) lastObservedAuthUid = user.uid;
  const version = ++authEventVersion;
  currentUser = user || null;
  if (!currentUser) {
    if (syncTimer) { clearTimeout(syncTimer); syncTimer = null; }
    syncAllowed = false;
    stopWatcher(true);
    status('Sem conta Google conectada. As listas ficam salvas neste aparelho.', 'info');
    return;
  }
  stopWatcher(true);
  persistenceReady
    .then(() => handleLogin(currentUser, version, previousUid))
    .catch(error => {
      if (currentUser?.uid !== user.uid || version !== authEventVersion) return;
      authLoadFailed = true;
      syncAllowed = false;
      status(failMessage(error), 'error');
      reportAccountLoad(user.uid, 92, failMessage(error), 'error');
    });
});

window.addEventListener('online', () => {
  if (!currentUser) return;
  if (authLoadFailed) {
    authLoadFailed = false;
    const version = ++authEventVersion;
    handleLogin(currentUser, version, lastObservedAuthUid)
      .catch(error => { authLoadFailed = true; syncAllowed = false; status(failMessage(error), 'error'); reportAccountLoad(currentUser?.uid, 92, failMessage(error), 'error'); });
    return;
  }
  if (syncAllowed && localDirty) autoSync().catch(error => status(failMessage(error), 'error'));
});
