import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/13.1.0/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-auth.js";
import {
  getFirestore,
  doc,
  collection,
  getDocFromServer,
  getDocsFromServer,
  query,
  where,
  setDoc,
  writeBatch,
  runTransaction,
  onSnapshot,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-firestore.js";

// Uses the same Firebase project and browser-persistent Google session as BuzzDataBase.
const firebaseConfig = {
  apiKey: "AIzaSyCwZ7b0jcJbkPr-ZITmuLNOw3CgNYqV7-4",
  authDomain: "buzzdatabase0.firebaseapp.com",
  projectId: "buzzdatabase0",
  storageBucket: "buzzdatabase0.firebasestorage.app",
  messagingSenderId: "960232212219",
  appId: "1:960232212219:web:a7309f66eb1daa4bbe125e",
  measurementId: "G-Z6VDBNRKF4"
};

const app = getApps().find(candidate => candidate.name === "[DEFAULT]") || initializeApp(firebaseConfig);
const auth = getAuth(app);
const firestore = getFirestore(app);
const CHUNK_SIZE = 60000; // stays comfortably below the 1 MiB document limit, including UTF-8 overhead
const BATCH_LIMIT = 20; // keeps each Firestore commit below its 10 MiB request limit

let currentUser = null;
let lastSnapshotId = null;
let syncAllowed = false;
let applyingCloud = false;
let syncing = false;
let syncPromise = null;
let syncTimer = null;
let cloudUnsubscribe = null;
let authEventVersion = 0;
let localOwnerUid = safeLocalGet('buzztier_cloud_owner_uid');
let localDirty = safeLocalGet('buzztier_cloud_dirty') === '1';
let localSyncError = '';
let syncAgain = false;

function safeLocalGet(key) { try { return localStorage.getItem(key) || ''; } catch (_) { return ''; } }
function safeLocalSet(key, value) { try { localStorage.setItem(key, value); } catch (_) {} }
function status(message, kind = 'info') {
  try { window.parent?.BuzzHub?.setAppStatus?.('tier', String(message), kind); } catch (_) {}
  try { window.dispatchEvent(new CustomEvent('buzztier-cloud-status', { detail: { message, kind } })); } catch (_) {}
}
function progress(percent, message) {
  try { window.parent?.BuzzHub?.setConfirmProgress?.(percent, message); } catch (_) {}
  try { window.dispatchEvent(new CustomEvent('buzztier-cloud-progress', { detail: { percent, message } })); } catch (_) {}
}
function manifestRef(uid = currentUser?.uid) { return doc(firestore, 'users', uid, 'apps', 'buzztier'); }
function chunksRef(uid = currentUser?.uid) { return collection(firestore, 'users', uid, 'apps', 'buzztier', 'chunks'); }
function cloneState(value) { return JSON.parse(JSON.stringify(value || { schema: 2, lists: [] })); }
function currentState() {
  const state = window.BuzzTierBridge?.getBackupState?.();
  return state && Array.isArray(state.lists) ? state : { schema: 2, lists: [] };
}
function hasLocalData(state = currentState()) { return Array.isArray(state?.lists) && state.lists.length > 0; }
function sameState(left, right) {
  try { return JSON.stringify(cloneState(left)) === JSON.stringify(cloneState(right)); }
  catch (_) { return false; }
}
function setOwner(uid) {
  localOwnerUid = uid || '';
  if (uid) safeLocalSet('buzztier_cloud_owner_uid', uid);
  else { try { localStorage.removeItem('buzztier_cloud_owner_uid'); } catch (_) {} }
}
function setDirty(value) {
  localDirty = !!value;
  safeLocalSet('buzztier_cloud_dirty', localDirty ? '1' : '0');
}
function stopWatcher(resetSnapshot = false) {
  if (typeof cloudUnsubscribe === 'function') {
    try { cloudUnsubscribe(); } catch (error) { console.warn('BuzzTier: erro ao encerrar o observador da nuvem.', error); }
  }
  cloudUnsubscribe = null;
  if (resetSnapshot) lastSnapshotId = null;
}
function failMessage(error) {
  const code = String(error?.code || '');
  if (code.includes('permission-denied')) return 'O Firestore recusou o acesso ao espaço independente do BuzzTier. Confira as regras users/{uid}/{path=**}.';
  if (code.includes('unauthorized-domain')) return 'O domínio do BuzzHub não está autorizado no Firebase Authentication.';
  if (code.includes('resource-exhausted')) return 'O limite de uso do Firestore foi atingido. Os dados locais continuam preservados.';
  if (code.includes('unavailable') || code.includes('network')) return 'Sem conexão com o Firestore. As alterações continuam salvas neste aparelho.';
  return error?.message || 'Não foi possível sincronizar o BuzzTier com a nuvem.';
}

async function readCloudSnapshot(uid = currentUser?.uid) {
  if (!uid) throw new Error('Nenhuma conta Google conectada.');
  const manifestSnapshot = await getDocFromServer(manifestRef(uid));
  if (!manifestSnapshot.exists()) return { exists: false, state: null, snapshotId: null, manifest: null };
  const manifest = manifestSnapshot.data() || {};
  const snapshotId = String(manifest.snapshotId || '');
  const chunkCount = Math.max(0, Number(manifest.chunkCount) || 0);
  if (!snapshotId || !chunkCount) throw new Error('O estado salvo do BuzzTier está incompleto. Seus dados locais não foram alterados.');

  const snapshot = await getDocsFromServer(chunksRef(uid));
  const parts = new Array(chunkCount);
  let found = 0;
  for (const document of snapshot.docs) {
    const value = document.data() || {};
    if (value.snapshotId !== snapshotId) continue;
    const index = Number(value.index);
    if (Number.isInteger(index) && index >= 0 && index < chunkCount && typeof value.data === 'string') {
      parts[index] = value.data;
      found++;
    }
  }
  if (found !== chunkCount || parts.some(part => typeof part !== 'string')) {
    throw new Error('A nuvem não entregou todos os blocos do BuzzTier. Nada foi substituído neste aparelho.');
  }
  const state = JSON.parse(parts.join(''));
  if (!state || !Array.isArray(state.lists)) throw new Error('A estrutura da cópia do BuzzTier na nuvem é inválida.');
  return { exists: true, state, snapshotId, manifest };
}

function splitJson(json) {
  const parts = [];
  for (let offset = 0; offset < json.length;) {
    let end = Math.min(json.length, offset + CHUNK_SIZE);
    // Avoid splitting a UTF-16 surrogate pair between two Firestore documents.
    if (end < json.length) {
      const last = json.charCodeAt(end - 1);
      if (last >= 0xD800 && last <= 0xDBFF) end--;
    }
    parts.push(json.slice(offset, end));
    offset = end;
  }
  return parts.length ? parts : ['{"schema":2,"lists":[]}'];
}

async function writeCloudSnapshot(state, { force = false, onProgress = null, expectedSnapshotId: expectedOverride } = {}) {
  const user = currentUser;
  if (!user) throw new Error('Entre com sua conta Google antes de salvar o BuzzTier na nuvem.');
  const uid = user.uid;
  const manifestBefore = await getDocFromServer(manifestRef(uid));
  const remoteBefore = { exists: manifestBefore.exists(), snapshotId: manifestBefore.exists() ? String(manifestBefore.data()?.snapshotId || '') || null : null };
  if (expectedOverride !== undefined && remoteBefore.snapshotId !== expectedOverride) throw new Error('A cópia do BuzzTier na nuvem mudou depois da sua revisão. Leia a versão mais recente e confirme novamente.');
  if (!force && remoteBefore.exists && remoteBefore.snapshotId !== lastSnapshotId) {
    syncAllowed = false;
    throw new Error('A nuvem do BuzzTier foi atualizada em outro dispositivo. Para evitar sobrescrever dados mais recentes, use “Confirmar Estado” depois de conferir suas listas.');
  }
  if (!force && !remoteBefore.exists && lastSnapshotId) {
    syncAllowed = false;
    throw new Error('A cópia do BuzzTier na nuvem mudou ou foi removida. Use “Confirmar Estado” para decidir o que salvar.');
  }

  const stableState = cloneState(state);
  const json = JSON.stringify(stableState);
  if (json.length > 30000000) throw new Error('O backup do BuzzTier passou de 30 MB. Exporte um backup local e reduza o tamanho antes de sincronizar.');
  const parts = splitJson(json);
  const snapshotId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  let completed = 0;
  for (let start = 0; start < parts.length; start += BATCH_LIMIT) {
    if (currentUser?.uid !== uid) throw new Error('A conta Google mudou antes da gravação do BuzzTier terminar.');
    const batch = writeBatch(firestore);
    const end = Math.min(parts.length, start + BATCH_LIMIT);
    for (let index = start; index < end; index++) {
      const chunkId = `${snapshotId}_${String(index).padStart(5, '0')}`;
      batch.set(doc(chunksRef(uid), chunkId), { snapshotId, index, data: parts[index], createdAt: Date.now() });
    }
    await batch.commit();
    completed = end;
    if (typeof onProgress === 'function') onProgress(Math.min(88, Math.round((completed / parts.length) * 88)), `Enviando listas e imagens do BuzzTier (${completed}/${parts.length} blocos)…`);
    else progress(Math.min(88, Math.round((completed / parts.length) * 88)), `Enviando BuzzTier (${completed}/${parts.length} blocos)…`);
  }

  // Publish the new generation only after all chunks have been written. The transaction
  // compares the manifest again, preventing a concurrent device from being overwritten.
  if (currentUser?.uid !== uid) throw new Error('A conta Google mudou antes de publicar o estado do BuzzTier.');
  const expectedSnapshotId = remoteBefore.snapshotId || null;
  await runTransaction(firestore, async transaction => {
    const latest = await transaction.get(manifestRef(uid));
    const latestId = latest.exists() ? String(latest.data()?.snapshotId || '') || null : null;
    if (latestId !== expectedSnapshotId) throw new Error('Outro dispositivo atualizou o BuzzTier durante o envio. Os blocos locais não foram publicados; confira a nuvem e tente novamente.');
    if (currentUser?.uid !== uid) throw new Error('A conta Google mudou antes de publicar o estado do BuzzTier.');
    transaction.set(manifestRef(uid), {
      schema: 1,
      appVersion: '1.21',
      snapshotId,
      chunkCount: parts.length,
      listCount: stableState.lists.length,
      jsonLength: json.length,
      updatedAt: serverTimestamp()
    });
  });
  lastSnapshotId = snapshotId;
  setOwner(uid);
  setDirty(false);

  // Remove only the previously active generation. A different device may already be
  // staging a newer generation, so never delete arbitrary uncommitted chunks.
  try {
    let staleDocs = [];
    if (remoteBefore.snapshotId) {
      const previousGeneration = await getDocsFromServer(query(chunksRef(uid), where('snapshotId', '==', remoteBefore.snapshotId)));
      staleDocs = previousGeneration.docs;
    }
    for (let start = 0; start < staleDocs.length; start += BATCH_LIMIT) {
      const batch = writeBatch(firestore);
      for (const document of staleDocs.slice(start, start + BATCH_LIMIT)) batch.delete(document.ref);
      await batch.commit();
    }
  } catch (cleanupError) {
    // The new manifest already points to a complete generation. Old chunks can be
    // cleaned during a later save; cleanup failure must not misreport a successful save.
    console.warn('BuzzTier: a nova cópia foi publicada, mas alguns blocos antigos ficaram para limpeza posterior.', cleanupError);
  }
  if (typeof onProgress === 'function') onProgress(100, 'BuzzTier confirmado na nuvem.');
  else progress(100, 'BuzzTier confirmado na nuvem.');
  return { ok: true, snapshotId, listCount: stableState.lists.length, chunkCount: parts.length };
}

async function applyRemote(remote, uid) {
  if (currentUser?.uid !== uid) return false;
  await window.BuzzTierBridge.applyCloudState(remote.state);
  setOwner(uid);
  setDirty(false);
  syncAllowed = true;
  lastSnapshotId = remote.snapshotId;
  status(`BuzzTier sincronizado: ${remote.state.lists.length} listas carregadas da nuvem.`, 'success');
  return true;
}

function startWatcher(uid) {
  stopWatcher(false);
  const version = ++authEventVersion;
  cloudUnsubscribe = onSnapshot(manifestRef(uid), async snapshot => {
    if (currentUser?.uid !== uid || version !== authEventVersion) return;
    if (!snapshot.exists()) return;
    const nextId = String(snapshot.data()?.snapshotId || '');
    if (!nextId || nextId === lastSnapshotId || syncing) return;
    if (localDirty) {
      syncAllowed = false;
      status('O BuzzTier foi alterado em outro dispositivo. Suas alterações locais foram preservadas; use “Confirmar Estado” depois de conferir as listas.', 'warning');
      return;
    }
    try {
      const remote = await readCloudSnapshot(uid);
      if (remote.exists && remote.snapshotId !== lastSnapshotId && !localDirty && currentUser?.uid === uid) await applyRemote(remote, uid);
    } catch (error) {
      status(failMessage(error), 'error');
    }
  }, error => status(failMessage(error), 'error'));
}

async function handleLogin(user, eventVersion) {
  await window.BuzzTierBridge.ready();
  if (currentUser?.uid !== user.uid || eventVersion !== authEventVersion) return;
  syncAllowed = false;
  localOwnerUid = safeLocalGet('buzztier_cloud_owner_uid');
  localDirty = safeLocalGet('buzztier_cloud_dirty') === '1';
  status('Google conectado. Verificando as listas do BuzzTier na nuvem…', 'info');
  const local = currentState();
  const localHasLists = hasLocalData(local);
  const remote = await readCloudSnapshot(user.uid);
  if (currentUser?.uid !== user.uid || eventVersion !== authEventVersion) return;

  if (remote.exists) {
    if (sameState(local, remote.state)) {
      setOwner(user.uid); setDirty(false); syncAllowed = true; lastSnapshotId = remote.snapshotId;
      status(`BuzzTier conectado à nuvem: ${remote.state.lists.length} listas.`, 'success');
    } else if (localOwnerUid === user.uid && !localDirty) {
      await applyRemote(remote, user.uid);
    } else if (!localHasLists) {
      await applyRemote(remote, user.uid);
    } else {
      const loadCloud = confirm(`O BuzzTier encontrou ${remote.state.lists.length} listas na nuvem e ${local.lists.length} listas diferentes neste aparelho.\n\nOK: carregar a versão da nuvem neste aparelho.\nCancelar: manter as listas locais sem sincronizar por enquanto.\n\nNenhuma das duas versões será apagada da nuvem por esta pergunta.`);
      if (loadCloud) await applyRemote(remote, user.uid);
      else {
        syncAllowed = false;
        lastSnapshotId = remote.snapshotId;
        status('As listas deste aparelho foram preservadas. A sincronização automática ficou pausada para evitar misturar versões; use “Confirmar Estado” quando decidir.', 'warning');
      }
    }
  } else {
    if (localHasLists && localOwnerUid && localOwnerUid !== user.uid) {
      const migrate = confirm(`Este aparelho tem ${local.lists.length} listas associadas a outra conta Google, mas esta conta ainda não tem um BuzzTier na nuvem.\n\nDeseja copiar as listas locais para a conta ${user.email || 'atual'}? A outra conta não será apagada.`);
      if (!migrate) {
        status('As listas locais foram preservadas e não foram copiadas para esta conta.', 'warning');
        syncAllowed = false;
      } else {
        syncAllowed = true;
        await writeCloudSnapshot(local, { force: true });
        status(`BuzzTier associado a ${user.email || 'esta conta'}: ${local.lists.length} listas.`, 'success');
      }
    } else if (localHasLists) {
      const uploadLocal = confirm(`O BuzzTier encontrou ${local.lists.length} listas neste aparelho e ainda não encontrou uma cópia na nuvem desta conta.\n\nDeseja salvar essas listas na conta ${user.email || 'atual'}?`);
      if (uploadLocal) {
        syncAllowed = true;
        await writeCloudSnapshot(local, { force: true });
        status(`Primeira cópia do BuzzTier salva na nuvem: ${local.lists.length} listas.`, 'success');
      } else {
        status('As listas continuam neste aparelho. A sincronização ficou pausada até você confirmar o estado.', 'warning');
      }
    } else {
      syncAllowed = true;
      await writeCloudSnapshot(local, { force: true });
      status('BuzzTier conectado. Uma cópia vazia foi inicializada na nuvem.', 'success');
    }
  }
  if (currentUser?.uid === user.uid && syncAllowed) startWatcher(user.uid);
}

function markLocalDirty() {
  if (applyingCloud) return;
  setDirty(true);
  if (!currentUser || !syncAllowed) return;
  if (syncing) syncAgain = true;
  if (syncTimer) clearTimeout(syncTimer);
  syncTimer = setTimeout(() => { syncTimer = null; autoSync().catch(error => status(failMessage(error), 'error')); }, 1200);
}

async function autoSync() {
  if (!currentUser || !syncAllowed) return false;
  if (syncing) return syncPromise;
  syncing = true;
  syncPromise = (async () => {
    try {
      const user = currentUser;
      const stateAtStart = currentState();
      const result = await writeCloudSnapshot(stateAtStart, { force: false });
      if (currentUser?.uid !== user.uid) throw new Error('A conta Google mudou durante a sincronização.');
      if (!sameState(currentState(), stateAtStart)) { setDirty(true); syncAgain = true; }
      localSyncError = '';
      status(`BuzzTier salvo na nuvem: ${result.listCount} listas.`, 'success');
      return true;
    } catch (error) {
      localSyncError = failMessage(error);
      status(localSyncError, 'warning');
      throw error;
    }
  })();
  try { return await syncPromise; }
  finally {
    syncing = false; syncPromise = null;
    if (syncAgain && currentUser && syncAllowed) {
      syncAgain = false;
      if (syncTimer) clearTimeout(syncTimer);
      syncTimer = setTimeout(() => { syncTimer = null; autoSync().catch(error => status(failMessage(error), 'error')); }, 650);
    }
  }
}

async function confirmState() {
  await window.BuzzTierBridge.ready();
  const user = currentUser || auth.currentUser;
  if (!user) { status('Entre com sua conta Google antes de confirmar o BuzzTier.', 'warning'); return false; }
  if (syncTimer) { clearTimeout(syncTimer); syncTimer = null; }
  if (syncPromise) {
    try { await syncPromise; } catch (_) {}
  }
  const local = currentState();
  const remote = await readCloudSnapshot(user.uid);
  if (remote.exists && !sameState(local, remote.state)) {
    const accepted = confirm(`A cópia da nuvem do BuzzTier contém uma versão diferente (${remote.state.lists.length} listas).\n\nAo confirmar, as ${local.lists.length} listas deste aparelho substituirão a versão atual da nuvem do BuzzTier. O BuzzDataBase não será alterado.\n\nDeseja continuar?`);
    if (!accepted) { status('Confirmação do BuzzTier cancelada. A nuvem não foi alterada.', 'info'); return false; }
  } else if (!remote.exists && hasLocalData(local)) {
    const accepted = confirm(`Salvar ${local.lists.length} listas do BuzzTier na nuvem desta conta?`);
    if (!accepted) return false;
  }

  syncAllowed = true;
  syncing = true;
  progress(1, 'Preparando a confirmação do BuzzTier…');
  try {
    const result = await writeCloudSnapshot(local, { force: true, onProgress: progress, expectedSnapshotId: remote.snapshotId });
    const verify = await readCloudSnapshot(user.uid);
    if (!verify.exists || verify.snapshotId !== result.snapshotId || !sameState(verify.state, local)) {
      throw new Error('O servidor não confirmou que todas as listas e imagens do BuzzTier foram gravadas.');
    }
    setOwner(user.uid); setDirty(false); syncAllowed = true; lastSnapshotId = verify.snapshotId;
    startWatcher(user.uid);
    status(`Estado confirmado no BuzzTier: ${result.listCount} listas e ${result.chunkCount} blocos verificados.`, 'success');
    progress(100, 'BuzzTier confirmado e verificado na nuvem.');
    return true;
  } catch (error) {
    status(`BuzzTier não confirmado: ${failMessage(error)}`, 'error');
    throw error;
  } finally {
    syncing = false;
    if (syncAgain && currentUser && syncAllowed) { syncAgain = false; if (syncTimer) clearTimeout(syncTimer); syncTimer = setTimeout(() => { syncTimer = null; autoSync().catch(error => status(failMessage(error), 'error')); }, 650); }
  }
}

async function stopWatcherAndPause() {
  if (syncTimer) { clearTimeout(syncTimer); syncTimer = null; }
  syncAllowed = false;
  stopWatcher(true);
  if (syncPromise) {
    try { await syncPromise; } catch (_) {}
  }
}

window.BuzzTierCloud = {
  markLocalDirty,
  setApplying(value) { applyingCloud = !!value; },
  confirmState,
  stopWatcher: stopWatcherAndPause,
  getCurrentUser: () => currentUser,
  getStatus: () => ({ connected: !!currentUser, syncing, allowed: syncAllowed, ownerUid: localOwnerUid, dirty: localDirty, error: localSyncError })
};

const persistenceReady = setPersistence(auth, browserLocalPersistence).catch(error => {
  console.warn('BuzzTier: não foi possível definir persistência local do login.', error);
});

onAuthStateChanged(auth, user => {
  const version = ++authEventVersion;
  currentUser = user || null;
  if (!currentUser) {
    if (syncTimer) { clearTimeout(syncTimer); syncTimer = null; }
    syncAllowed = false;
    stopWatcher(true);
    status('Sem conta Google conectada. As listas ficam salvas neste aparelho.', 'info');
    return;
  }
  stopWatcher(true);
  persistenceReady
    .then(() => handleLogin(currentUser, version))
    .catch(error => {
      if (currentUser?.uid !== user.uid || version !== authEventVersion) return;
      syncAllowed = false;
      status(failMessage(error), 'error');
    });
});

window.addEventListener('online', () => {
  if (currentUser && syncAllowed && localDirty) autoSync().catch(error => status(failMessage(error), 'error'));
});
