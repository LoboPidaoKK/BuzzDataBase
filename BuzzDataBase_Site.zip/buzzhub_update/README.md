# BuzzHub 2.3

Central local com três aplicativos: BuzzDataBase, BuzzTier e BuzzLinks.

O BuzzLinks organiza endereços em pastas, permite capas personalizadas e inclui links, pastas e imagens nos backups locais. A atualização preserva os dados existentes do BuzzLinks 2.1: links antigos aparecem em “Sem pasta” até que sejam organizados.

Não há login nem sincronização na nuvem. Publique mantendo a estrutura de pastas e faça backups JSON regulares. Consulte `LEIA-ME_BUZZHUB.txt` e `CHANGELOG_BUZZHUB_v2.2.txt` para detalhes.
