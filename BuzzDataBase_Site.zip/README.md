BuzzHub 3.0 — BuzzDash reorganizado e otimizado.

A navegação do BuzzDash agora é Aplicativo → Tópico (BuzzDataBase) ou Lista (BuzzTier) → carrossel com todas as imagens da seleção. A linha de tiers e a mensagem de instrução foram removidas, as capas ficaram maiores e o carregamento recebeu indicadores circulares. A tela inicial e os demais aplicativos foram preservados.
