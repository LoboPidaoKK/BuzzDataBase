BuzzHub 3.1

Pacote completo do BuzzHub, preservando a estrutura do ZIP 2.12 e o conteúdo funcional do 3.0.

Publicação: o workflow existente continua extraindo BuzzDataBase_Site.zip para _site. O index.html está diretamente na raiz do arquivo; renomeie este pacote para BuzzDataBase_Site.zip antes de enviar ao repositório. Não é necessário alterar o workflow.
