# BuzzHub 1.3

Centraliza BuzzDataBase 1.29 e BuzzTier 1.21 em uma única página e sessão Google.

## Correção de sincronização nesta versão

- Cada coleção fica vinculada ao UID do Gmail no Firestore.
- Ao trocar de Gmail, o estado local anterior é preservado em um cache IndexedDB separado por aplicativo e UID.
- O aplicativo passa a carregar o snapshot remoto da conta selecionada; não mistura listas/obras locais de outro Gmail.
- Se uma conta ainda não tiver cópia na nuvem, só pode restaurar o cache local que pertence ao mesmo UID; caso contrário, inicia vazia.
- Alterações locais pendentes da própria conta são preservadas e podem ser confirmadas sem migrar dados para outro Gmail.

O cache por UID é local ao navegador/aparelho. O Firestore continua sendo a cópia na nuvem.

Veja `LEIA-ME_BUZZHUB.txt` para publicação e configuração.
