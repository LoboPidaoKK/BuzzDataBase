# BuzzHub 1.7

Centraliza BuzzDataBase 1.30 e BuzzTier 1.21 em uma única página e sessão Google. A versão atual do Hub é a 1.7.

## Correção de sincronização nesta versão

- Cada coleção fica vinculada ao UID do Gmail no Firestore.
- Ao trocar de Gmail, o estado local anterior é preservado em um cache IndexedDB separado por aplicativo e UID.
- O aplicativo passa a carregar o snapshot remoto da conta selecionada; não mistura listas/obras locais de outro Gmail.
- Se uma conta ainda não tiver cópia na nuvem, só pode restaurar o cache local que pertence ao mesmo UID; caso contrário, inicia vazia.
- Alterações locais pendentes da própria conta são preservadas e podem ser confirmadas sem migrar dados para outro Gmail.

O cache por UID é local ao navegador/aparelho. O Firestore continua sendo a cópia na nuvem.

Veja `LEIA-ME_BUZZHUB.txt` para publicação e configuração.

## BuzzDataBase v1.30

O salvamento agora é incremental: capas e registros inalterados não são regravados no IndexedDB. A busca e a grade também foram otimizadas para catálogos grandes.

## Atualização v1.5 — recarregar os backups ao trocar de Gmail

Ao trocar de conta, os dois aplicativos consultam o Firebase automaticamente. Uma barra de progresso aparece logo abaixo do cartão da conta e combina o andamento do BuzzDataBase e do BuzzTier. O BuzzDataBase força leitura do servidor; o BuzzTier mostra a leitura dos blocos em lotes.

Os dados locais e remotos não são apagados. Publique todo o conteúdo deste ZIP na raiz do repositório.


## v1.6 — atualização de conta
Ao concluir a seleção de um Gmail, o Hub executa uma recarga real da página para recriar os dois iframes e reiniciar a leitura de backups em ambos os aplicativos. Uma mudança de UID observada diretamente pelo Firebase também dispara essa recarga. Um marcador de sessão impede loops e posiciona a tela no topo após a atualização.


## v1.7 — retomada em segundo plano e importação protegida

- O Hub memoriza qual aplicativo estava aberto e o reabre após o retorno do seletor de arquivos ou uma reinicialização do processo pelo Android.
- O BuzzTier restaura a Tier List que estava aberta e a posição de rolagem.
- Cada imagem processada em uma importação em massa recebe um ponto de recuperação no IndexedDB. Se o Android encerrar a página, as imagens já processadas são recuperadas ao abrir novamente.
- Os pontos de recuperação ficam associados ao UID da conta, evitando misturar arquivos temporários entre Gmail diferentes.
- O banco local é atualizado de forma compatível: a loja de recuperação é adicionada sem apagar listas existentes.

Limitação: o navegador não oferece a um PWA controle para impedir que o Android suspenda ou encerre seu processo. Esta versão mantém a tela e o trabalho já processado recuperáveis; arquivos que o navegador ainda não recebeu do seletor podem precisar ser selecionados novamente se o Android descartar a seleção.


## v1.8 — Corrigir tela inicial e retomada seletiva

O Hub agora abre sempre na Central, exceto quando há uma intenção temporária válida de retomada do seletor de imagens do BuzzTier. Essa intenção expira em 15 minutos e é removida no retorno normal do seletor ou após a seleção de arquivos.
