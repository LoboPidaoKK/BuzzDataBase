# BuzzHub 2.1 — edição local

Central de aplicativos para BuzzDataBase, BuzzTier e Guarda Links. Esta edição não possui contas, login Google, Firebase, sincronização ou armazenamento em nuvem.

## Como funciona
- Cada aplicativo grava seus dados localmente neste navegador/aparelho.
- O BuzzHub permite exportar um backup JSON combinado dos três aplicativos, incluindo links e capas personalizadas do Guarda Links.
- A importação permite restaurar o BuzzDataBase, o BuzzTier, o Guarda Links ou qualquer combinação deles, escolhendo quais conteúdos substituir.
- O BuzzDataBase, o BuzzTier e o Guarda Links também mantêm suas próprias opções de exportar/importar backup.
- Nenhum dado é enviado automaticamente a um servidor.

## Importante
O armazenamento é local ao navegador e ao aparelho. Limpar os dados do navegador, desinstalar o app ou trocar de dispositivo pode remover o conteúdo local. Exporte backups JSON regularmente e guarde-os fora do aparelho. A versão 2.0 remove o botão “Confirmar Estado”, o botão “Reiniciar” e todo o fluxo de contas/nuvem; não apaga os bancos locais existentes durante a atualização.

## Publicação
Publique o conteúdo desta pasta mantendo a estrutura de diretórios. O Service Worker usa identificadores v2.1-local para atualizar os caches antigos.

MIGRAÇÃO DE DADOS NA NUVEM
A versão 2.0 não acessa nem importa dados que existam somente na antiga nuvem. Ela também não envia comandos para apagar esses dados remotos. Antes de publicar a versão 2.0, abra a versão antiga e exporte os backups disponíveis. Se algum conteúdo existir apenas na nuvem e não estiver presente no armazenamento local ou nos arquivos exportados, ele não aparecerá na versão 2.0.

## Guarda Links

O Guarda Links salva os endereços e as capas personalizadas no armazenamento local do navegador (IndexedDB). Cada capa é comprimida antes de ser salva. Ao tocar na capa, o endereço é aberto em uma nova aba. Os backups próprios e o backup combinado do BuzzHub incluem os links e as imagens de capa.
