BuzzHub 3.2 — BuzzLinks com botão Gerenciar tópicos e edição/exclusão pelo lápis em cada capa. Tela inicial e demais aplicativos preservados.
