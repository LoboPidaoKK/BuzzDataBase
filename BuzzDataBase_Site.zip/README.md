# BuzzHub v1.8

Central de aplicativos para BuzzDataBase e BuzzTier, com login Google compartilhado e conteúdo separado por UID do Firebase.

## O que muda na v1.8

- **Confirmar Estado** salva na nuvem o estado atual do aparelho: obras e capas do BuzzDataBase, listas/tiers e imagens do BuzzTier.
- Uma única confirmação mostra o Gmail de destino e a quantidade de dados que serão enviados.
- Os dois aplicativos são gravados e verificados separadamente; erros são reportados por aplicativo.
- Nunca envia conteúdo local se o UID proprietário conhecido for diferente do Gmail conectado. Conteúdo sem proprietário conhecido exige confirmação explícita para ser associado à conta atual.
- Snapshots locais por conta são preservados ao trocar de Gmail, mesmo quando estavam marcados como sincronizados.
- Se a nuvem estiver vazia, mas houver conteúdo local da mesma conta, o conteúdo local é preservado e fica aguardando confirmação manual.
- Compatibilidade com manifesto vazio antigo do BuzzTier.

## Separação dos dados

- BuzzDataBase: `users/{uid}/items` e metadados em `users/{uid}`.
- BuzzTier: `users/{uid}/apps/buzztier` e seus blocos em `users/{uid}/apps/buzztier/chunks`.
- O UID é validado antes de qualquer gravação. Dados de outros UIDs não são lidos ou alterados durante a confirmação.

## Publicação

Extraia todos os arquivos deste ZIP na raiz do repositório `BuzzDataBase`, substituindo os arquivos anteriores e preservando a estrutura de pastas. Publique pelo GitHub Pages/Actions. Não limpe os dados do navegador nem desinstale o PWA.

Site: https://lobopidaokk.github.io/BuzzDataBase/
