BuzzHub 2.8 — atualização do BuzzDataBase

Projeto estático para GitHub Pages. Inclui BuzzDataBase, BuzzTier e BuzzLinks.
Esta versão atualiza a gestão das capas, o tamanho dos ícones de estrela/lápis e adiciona a marcação “Visto no cinema” com estrela azul e filtro próprio.
A aparência compartilhada continua funcionando; os dados ficam locais no navegador, sem contas ou sincronização na nuvem.
