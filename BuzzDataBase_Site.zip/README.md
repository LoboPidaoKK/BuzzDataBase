# BuzzHub 2.0 — edição local

Central de aplicativos para BuzzDataBase e BuzzTier. Esta edição não possui contas, login Google, Firebase, sincronização ou armazenamento em nuvem.

## Como funciona
- Cada aplicativo grava seus dados localmente neste navegador/aparelho.
- O BuzzHub permite exportar um backup JSON combinado dos dois aplicativos.
- A importação permite restaurar o BuzzDataBase, o BuzzTier ou ambos, escolhendo quais conteúdos substituir.
- O BuzzDataBase e o BuzzTier também mantêm suas próprias opções de exportar/importar backup.
- Nenhum dado é enviado automaticamente a um servidor.

## Importante
O armazenamento é local ao navegador e ao aparelho. Limpar os dados do navegador, desinstalar o app ou trocar de dispositivo pode remover o conteúdo local. Exporte backups JSON regularmente e guarde-os fora do aparelho. A versão 2.0 remove o botão “Confirmar Estado”, o botão “Reiniciar” e todo o fluxo de contas/nuvem; não apaga os bancos locais existentes durante a atualização.

## Publicação
Publique o conteúdo desta pasta mantendo a estrutura de diretórios. O Service Worker usa identificadores v2.0-local para atualizar os caches antigos.

MIGRAÇÃO DE DADOS NA NUVEM
A versão 2.0 não acessa nem importa dados que existam somente na antiga nuvem. Ela também não envia comandos para apagar esses dados remotos. Antes de publicar a versão 2.0, abra a versão antiga e exporte os backups disponíveis. Se algum conteúdo existir apenas na nuvem e não estiver presente no armazenamento local ou nos arquivos exportados, ele não aparecerá na versão 2.0.
