# BuzzHub 1.7

Centraliza BuzzDataBase e BuzzTier em uma única página e sessão Google.

## Correções da v1.7

- O BuzzTier dentro do Hub agora usa o IndexedDB `BuzzHubTierDatabase`, separado da versão independente (`BuzzTierDatabase`). Os dois endereços do GitHub Pages usam a mesma origem `lobopidaokk.github.io`, mesmo em caminhos diferentes.
- Na primeira abertura, o Hub copia os dados do banco antigo por leitura somente. A base anterior não é apagada.
- A restauração da nuvem valida os blocos, o tamanho do JSON e a quantidade de listas antes de aplicar os dados.
- A gravação local é verificada antes de substituir o estado ativo; mensagens de erro agora incluem o motivo do navegador.
- Contas sem listas e sem backup não geram snapshots vazios automaticamente.
- A importação de backup combinado permite escolher BuzzDataBase, BuzzTier ou ambos.
- Importar JSON altera somente os dados locais; publicar na nuvem depende de `Confirmar Estado`.
- Service Workers e referências de módulos receberam versões novas para evitar usar scripts antigos do cache.

## Dados e nuvem

- BuzzDataBase: `users/{uid}/items` e metadados em `users/{uid}`.
- BuzzTier: manifesto e blocos em `users/{uid}/apps/buzztier`.
- O caminho Firestore do BuzzTier foi mantido para tentar recuperar o backup já existente.
- `Reiniciar` limpa os dados locais do Hub e desconecta a conta; não apaga documentos do Firestore.

## Publicação

Extraia todo o conteúdo deste ZIP na raiz do repositório `BuzzDataBase`, substituindo os arquivos antigos e preservando a estrutura. Publique pelo GitHub Pages/Actions como antes. Não limpe os dados do navegador para atualizar.

Site: `https://lobopidaokk.github.io/BuzzDataBase/`

Mantenha uma cópia do JSON. Depois de publicar, aguarde a leitura da conta e confira o estado restaurado antes de usar `Confirmar Estado`.
