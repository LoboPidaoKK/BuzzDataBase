# BuzzHub 1.7

Centraliza BuzzDataBase 1.31, BuzzTier 1.21 e BuzzPin 0.1 em uma única página e sessão Google.

## Correção de sincronização nesta versão

- Cada coleção fica vinculada ao UID do Gmail no Firestore.
- Ao trocar de Gmail, o estado local anterior é preservado em um cache IndexedDB separado por aplicativo e UID.
- O aplicativo passa a carregar o snapshot remoto da conta selecionada; não mistura listas/obras locais de outro Gmail.
- Se uma conta ainda não tiver cópia na nuvem, só pode restaurar o cache local que pertence ao mesmo UID; caso contrário, inicia vazia.
- Alterações locais pendentes da própria conta são preservadas e podem ser confirmadas sem migrar dados para outro Gmail.

O cache por UID é local ao navegador/aparelho. O Firestore continua sendo a cópia na nuvem.

Veja `LEIA-ME_BUZZHUB.txt` para publicação e configuração.

## BuzzDataBase v1.30

O salvamento agora é incremental: capas e registros inalterados não são regravados no IndexedDB. A busca e a grade também foram otimizadas para catálogos grandes.

## Atualização v1.5 — recarregar os backups ao trocar de Gmail

Ao trocar de conta, os dois aplicativos consultam o Firebase automaticamente. Uma barra de progresso aparece logo abaixo do cartão da conta e combina o andamento do BuzzDataBase e do BuzzTier. O BuzzDataBase força leitura do servidor; o BuzzTier mostra a leitura dos blocos em lotes.

Os dados locais e remotos não são apagados. Publique todo o conteúdo deste ZIP na raiz do repositório.


## v1.6 — atualização de conta
Ao concluir a seleção de um Gmail, o Hub executa uma recarga real da página para recriar os dois iframes e reiniciar a leitura de backups em ambos os aplicativos. Uma mudança de UID observada diretamente pelo Firebase também dispara essa recarga. Um marcador de sessão impede loops e posiciona a tela no topo após a atualização.


## v1.7 — BuzzPin integrado
O BuzzPin agora aparece como terceiro aplicativo na tela inicial e abre dentro do Hub. Nesta primeira versão, ele importa imagens escolhidas no aparelho e gera um ZIP com as selecionadas. Ele ainda não está conectado ao Pinterest. O backup, a sincronização e o botão Reiniciar continuam gerenciando apenas BuzzDataBase e BuzzTier, pois o BuzzPin ainda não possui conta ou armazenamento próprio.
