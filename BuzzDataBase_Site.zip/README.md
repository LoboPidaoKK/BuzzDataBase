# BuzzHub v1.8

Central de aplicativos BuzzDataBase + BuzzTier.

## Atualização
Extraia o ZIP na raiz do repositório BuzzDataBase e publique pelo GitHub Pages. Exporte um backup antes. Não remova o IndexedDB nem limpe os dados do navegador.

## Mudanças v1.8
- Um app por vez na memória; frames carregam sob demanda.
- Recuperação da rota e da lista do BuzzTier ao voltar do seletor Android ou após recriação do processo.
- Seletor de imagens aceita MIME genérico/ausente e identifica formatos pelo cabeçalho quando possível.
- Importação de imagens salva checkpoints locais a cada três arquivos e agrupa uma única sincronização na nuvem.
- Leitura do Firestore em lotes e hashes de blocos reduzem consultas e reenvios.
- BuzzTier e BuzzDataBase evitam ler ou regravar snapshots que já estão confirmados e inalterados.
- Confirmação do BuzzTier reaproveita o manifesto já consultado, deixa a limpeza de blocos antigos em segundo plano e mantém a proteção transacional contra alterações concorrentes.

Apps: BuzzDataBase v1.31; BuzzTier lógica v1.23. A versão visível da Central é BuzzHub v1.8.
