# BuzzHub 1.0

Central de aplicativos que reúne o BuzzDataBase 1.29 e o BuzzTier 1.21.

- Login Google compartilhado.
- Firestore com dados separados por aplicativo.
- Backup/restauração combinado em JSON.
- Confirmação de estado nos dois aplicativos.
- Reiniciar limpa dados locais e mantém os dados na nuvem.

Veja `LEIA-ME_BUZZHUB.txt` para publicação e configuração.
