# BuzzHub 3.0 — pacote do site para GitHub Pages

Este ZIP contém o site completo, com `index.html` diretamente na raiz, a tela inicial do BuzzHub e os quatro aplicativos: BuzzDataBase, BuzzTier, BuzzLinks e BuzzDash.

## Publicação com o workflow que já existe no repositório

1. Baixe este ZIP e renomeie o arquivo para `BuzzDataBase_Site.zip` (respeite maiúsculas, minúsculas e `_`).
2. Envie esse arquivo para a raiz do repositório `LoboPidaoKK/BuzzDataBase`, substituindo o arquivo anterior com o mesmo nome. Não extraia o conteúdo manualmente: o workflow atual faz a extração.
3. Faça o commit do envio. O workflow existente `Publicar BuzzDataBase` procura exatamente `BuzzDataBase_Site.zip` e executa `unzip -o BuzzDataBase_Site.zip -d _site`.
4. Na aba Actions, confirme que a etapa `Preparar site` terminou sem erro e que a execução foi concluída.

O ZIP foi preparado para o comando acima: `index.html` está na raiz interna, sem uma pasta externa envolvendo todos os arquivos. O pacote não inclui nem exige troca do arquivo `.github/workflows/publish.yml`.

**Configuração do Pages:** o workflow existente usa `actions/deploy-pages`; a fonte de publicação do GitHub Pages precisa estar configurada como `GitHub Actions`. Se essa já é a configuração que publicou versões anteriores, não altere nada.

## Atualização 3.0

- Mantém a tela inicial do BuzzHub e os quatro aplicativos.
- BuzzDash 3.0 organiza por aplicativo, tópico/lista e mostra as imagens da lista inteira sem separar tiers.
- Atualiza os identificadores dos caches de BuzzDataBase, BuzzTier e BuzzLinks para que instalações antigas atualizem os arquivos de interface.
- Não apaga nem recria os bancos de dados locais e não altera os formatos de backup.
