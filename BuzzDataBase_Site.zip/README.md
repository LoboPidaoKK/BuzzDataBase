BuzzHub 2.12 — BuzzDash organizado por tópicos e tiers.

O BuzzDash agora separa as coleções do BuzzDataBase por tópicos e as coleções do BuzzTier por lista e tier. O carrossel mostra uma coleção por vez. O ícone do BuzzDash na tela inicial foi ampliado opticamente para combinar com os outros cartões.
