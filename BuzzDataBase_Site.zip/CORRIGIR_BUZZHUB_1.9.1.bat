@echo off
setlocal
cd /d "%~dp0"
echo Corrigindo o BuzzHub 1.9 para a versao 1.9.1...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0CORRIGIR_BUZZHUB_1.9.1.ps1"
if errorlevel 1 (
  echo.
  echo A correcao nao foi aplicada. Leia a mensagem acima e mantenha a pasta original.
  pause
  exit /b 1
)
echo.
echo Abra a pasta acima e procure BuzzHub_v1.9.1_Corrigido.zip.
pause
endlocal
