import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/13.1.0/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence,
  signOut
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCwZ7b0jcJbkPr-ZITmuLNOw3CgNYqV7-4",
  authDomain: "buzzdatabase0.firebaseapp.com",
  projectId: "buzzdatabase0",
  storageBucket: "buzzdatabase0.firebasestorage.app",
  messagingSenderId: "960232212219",
  appId: "1:960232212219:web:a7309f66eb1daa4bbe125e",
  measurementId: "G-Z6VDBNRKF4"
};

const app = getApps().find(candidate => candidate.name === "[DEFAULT]") || initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();
provider.setCustomParameters({ prompt: 'select_account' });

const $ = id => document.getElementById(id);
const homeView = $('homeView');
const appView = $('appView');
const databaseFrame = $('databaseFrame');
const tierFrame = $('tierFrame');
const accountControl = $('accountControl');
let authReady = false;
let currentUser = null;
let activeApp = null;
let operationBusy = false;
let lastHubStatus = '';
let deferredInstallPrompt = null;
let installedAsApp = window.matchMedia?.('(display-mode: standalone)').matches || navigator.standalone === true;
let observedHubUid = null;
let authInitialStateSeen = false;
let accountRefreshState = null;
const pendingAccountProgress = new Map();
const LAST_ACTIVE_APP_KEY = 'buzzhub.last-active-app.v1';
const frameLoadPromises = new WeakMap();
const accountSyncWaiters = new Map();
let accountWarmupUid = null;
let accountWarmupPromise = null;

function ensureFrameLoaded(frame) {
  if (frame?.dataset.loaded === 'true') return Promise.resolve();
  const currentSrc = frame?.getAttribute('src') || '';
  if (currentSrc && currentSrc !== 'about:blank' && frame.dataset.unloaded !== 'true') return Promise.resolve();
  const existing = frameLoadPromises.get(frame);
  if (existing) return existing;
  const source = frame?.dataset.src;
  if (!source) return Promise.reject(new Error('O endereço do aplicativo não está configurado.'));
  const promise = new Promise((resolve, reject) => {
    const timeout = window.setTimeout(() => {
      frame.removeEventListener('load', onLoad);
      frame.dataset.loaded = 'false';
      frameLoadPromises.delete(frame);
      reject(new Error('O aplicativo não respondeu ao carregamento. Verifique a conexão e tente novamente.'));
    }, 30000);
    const onLoad = () => {
      if (frame.dataset.loaded !== 'loading') return;
      try { if (frame.contentWindow?.location?.href === 'about:blank') return; } catch (_) {}
      window.clearTimeout(timeout);
      frame.dataset.loaded = 'true';
      frame.dataset.unloaded = 'false';
      frame.removeEventListener('load', onLoad);
      frameLoadPromises.delete(frame);
      resolve();
    };
    frame.addEventListener('load', onLoad);
    frame.dataset.loaded = 'loading';
    frame.src = source;
  }).catch(error => { frameLoadPromises.delete(frame); throw error; });
  frameLoadPromises.set(frame, promise);
  return promise;
}

function unloadFrame(frame) {
  if (!frame) return;
  const currentSrc = frame.getAttribute('src') || '';
  if (!currentSrc || currentSrc === 'about:blank') return;
  try { frame.dataset.unloaded = 'true'; frame.src = 'about:blank'; } catch (_) {}
  frame.dataset.loaded = 'false';
  frameLoadPromises.delete(frame);
}

function rememberActiveApp(key) {
  try {
    if (key) localStorage.setItem(LAST_ACTIVE_APP_KEY, JSON.stringify({ key, at: Date.now() }));
    else localStorage.removeItem(LAST_ACTIVE_APP_KEY);
  } catch (_) {}
}

function restoreLastActiveApp() {
  try {
    const saved = JSON.parse(localStorage.getItem(LAST_ACTIVE_APP_KEY) || 'null');
    if (!saved || !['database', 'tier'].includes(saved.key) || Date.now() - Number(saved.at || 0) > 24 * 60 * 60 * 1000) {
      rememberActiveApp(null);
      return;
    }
    openApp(saved.key, { restore: true });
  } catch (_) { rememberActiveApp(null); }
}

// After a Google account change, reload the whole Hub once. This recreates both
// isolated app frames so each Firebase Auth instance starts with the selected UID.
// The session marker prevents a reload loop while still allowing a same-account
// re-login after the user pressed "Reiniciar".
const ACCOUNT_RELOAD_MARKER = 'buzzhub.account-reload.v1';
const HUB_PAGE_INSTANCE = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
let accountReloadRequested = false;

function readAccountReloadMarker() {
  try { return JSON.parse(sessionStorage.getItem(ACCOUNT_RELOAD_MARKER) || 'null'); }
  catch (_) { return null; }
}
function clearAccountReloadMarker() {
  try { sessionStorage.removeItem(ACCOUNT_RELOAD_MARKER); } catch (_) {}
}
function consumeAccountReloadMarker(uid) {
  const marker = readAccountReloadMarker();
  if (!marker) return false;
  if (Date.now() - Number(marker.createdAt || 0) > 45000) {
    clearAccountReloadMarker();
    return false;
  }
  if (marker.uid === uid && marker.pageInstance !== HUB_PAGE_INSTANCE) {
    clearAccountReloadMarker();
    requestAnimationFrame(() => requestAnimationFrame(() => window.scrollTo({ top: 0, left: 0, behavior: 'instant' })));
    return true;
  }
  return false;
}
function forceAccountPageReload(user, reason = 'account-change') {
  if (!user?.uid || accountReloadRequested) return;
  const existing = readAccountReloadMarker();
  if (existing?.uid === user.uid && existing.pageInstance === HUB_PAGE_INSTANCE) return;
  accountReloadRequested = true;
  try {
    sessionStorage.setItem(ACCOUNT_RELOAD_MARKER, JSON.stringify({
      uid: user.uid,
      pageInstance: HUB_PAGE_INSTANCE,
      reason,
      createdAt: Date.now()
    }));
  } catch (_) {
    // The in-memory guard still prevents multiple reload requests on this page.
  }
  setStatus('Conta atualizada. Recarregando o BuzzHub e os dois aplicativos…', 'success');
  window.setTimeout(() => {
    if (auth.currentUser?.uid === user.uid) {
      window.location.reload();
    } else {
      clearAccountReloadMarker();
      accountReloadRequested = false;
    }
  }, 350);
}

function renderAccountSyncProgress() {
  const state = accountRefreshState;
  const box = $('accountSyncBox');
  if (!state || !box) return;
  const apps = ['database', 'tier'];
  const values = apps.map(key => state.apps[key]);
  const average = Math.round(values.reduce((sum, item) => sum + (item?.percent || 0), 0) / apps.length);
  const done = values.filter(item => item?.state === 'complete').length;
  const skipped = values.filter(item => item?.state === 'skipped').length;
  const failed = values.find(item => item?.state === 'error');
  const label = failed
    ? `Falha ao atualizar ${failed.label}`
    : done + skipped === 2
      ? (skipped ? `Conta atualizada; ${skipped === 1 ? 'um aplicativo atualizará ao abrir' : 'os aplicativos atualizarão ao abrir'}` : `Backups atualizados para ${state.email || 'esta conta Google'}`)
      : `Atualizando backups de ${state.email || 'esta conta Google'}…`;
  const percent = failed ? average : done + skipped === 2 ? 100 : average;
  $('accountSyncMessage').textContent = failed ? `${label}: ${failed.message}` : label;
  $('accountSyncPercent').textContent = `${percent}%`;
  $('accountSyncFill').style.width = `${percent}%`;
  $('accountSyncDetails').textContent = apps.map(key => {
    const item = state.apps[key];
    const title = key === 'database' ? 'BuzzDataBase' : 'BuzzTier';
    if (!item) return `${title}: aguardando`;
    const stateText = item.state === 'complete' ? 'concluído' : item.state === 'skipped' ? 'atualiza ao abrir' : item.state === 'error' ? 'erro' : item.message;
    return `${title}: ${item.percent}% · ${stateText}`;
  }).join('  |  ');
  box.classList.add('visible');
  box.classList.toggle('error', !!failed);
}

function beginAccountRefresh(uid, email = '') {
  if (!uid) return;
  if (accountRefreshState?.uid === uid) {
    if (email) accountRefreshState.email = email;
    return;
  }
  accountRefreshState = {
    uid, email,
    apps: {
      database: { percent: 0, message: 'iniciando leitura', state: 'loading', label: 'BuzzDataBase' },
      tier: { percent: 0, message: 'iniciando leitura', state: 'loading', label: 'BuzzTier' }
    }
  };
  renderAccountSyncProgress();
}

function settleAccountSyncWaiters(appKey, uid, result, error = null) {
  const key = `${uid}:${appKey}`;
  const waiters = accountSyncWaiters.get(key);
  if (!waiters?.length) return;
  accountSyncWaiters.delete(key);
  for (const waiter of waiters) {
    window.clearTimeout(waiter.timer);
    if (error) waiter.reject(error);
    else waiter.resolve(result);
  }
}
function waitForAccountAppSync(uid, appKey, timeoutMs = 45000) {
  const current = accountRefreshState?.uid === uid ? accountRefreshState.apps[appKey] : null;
  if (current?.state === 'complete') return Promise.resolve(current);
  if (current?.state === 'error') return Promise.reject(new Error(current.message || 'Falha ao atualizar o backup.'));
  const key = `${uid}:${appKey}`;
  return new Promise((resolve, reject) => {
    const waiter = { resolve, reject, timer: window.setTimeout(() => {
      const list = accountSyncWaiters.get(key) || [];
      const remaining = list.filter(item => item !== waiter);
      if (remaining.length) accountSyncWaiters.set(key, remaining); else accountSyncWaiters.delete(key);
      reject(new Error('O aplicativo não informou a conclusão da atualização dentro do tempo esperado. Abra-o para tentar novamente.'));
    }, timeoutMs) };
    const list = accountSyncWaiters.get(key) || [];
    list.push(waiter);
    accountSyncWaiters.set(key, list);
  });
}
function applyAccountSyncProgress(appKey, uid, percent, message, state = 'loading') {
  beginAccountRefresh(uid, auth.currentUser?.uid === uid ? auth.currentUser.email || '' : '');
  const appState = accountRefreshState.apps[appKey];
  const nextState = state === 'complete' || state === 'error' ? state : 'loading';
  if (appState.state === 'skipped' && nextState === 'loading') appState.percent = 0;
  appState.percent = Math.max(appState.percent || 0, Math.min(100, Math.round(Number(percent) || 0)));
  appState.message = String(message || (nextState === 'complete' ? 'backup atualizado' : 'carregando'));
  appState.state = nextState;
  renderAccountSyncProgress();
  if (nextState === 'complete') settleAccountSyncWaiters(appKey, uid, appState);
  if (nextState === 'error') settleAccountSyncWaiters(appKey, uid, null, new Error(appState.message));
}

function reportAccountSyncProgress(appKey, uid, percent, message, state = 'loading') {
  if (!['database', 'tier'].includes(appKey) || !uid) return;
  const knownUid = auth.currentUser?.uid || observedHubUid;
  // Hold an early report if an iframe notices the account transition just
  // before the Hub's own Firebase observer. Discard reports from old sessions.
  if (knownUid && knownUid !== uid) {
    if (auth.currentUser?.uid === uid) applyAccountSyncProgress(appKey, uid, percent, message, state);
    else pendingAccountProgress.set(uid, { appKey, percent, message, state });
    return;
  }
  applyAccountSyncProgress(appKey, uid, percent, message, state);
}

function clearAccountSyncProgress() {
  accountRefreshState = null;
  const box = $('accountSyncBox');
  if (box) { box.classList.remove('visible', 'error'); $('accountSyncFill').style.width = '0%'; }
}

function setStatus(message, kind = 'info') {
  const el = $('hubStatus');
  if (!el) return;
  el.textContent = String(message || '');
  el.className = `status ${kind}`;
  lastHubStatus = String(message || '');
}
function setAppStatus(appKey, message, kind = 'info') {
  if (appKey === 'tier' && !activeApp) {
    setStatus(message, kind);
    return;
  }
  if (activeApp === appKey) setStatus(message, kind);
}
function setConfirmProgress(percent, message) {
  const n = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
  $('progressBox').classList.add('visible');
  $('progressMessage').textContent = message || 'Sincronizando…';
  $('progressPercent').textContent = `${n}%`;
  $('progressFill').style.width = `${n}%`;
}
function hideProgress() { $('progressBox').classList.remove('visible'); $('progressFill').style.width = '0%'; }
function setBusy(value) {
  operationBusy = !!value;
  for (const id of ['exportBackupBtn','importBackupBtn','confirmStateBtn','restartBtn','accountControl','installHubBtn']) {
    const disabledByState = id === 'accountControl' ? !authReady : id === 'installHubBtn' ? installedAsApp : false;
    $(id).disabled = operationBusy || disabledByState;
  }
}
function setAccount(user) {
  currentUser = user || null;
  const avatar = $('accountAvatar');
  avatar.replaceChildren();
  if (user) {
    if (user.photoURL) {
      const img = document.createElement('img');
      img.src = user.photoURL;
      img.alt = '';
      img.referrerPolicy = 'no-referrer';
      img.onerror = () => { avatar.textContent = (user.displayName || user.email || 'G').slice(0,1).toUpperCase(); };
      avatar.append(img);
    } else avatar.textContent = (user.displayName || user.email || 'G').slice(0,1).toUpperCase();
    $('accountName').textContent = user.displayName || 'Conta Google conectada';
    $('accountEmail').textContent = user.email || 'Conta Google';
    $('accountHint').textContent = 'TROCAR CONTA';
  } else {
    avatar.textContent = 'B';
    $('accountName').textContent = 'Conectar conta Google';
    $('accountEmail').textContent = 'Toque aqui para entrar ou selecionar outro Gmail';
    $('accountHint').textContent = 'CONECTAR';
  }
  accountControl.disabled = !authReady || operationBusy;
}
function openApp(key, options = {}) {
  if (!['database', 'tier'].includes(key)) return;
  activeApp = key;
  rememberActiveApp(key);
  homeView.hidden = true;
  homeView.style.display = 'none';
  appView.classList.add('active');
  const isDb = key === 'database';
  const currentFrame = isDb ? databaseFrame : tierFrame;
  const inactiveFrame = isDb ? tierFrame : databaseFrame;
  databaseFrame.classList.toggle('active', isDb);
  tierFrame.classList.toggle('active', !isDb);
  document.title = `${isDb ? 'BuzzDataBase' : 'BuzzTier'} · BuzzHub`;
  // Only one app runtime may remain in memory. This is especially important
  // on Android while the system file picker is in the foreground.
  unloadFrame(inactiveFrame);
  ensureFrameLoaded(currentFrame).catch(error => {
    console.error('BuzzHub: falha ao abrir aplicativo.', error);
    setStatus(error.message || 'Não foi possível abrir o aplicativo.', 'error');
  });
  if (!options.restore) history.pushState({ buzzApp: key }, '', `#${key}`);
}
function goHome(fromPopState = false) {
  activeApp = null;
  rememberActiveApp(null);
  appView.classList.remove('active');
  databaseFrame.classList.remove('active');
  tierFrame.classList.remove('active');
  // Keep the most recently used app in memory (but keep the other iframe
  // unloaded) so returning from Android's file picker does not restart it.
  homeView.hidden = false;
  homeView.style.display = 'flex';
  document.title = 'BuzzHub — Central de aplicativos';
  if (!fromPopState && location.hash) history.replaceState({}, '', location.pathname + location.search);
}
window.addEventListener('popstate', event => {
  if (activeApp) goHome(true);
});
document.querySelectorAll('[data-open-app]').forEach(button => button.addEventListener('click', () => openApp(button.dataset.openApp)));

function explainLoginError(error) {
  const code = String(error?.code || '');
  if (code.includes('unauthorized-domain')) return 'O domínio do BuzzDataBase precisa estar autorizado no Firebase Authentication.';
  if (code.includes('popup-blocked')) return 'O navegador bloqueou a janela de login. Permita pop-ups para este site e tente novamente.';
  if (code.includes('popup-closed-by-user')) return 'A janela de login foi fechada antes de concluir.';
  if (code.includes('operation-not-allowed')) return 'Ative o provedor Google em Firebase Authentication.';
  if (code.includes('network-request-failed')) return 'Sem conexão com o Firebase. Tente novamente quando estiver online.';
  return error?.message || 'Não foi possível conectar à conta Google.';
}
accountControl.addEventListener('click', () => {
  if (!authReady || operationBusy) return;
  provider.setCustomParameters({ prompt: 'select_account' });
  setStatus(currentUser ? 'Abrindo o seletor de contas Google…' : 'Abrindo o login Google…');
  // Call the popup immediately from the user's click so mobile browsers do not block it.
  signInWithPopup(auth, provider)
    .then(credential => {
      const user = credential.user;
      setStatus(`Conta conectada: ${user.email || 'Google'}. Atualizando os aplicativos…`, 'success');
      // Reload even when the user selected the same Gmail again after Reiniciar.
      forceAccountPageReload(user, 'google-popup-success');
    })
    .catch(error => { console.error('BuzzHub Google login:', error); setStatus(explainLoginError(error), 'error'); });
});

async function waitForBridge(frame, name, timeoutMs = 30000) {
  if (frame?.dataset.unloaded === 'true') await ensureFrameLoaded(frame);
  return new Promise((resolve, reject) => {
    const started = Date.now();
    const check = async () => {
      try {
        const bridge = frame.contentWindow?.[name];
        if (bridge) {
          frame.dataset.loaded = 'true';
          frame.dataset.unloaded = 'false';
          if (typeof bridge.ready === 'function') await bridge.ready();
          resolve(bridge);
          return;
        }
      } catch (error) { reject(error); return; }
      if (Date.now() - started > timeoutMs) { reject(new Error(`O ${name === 'BuzzApp' ? 'BuzzDataBase' : 'BuzzTier'} ainda não terminou de carregar.`)); return; }
      setTimeout(check, 100);
    };
    check();
  });
}
async function withAppBridge(appKey, callback) {
  const isDb = appKey === 'database';
  const frame = isDb ? databaseFrame : tierFrame;
  const other = isDb ? tierFrame : databaseFrame;
  const bridgeName = isDb ? 'BuzzApp' : 'BuzzTierBridge';
  if (!activeApp) unloadFrame(other);
  if (activeApp && activeApp !== appKey) throw new Error('Volte à Central para usar esta ação com segurança.');
  await ensureFrameLoaded(frame);
  const bridge = await waitForBridge(frame, bridgeName);
  try { return await callback(bridge); }
  finally { if (!activeApp) unloadFrame(frame); }
}
function releaseInactiveFrameAfterHubAction() {
  if (activeApp === 'database') unloadFrame(tierFrame);
  else if (activeApp === 'tier') unloadFrame(databaseFrame);
  else { unloadFrame(databaseFrame); unloadFrame(tierFrame); }
}
async function refreshAccountAppsSequentially(user) {
  if (!user?.uid || auth.currentUser?.uid !== user.uid) return;
  if (accountWarmupUid === user.uid) return accountWarmupPromise || Promise.resolve();
  accountWarmupUid = user.uid;
  accountWarmupPromise = (async () => {
    const queue = activeApp ? [activeApp] : ['database', 'tier'];
    if (activeApp) {
      const other = activeApp === 'database' ? 'tier' : 'database';
      const skipped = accountRefreshState?.apps?.[other];
      if (skipped) { skipped.percent = 100; skipped.state = 'skipped'; skipped.message = 'Atualiza ao abrir para poupar memória'; }
      renderAccountSyncProgress();
    }
    for (const key of queue) {
      if (auth.currentUser?.uid !== user.uid) break;
      const frame = key === 'database' ? databaseFrame : tierFrame;
      const otherFrame = key === 'database' ? tierFrame : databaseFrame;
      const name = key === 'database' ? 'BuzzApp' : 'BuzzTierBridge';
      try {
        unloadFrame(otherFrame);
        await ensureFrameLoaded(frame);
        await waitForBridge(frame, name, 45000);
        await waitForAccountAppSync(user.uid, key, 60000);
      } catch (error) {
        console.warn(`BuzzHub: atualização de ${key} não terminou automaticamente.`, error);
        if (auth.currentUser?.uid === user.uid) applyAccountSyncProgress(key, user.uid, accountRefreshState?.apps?.[key]?.percent || 0, error.message, 'error');
      } finally {
        if (!activeApp) unloadFrame(frame);
      }
    }
  })().finally(() => { accountWarmupPromise = null; });
  return accountWarmupPromise;
}
function downloadJson(payload, filename) {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url; link.download = filename;
  document.body.append(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function safeFileBase(value) {
  return String(value || 'BuzzHub').split('@')[0].normalize('NFKC').replace(/[<>:"/\\|?*\u0000-\u001F]/g, '').replace(/\s+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'BuzzHub';
}

$('exportBackupBtn').addEventListener('click', async () => {
  if (operationBusy) return;
  setBusy(true); setStatus('Preparando backup completo dos dois aplicativos…');
  try {
    const databaseState = await withAppBridge('database', bridge => bridge.getBackupState());
    const tierState = await withAppBridge('tier', bridge => bridge.getBackupState());
    const payload = {
      app: 'BuzzHub', schemaVersion: 1, hubVersion: '1.8', exportedAt: new Date().toISOString(),
      account: currentUser ? { email: currentUser.email || '', displayName: currentUser.displayName || '' } : null,
      apps: { buzzdatabase: databaseState, buzztier: tierState }
    };
    downloadJson(payload, `${safeFileBase(currentUser?.email || 'BuzzHub')}-BuzzHub-backup.json`);
    setStatus('Backup completo dos aplicativos exportado.', 'success');
  } catch (error) { console.error(error); setStatus(error.message || 'Não foi possível exportar o backup.', 'error'); }
  finally { setBusy(false); releaseInactiveFrameAfterHubAction(); }
});

$('importBackupBtn').addEventListener('click', () => { if (!operationBusy) $('backupFile').click(); });
$('backupFile').addEventListener('change', async event => {
  const file = event.target.files?.[0];
  if (!file || operationBusy) return;
  setBusy(true); setStatus('Lendo o arquivo de backup…');
  try {
    const raw = JSON.parse(await file.text());
    let apps = raw?.app === 'BuzzHub' && raw.apps && typeof raw.apps === 'object' ? raw.apps : null;
    if (!apps) {
      apps = {};
      if (raw?.app === 'BuzzDataBase' && Array.isArray(raw.items)) apps.buzzdatabase = raw;
      else if (raw?.app === 'BuzzTier' && Array.isArray(raw.lists)) apps.buzztier = raw;
      else if (Array.isArray(raw?.lists)) apps.buzztier = raw;
    }
    const hasDb = !!apps?.buzzdatabase && Array.isArray(apps.buzzdatabase.items);
    const hasTier = !!apps?.buzztier && Array.isArray(apps.buzztier.lists);
    if (!hasDb && !hasTier) throw new Error('Esse arquivo não contém um backup válido do BuzzHub, BuzzDataBase ou BuzzTier.');
    const summary = [hasDb ? `${apps.buzzdatabase.items.length} obras do BuzzDataBase` : '', hasTier ? `${apps.buzztier.lists.length} listas do BuzzTier` : ''].filter(Boolean).join(' e ');
    if (!confirm(`Importar ${summary}?\n\nOs dados locais correspondentes serão substituídos. As cópias atuais da nuvem não serão apagadas automaticamente; após importar, confirme o estado para publicar essa versão na nuvem.`)) return;
    if (hasDb) { setStatus('Restaurando BuzzDataBase…'); await withAppBridge('database', bridge => bridge.importBackupState(apps.buzzdatabase)); }
    if (hasTier) { setStatus('Restaurando BuzzTier…'); await withAppBridge('tier', bridge => bridge.importBackupState(apps.buzztier)); }
    setStatus(`Backup importado com sucesso: ${summary}. Use “Confirmar Estado” para conferir as duas cópias na nuvem.`, 'success');
  } catch (error) { console.error(error); setStatus(error.message || 'Não foi possível importar o backup.', 'error'); }
  finally { event.target.value = ''; setBusy(false); releaseInactiveFrameAfterHubAction(); }
});

$('confirmStateBtn').addEventListener('click', async () => {
  if (operationBusy) return;
  if (!currentUser) { setStatus('Conecte sua conta Google antes de confirmar o estado dos aplicativos.', 'warning'); accountControl.focus(); return; }
  setBusy(true); setConfirmProgress(0, 'Preparando confirmação dos dois aplicativos…');
  try {
    setConfirmProgress(2, 'Confirmando o estado do BuzzDataBase…');
    const dbOk = await withAppBridge('database', bridge => bridge.confirmState());
    if (!dbOk) throw new Error('O BuzzDataBase não concluiu a confirmação. O BuzzTier não foi alterado nesta operação.');
    setConfirmProgress(52, 'Confirmando o estado do BuzzTier…');
    const tierOk = await withAppBridge('tier', bridge => bridge.confirmState());
    if (!tierOk) throw new Error('O BuzzTier não concluiu a confirmação. O estado já confirmado do BuzzDataBase permanece salvo.');
    setConfirmProgress(100, 'Os dois aplicativos foram confirmados na nuvem.');
    setStatus('Estado confirmado nos dois aplicativos: BuzzDataBase e BuzzTier. 💜', 'success');
    setTimeout(hideProgress, 4500);
  } catch (error) { console.error(error); setStatus(error.message || 'Não foi possível confirmar o estado dos aplicativos.', 'error'); }
  finally { setBusy(false); releaseInactiveFrameAfterHubAction(); }
});

$('restartBtn').addEventListener('click', async () => {
  if (operationBusy) return;
  const accepted = confirm('Reiniciar o BuzzHub neste aparelho?\n\nIsso vai desconectar a conta Google e limpar os dados locais do BuzzDataBase e do BuzzTier.\n\nAs coleções e imagens já salvas no Firestore NÃO serão apagadas. Ao entrar novamente com o mesmo Gmail, os aplicativos poderão carregar as cópias da nuvem.\n\nExporte um backup antes, por segurança.');
  if (!accepted) return;
  setBusy(true); setStatus('Desconectando a conta e limpando somente os dados locais…');
  try {
    await withAppBridge('database', bridge => bridge.resetForHub());
    await withAppBridge('tier', bridge => bridge.resetLocalData());
    if (auth.currentUser) await signOut(auth);
    setAccount(null);
    setStatus('Aparelho reiniciado. As duas cópias na nuvem foram preservadas. Entre novamente com o Gmail para recuperá-las.', 'success');
  } catch (error) { console.error(error); setStatus(error.message || 'Não foi possível reiniciar com segurança. Os dados locais que não foram limpos continuam preservados.', 'error'); }
  finally { setBusy(false); releaseInactiveFrameAfterHubAction(); }
});

window.addEventListener('message', event => {
  if (event.origin !== location.origin || event.source !== databaseFrame.contentWindow) return;
  if (event.data?.type === 'BUZZ_DB_PROGRESS') setConfirmProgress(event.data.percent, event.data.message);
});

window.addEventListener('pagehide', () => { if (activeApp) rememberActiveApp(activeApp); });
window.addEventListener('pageshow', event => {
  if (event.persisted && activeApp) {
    const frame = activeApp === 'database' ? databaseFrame : tierFrame;
    ensureFrameLoaded(frame).catch(error => setStatus(error.message || 'Não foi possível restaurar o aplicativo.', 'error'));
  }
});

function prepareForExternalPicker(appKey) {
  if (!['database', 'tier'].includes(appKey)) return false;
  rememberActiveApp(appKey);
  return true;
}
window.BuzzHub = { setAppStatus, setConfirmProgress, setStatus, reportAccountSyncProgress, prepareForExternalPicker };

function renderInstallButton() {
  const button = $('installHubBtn');
  if (!button) return;
  if (installedAsApp) {
    button.disabled = true;
    button.innerHTML = '<span class="install-hub-icon">✓</span><span>App instalado</span>';
    button.setAttribute('aria-label', 'BuzzHub já está instalado');
  } else {
    button.disabled = operationBusy;
    button.innerHTML = '<span class="install-hub-icon">⇩</span><span>Baixar App</span>';
    button.setAttribute('aria-label', 'Instalar BuzzHub como aplicativo');
  }
}

window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault();
  deferredInstallPrompt = event;
  renderInstallButton();
});

window.addEventListener('appinstalled', () => {
  installedAsApp = true;
  deferredInstallPrompt = null;
  renderInstallButton();
  setStatus('BuzzHub instalado com sucesso neste aparelho.', 'success');
});

$('installHubBtn')?.addEventListener('click', async () => {
  if (installedAsApp) return;
  if (deferredInstallPrompt) {
    const installPrompt = deferredInstallPrompt;
    deferredInstallPrompt = null;
    try {
      await installPrompt.prompt();
      const choice = await installPrompt.userChoice;
      if (choice?.outcome === 'accepted') {
        setStatus('Instalação do BuzzHub iniciada.', 'success');
      } else {
        setStatus('Instalação cancelada. Você pode instalar depois pelo navegador.', 'info');
      }
    } catch (error) {
      console.warn('BuzzHub: prompt de instalação indisponível.', error);
      showInstallInstructions();
    }
    return;
  }
  showInstallInstructions();
});

function showInstallInstructions() {
  const isAppleMobile = /iPhone|iPad|iPod/i.test(navigator.userAgent) && !window.MSStream;
  const instructions = isAppleMobile
    ? 'Para instalar no iPhone/iPad: abra o BuzzHub no Safari, toque em Compartilhar e escolha “Adicionar à Tela de Início”.'
    : 'Para instalar: abra o menu do navegador (⋮ ou ⋯) e escolha “Instalar app” ou “Adicionar à tela inicial”.';
  setStatus(instructions, 'warning');
}

renderInstallButton();
restoreLastActiveApp();

const persistenceReady = setPersistence(auth, browserLocalPersistence).then(() => {
  authReady = true;
  accountControl.disabled = false;
}).catch(error => {
  console.warn('BuzzHub: persistência local do login não pôde ser ajustada.', error);
  authReady = true;
  accountControl.disabled = false;
});
onAuthStateChanged(auth, user => {
  const nextUid = user?.uid || null;
  const previousUid = observedHubUid;
  const hadInitialAuthState = authInitialStateSeen;
  const accountChanged = nextUid !== previousUid;
  const isPostReload = !!(nextUid && consumeAccountReloadMarker(nextUid));
  observedHubUid = nextUid;
  authInitialStateSeen = true;
  setAccount(user);
  if (user) {
    if (accountChanged) beginAccountRefresh(user.uid, user.email || user.displayName || 'Google');
    const pending = pendingAccountProgress.get(user.uid);
    if (pending) {
      pendingAccountProgress.delete(user.uid);
      applyAccountSyncProgress(pending.appKey, user.uid, pending.percent, pending.message, pending.state);
    }
    for (const uid of pendingAccountProgress.keys()) if (uid !== user.uid) pendingAccountProgress.delete(uid);
    setStatus(`Conectado como ${user.email || user.displayName || 'Google'}. Atualizando os backups dos dois aplicativos…`, 'success');
    // Covers account changes initiated outside this page's Google popup too.
    // Initial page startup is intentionally excluded; only subsequent changes reload.
    if (hadInitialAuthState && accountChanged && !isPostReload) {
      forceAccountPageReload(user, 'firebase-auth-state-change');
    } else if (!hadInitialAuthState || isPostReload || !accountWarmupUid) {
      persistenceReady.then(() => refreshAccountAppsSequentially(user)).catch(error => {
        console.warn('BuzzHub: atualização inicial dos aplicativos não terminou.', error);
      });
    }
  } else {
    pendingAccountProgress.clear();
    clearAccountSyncProgress();
    if (authReady) setStatus('Sem conta conectada. Toque no perfil para entrar com Google.');
  }
});
persistenceReady.catch(() => {});

// The app frames load on demand. When the Hub is on Home, account warm-up
// opens each app sequentially and unloads it before starting the next one.
window.addEventListener('load', () => {
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    navigator.serviceWorker.register('./sw.js', { updateViaCache: 'none' })
      .then(registration => registration.update().catch(() => {}))
      .catch(error => console.warn('BuzzHub: service worker indisponível.', error));
  }
});
