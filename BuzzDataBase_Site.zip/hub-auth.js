import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/13.1.0/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence,
  signOut
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCwZ7b0jcJbkPr-ZITmuLNOw3CgNYqV7-4",
  authDomain: "buzzdatabase0.firebaseapp.com",
  projectId: "buzzdatabase0",
  storageBucket: "buzzdatabase0.firebasestorage.app",
  messagingSenderId: "960232212219",
  appId: "1:960232212219:web:a7309f66eb1daa4bbe125e",
  measurementId: "G-Z6VDBNRKF4"
};

const app = getApps().find(candidate => candidate.name === "[DEFAULT]") || initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();
provider.setCustomParameters({ prompt: 'select_account' });

const $ = id => document.getElementById(id);
const homeView = $('homeView');
const appView = $('appView');
const databaseFrame = $('databaseFrame');
const tierFrame = $('tierFrame');
const accountControl = $('accountControl');
let authReady = false;
let currentUser = null;
let activeApp = null;
let operationBusy = false;
let lastHubStatus = '';
let deferredInstallPrompt = null;
let installedAsApp = window.matchMedia?.('(display-mode: standalone)').matches || navigator.standalone === true;
let observedHubUid = null;
let authInitialStateSeen = false;
let accountRefreshState = null;
const pendingAccountProgress = new Map();

// After a Google account change, reload the whole Hub once. This recreates both
// isolated app frames so each Firebase Auth instance starts with the selected UID.
// The session marker prevents a reload loop while still allowing a same-account
// re-login after the user pressed "Reiniciar".
const ACCOUNT_RELOAD_MARKER = 'buzzhub.account-reload.v1';
const HUB_PAGE_INSTANCE = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
let accountReloadRequested = false;

function readAccountReloadMarker() {
  try { return JSON.parse(sessionStorage.getItem(ACCOUNT_RELOAD_MARKER) || 'null'); }
  catch (_) { return null; }
}
function clearAccountReloadMarker() {
  try { sessionStorage.removeItem(ACCOUNT_RELOAD_MARKER); } catch (_) {}
}
function consumeAccountReloadMarker(uid) {
  const marker = readAccountReloadMarker();
  if (!marker) return false;
  if (Date.now() - Number(marker.createdAt || 0) > 45000) {
    clearAccountReloadMarker();
    return false;
  }
  if (marker.uid === uid && marker.pageInstance !== HUB_PAGE_INSTANCE) {
    clearAccountReloadMarker();
    requestAnimationFrame(() => requestAnimationFrame(() => window.scrollTo({ top: 0, left: 0, behavior: 'instant' })));
    return true;
  }
  return false;
}
function forceAccountPageReload(user, reason = 'account-change') {
  if (!user?.uid || accountReloadRequested) return;
  const existing = readAccountReloadMarker();
  if (existing?.uid === user.uid && existing.pageInstance === HUB_PAGE_INSTANCE) return;
  accountReloadRequested = true;
  try {
    sessionStorage.setItem(ACCOUNT_RELOAD_MARKER, JSON.stringify({
      uid: user.uid,
      pageInstance: HUB_PAGE_INSTANCE,
      reason,
      createdAt: Date.now()
    }));
  } catch (_) {
    // The in-memory guard still prevents multiple reload requests on this page.
  }
  setStatus('Conta atualizada. Recarregando o BuzzHub e os dois aplicativos…', 'success');
  window.setTimeout(() => {
    if (auth.currentUser?.uid === user.uid) {
      window.location.reload();
    } else {
      clearAccountReloadMarker();
      accountReloadRequested = false;
    }
  }, 350);
}

function renderAccountSyncProgress() {
  const state = accountRefreshState;
  const box = $('accountSyncBox');
  if (!state || !box) return;
  const apps = ['database', 'tier'];
  const values = apps.map(key => state.apps[key]);
  const average = Math.round(values.reduce((sum, item) => sum + (item?.percent || 0), 0) / apps.length);
  const done = values.filter(item => item?.state === 'complete').length;
  const failed = values.find(item => item?.state === 'error');
  const label = failed
    ? `Falha ao atualizar ${failed.label}`
    : done === 2
      ? `Backups atualizados para ${state.email || 'esta conta Google'}`
      : `Atualizando backups de ${state.email || 'esta conta Google'}…`;
  const percent = failed ? average : done === 2 ? 100 : average;
  $('accountSyncMessage').textContent = failed ? `${label}: ${failed.message}` : label;
  $('accountSyncPercent').textContent = `${percent}%`;
  $('accountSyncFill').style.width = `${percent}%`;
  $('accountSyncDetails').textContent = apps.map(key => {
    const item = state.apps[key];
    const title = key === 'database' ? 'BuzzDataBase' : 'BuzzTier';
    if (!item) return `${title}: aguardando`;
    const stateText = item.state === 'complete' ? 'concluído' : item.state === 'error' ? 'erro' : item.message;
    return `${title}: ${item.percent}% · ${stateText}`;
  }).join('  |  ');
  box.classList.add('visible');
  box.classList.toggle('error', !!failed);
}

function beginAccountRefresh(uid, email = '') {
  if (!uid) return;
  if (accountRefreshState?.uid === uid) {
    if (email) accountRefreshState.email = email;
    return;
  }
  accountRefreshState = {
    uid, email,
    apps: {
      database: { percent: 0, message: 'iniciando leitura', state: 'loading', label: 'BuzzDataBase' },
      tier: { percent: 0, message: 'iniciando leitura', state: 'loading', label: 'BuzzTier' }
    }
  };
  renderAccountSyncProgress();
}

function applyAccountSyncProgress(appKey, uid, percent, message, state = 'loading') {
  beginAccountRefresh(uid, auth.currentUser?.uid === uid ? auth.currentUser.email || '' : '');
  const appState = accountRefreshState.apps[appKey];
  appState.percent = Math.max(appState.percent || 0, Math.min(100, Math.round(Number(percent) || 0)));
  appState.message = String(message || (state === 'complete' ? 'backup atualizado' : 'carregando'));
  appState.state = state === 'complete' || state === 'error' ? state : 'loading';
  renderAccountSyncProgress();
}

function reportAccountSyncProgress(appKey, uid, percent, message, state = 'loading') {
  if (!['database', 'tier'].includes(appKey) || !uid) return;
  const knownUid = auth.currentUser?.uid || observedHubUid;
  // Hold an early report if an iframe notices the account transition just
  // before the Hub's own Firebase observer. Discard reports from old sessions.
  if (knownUid && knownUid !== uid) {
    if (auth.currentUser?.uid === uid) applyAccountSyncProgress(appKey, uid, percent, message, state);
    else pendingAccountProgress.set(uid, { appKey, percent, message, state });
    return;
  }
  applyAccountSyncProgress(appKey, uid, percent, message, state);
}

function clearAccountSyncProgress() {
  accountRefreshState = null;
  const box = $('accountSyncBox');
  if (box) { box.classList.remove('visible', 'error'); $('accountSyncFill').style.width = '0%'; }
}

function setStatus(message, kind = 'info') {
  const el = $('hubStatus');
  if (!el) return;
  el.textContent = String(message || '');
  el.className = `status ${kind}`;
  lastHubStatus = String(message || '');
}
function setAppStatus(appKey, message, kind = 'info') {
  if (appKey === 'tier' && !activeApp) {
    setStatus(message, kind);
    return;
  }
  if (activeApp === appKey) setStatus(message, kind);
}
function setConfirmProgress(percent, message) {
  const n = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
  $('progressBox').classList.add('visible');
  $('progressMessage').textContent = message || 'Sincronizando…';
  $('progressPercent').textContent = `${n}%`;
  $('progressFill').style.width = `${n}%`;
}
function hideProgress() { $('progressBox').classList.remove('visible'); $('progressFill').style.width = '0%'; }
function setBusy(value) {
  operationBusy = !!value;
  for (const id of ['exportBackupBtn','importBackupBtn','confirmStateBtn','restartBtn','accountControl','installHubBtn']) {
    const disabledByState = id === 'accountControl' ? !authReady : id === 'installHubBtn' ? installedAsApp : false;
    $(id).disabled = operationBusy || disabledByState;
  }
}
function setAccount(user) {
  currentUser = user || null;
  const avatar = $('accountAvatar');
  avatar.replaceChildren();
  if (user) {
    if (user.photoURL) {
      const img = document.createElement('img');
      img.src = user.photoURL;
      img.alt = '';
      img.referrerPolicy = 'no-referrer';
      img.onerror = () => { avatar.textContent = (user.displayName || user.email || 'G').slice(0,1).toUpperCase(); };
      avatar.append(img);
    } else avatar.textContent = (user.displayName || user.email || 'G').slice(0,1).toUpperCase();
    $('accountName').textContent = user.displayName || 'Conta Google conectada';
    $('accountEmail').textContent = user.email || 'Conta Google';
    $('accountHint').textContent = 'TROCAR CONTA';
  } else {
    avatar.textContent = 'B';
    $('accountName').textContent = 'Conectar conta Google';
    $('accountEmail').textContent = 'Toque aqui para entrar ou selecionar outro Gmail';
    $('accountHint').textContent = 'CONECTAR';
  }
  accountControl.disabled = !authReady || operationBusy;
}
function openApp(key) {
  activeApp = key;
  homeView.hidden = true;
  homeView.style.display = 'none';
  appView.classList.add('active');
  const isDb = key === 'database';
  databaseFrame.classList.toggle('active', isDb);
  tierFrame.classList.toggle('active', !isDb);
  document.title = `${isDb ? 'BuzzDataBase' : 'BuzzTier'} · BuzzHub`;
  history.pushState({ buzzApp: key }, '', `#${key}`);
}
function goHome(fromPopState = false) {
  activeApp = null;
  appView.classList.remove('active');
  databaseFrame.classList.remove('active');
  tierFrame.classList.remove('active');
  homeView.hidden = false;
  homeView.style.display = 'flex';
  document.title = 'BuzzHub — Central de aplicativos';
  if (!fromPopState && location.hash) history.replaceState({}, '', location.pathname + location.search);
}
window.addEventListener('popstate', event => {
  if (activeApp) goHome(true);
});
document.querySelectorAll('[data-open-app]').forEach(button => button.addEventListener('click', () => openApp(button.dataset.openApp)));

function explainLoginError(error) {
  const code = String(error?.code || '');
  if (code.includes('unauthorized-domain')) return 'O domínio do BuzzDataBase precisa estar autorizado no Firebase Authentication.';
  if (code.includes('popup-blocked')) return 'O navegador bloqueou a janela de login. Permita pop-ups para este site e tente novamente.';
  if (code.includes('popup-closed-by-user')) return 'A janela de login foi fechada antes de concluir.';
  if (code.includes('operation-not-allowed')) return 'Ative o provedor Google em Firebase Authentication.';
  if (code.includes('network-request-failed')) return 'Sem conexão com o Firebase. Tente novamente quando estiver online.';
  return error?.message || 'Não foi possível conectar à conta Google.';
}
accountControl.addEventListener('click', () => {
  if (!authReady || operationBusy) return;
  provider.setCustomParameters({ prompt: 'select_account' });
  setStatus(currentUser ? 'Abrindo o seletor de contas Google…' : 'Abrindo o login Google…');
  // Call the popup immediately from the user's click so mobile browsers do not block it.
  signInWithPopup(auth, provider)
    .then(credential => {
      const user = credential.user;
      setStatus(`Conta conectada: ${user.email || 'Google'}. Atualizando os aplicativos…`, 'success');
      // Reload even when the user selected the same Gmail again after Reiniciar.
      forceAccountPageReload(user, 'google-popup-success');
    })
    .catch(error => { console.error('BuzzHub Google login:', error); setStatus(explainLoginError(error), 'error'); });
});

function waitForBridge(frame, name, timeoutMs = 20000) {
  return new Promise((resolve, reject) => {
    const started = Date.now();
    const check = async () => {
      try {
        const bridge = frame.contentWindow?.[name];
        if (bridge) {
          if (typeof bridge.ready === 'function') await bridge.ready();
          resolve(bridge);
          return;
        }
      } catch (error) { reject(error); return; }
      if (Date.now() - started > timeoutMs) { reject(new Error(`O ${name === 'BuzzApp' ? 'BuzzDataBase' : 'BuzzTier'} ainda não terminou de carregar.`)); return; }
      setTimeout(check, 100);
    };
    check();
  });
}
async function getBridges() {
  const [db, tier] = await Promise.all([waitForBridge(databaseFrame, 'BuzzApp'), waitForBridge(tierFrame, 'BuzzTierBridge')]);
  return { db, tier };
}
function downloadJson(payload, filename) {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url; link.download = filename;
  document.body.append(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function safeFileBase(value) {
  return String(value || 'BuzzHub').split('@')[0].normalize('NFKC').replace(/[<>:"/\\|?*\u0000-\u001F]/g, '').replace(/\s+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'BuzzHub';
}

$('exportBackupBtn').addEventListener('click', async () => {
  if (operationBusy) return;
  setBusy(true); setStatus('Preparando backup completo dos dois aplicativos…');
  try {
    const { db, tier } = await getBridges();
    const payload = {
      app: 'BuzzHub', schemaVersion: 2, hubVersion: '1.9', exportedAt: new Date().toISOString(),
      account: currentUser ? { email: currentUser.email || '', displayName: currentUser.displayName || '' } : null,
      apps: { buzzdatabase: db.getBackupState(), buzztier: tier.getBackupState() }
    };
    downloadJson(payload, `${safeFileBase(currentUser?.email || 'BuzzHub')}-BuzzHub-backup.json`);
    setStatus('Backup completo dos aplicativos exportado.', 'success');
  } catch (error) { console.error(error); setStatus(error.message || 'Não foi possível exportar o backup.', 'error'); }
  finally { setBusy(false); }
});

$('importBackupBtn').addEventListener('click', () => { if (!operationBusy) $('backupFile').click(); });
let pendingRestore = null;
function setRestoreOption(id, enabled, checked, summary) {
  const option=$(id+'Option'),checkbox=$(id+'Check');option.classList.toggle('disabled',!enabled);checkbox.disabled=!enabled;checkbox.checked=!!checked;$(id+'Summary').textContent=summary||'Não encontrado neste arquivo.';
}
function closeRestoreDialog(){const dialog=$('restoreDialog');if(dialog.open)dialog.close();pendingRestore=null;}
$('cancelRestoreBtn').addEventListener('click',closeRestoreDialog);
$('applyRestoreBtn').addEventListener('click',async()=>{
  if(!pendingRestore||operationBusy)return;
  const restoreDb=$('restoreDbCheck').checked&&pendingRestore.hasDb;
  const restoreTier=$('restoreTierCheck').checked&&pendingRestore.hasTier;
  if(!restoreDb&&!restoreTier){setStatus('Marque pelo menos um aplicativo para restaurar.','warning');return;}
  const operation=pendingRestore;closeRestoreDialog();setBusy(true);const parts=[];
  try{
    if(restoreDb){setStatus('Restaurando somente o BuzzDataBase no aparelho…');const result=await operation.db.importBackupState(operation.apps.buzzdatabase);parts.push(`${result.items} obras do BuzzDataBase`);}
    if(restoreTier){setStatus('Restaurando somente o BuzzTier no aparelho…');const result=await operation.tier.importBackupState(operation.apps.buzztier);parts.push(`${result.lists} listas do BuzzTier`);}
    setStatus(`Backup importado localmente: ${parts.join(' e ')}. A nuvem não foi alterada. Use “Confirmar Estado” quando quiser publicar a versão restaurada.`, 'success');
  }catch(error){console.error('BuzzHub restore:',error);setStatus(error.message||'Não foi possível restaurar o backup. Os dados anteriores do aplicativo com falha foram preservados.','error');}
  finally{setBusy(false);}
});
$('backupFile').addEventListener('change',async event=>{
  const file=event.target.files?.[0];if(!file||operationBusy)return;setBusy(true);setStatus('Lendo e verificando o arquivo de backup…');
  try{
    if(file.size>120*1024*1024)throw new Error('O arquivo ultrapassa 120 MB. Divida o backup antes de importar.');
    const raw=JSON.parse(await file.text());let apps=raw?.app==='BuzzHub'&&raw.apps&&typeof raw.apps==='object'?raw.apps:null;
    if(!apps){apps={};if(raw?.app==='BuzzDataBase'&&Array.isArray(raw.items))apps.buzzdatabase=raw;else if(raw?.app==='BuzzTier'&&Array.isArray(raw.lists))apps.buzztier=raw;else if(Array.isArray(raw?.lists))apps.buzztier=raw;}
    const hasDb=!!apps?.buzzdatabase&&Array.isArray(apps.buzzdatabase.items),hasTier=!!apps?.buzztier&&Array.isArray(apps.buzztier.lists);
    if(!hasDb&&!hasTier)throw new Error('Esse arquivo não contém dados válidos do BuzzDataBase ou do BuzzTier.');
    const {db,tier}=await getBridges();
    const dbReport=hasDb?db.validateBackupState(apps.buzzdatabase):null,tierReport=hasTier?tier.validateBackupState(apps.buzztier):null;
    pendingRestore={apps,db,tier,hasDb,hasTier};
    // A combined backup may predate recent catalogs. Default to restoring
    // BuzzTier alone; the user must deliberately opt into replacing BuzzDataBase.
    setRestoreOption('restoreDb',hasDb,hasDb&&!hasTier,hasDb?`${dbReport.items} obras · ${dbReport.sections} tópicos (marque somente se quiser substituir)`:'Não encontrado neste arquivo.');
    setRestoreOption('restoreTier',hasTier,hasTier,hasTier?`${tierReport.lists} listas · ${tierReport.images} imagens`:'Não encontrado neste arquivo.');
    $('restoreDialog').showModal();setStatus('Backup verificado. Escolha quais aplicativos deseja restaurar; os demais não serão modificados.','info');
  }catch(error){console.error('BuzzHub backup validation:',error);setStatus(error.message||'Arquivo de backup inválido.','error');}
  finally{event.target.value='';setBusy(false);}
});

async function waitForChildAccount(uid, timeoutMs = 25000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    const dbUser = databaseFrame.contentWindow?.BuzzFirebase?.getCurrentUser?.() || null;
    const tierUser = tierFrame.contentWindow?.BuzzTierCloud?.getCurrentUser?.() || null;
    const sync = accountRefreshState;
    const refreshSettled = sync?.uid === uid && ['database', 'tier'].every(key =>
      ['complete', 'error'].includes(sync.apps?.[key]?.state)
    );
    if (dbUser?.uid === uid && tierUser?.uid === uid && refreshSettled) return { dbUser, tierUser };
    if ((dbUser?.uid && dbUser.uid !== uid) || (tierUser?.uid && tierUser.uid !== uid)) {
      throw new Error('Um dos aplicativos ainda está conectado a outra conta Google. Aguarde a atualização da conta e tente novamente.');
    }
    await new Promise(resolve => setTimeout(resolve, 150));
  }
  throw new Error('Os dois aplicativos ainda não terminaram de conectar o Gmail atual. Aguarde a sincronização inicial e tente novamente.');
}

$('confirmStateBtn').addEventListener('click', async () => {
  if (operationBusy) return;
  if (!currentUser) { setStatus('Conecte sua conta Google antes de confirmar o estado dos aplicativos.', 'warning'); accountControl.focus(); return; }
  setBusy(true); setConfirmProgress(0, 'Preparando o estado atual deste aparelho…');
  try {
    const { db, tier } = await getBridges();
    await waitForChildAccount(currentUser.uid);
    const dbState = db.getBackupState();
    const tierState = tier.getBackupState();
    const dbLocal = db.getLocalCloudState?.() || {};
    const tierStatus = tier.getStatus?.() || {};
    if (dbLocal.cloudOwnerUid && dbLocal.cloudOwnerUid !== currentUser.uid) {
      throw new Error('O catálogo aberto no BuzzDataBase pertence a outro Gmail. Não enviei nenhum dado.');
    }
    if (tierStatus.ownerUid && tierStatus.ownerUid !== currentUser.uid) {
      throw new Error('As listas abertas no BuzzTier pertencem a outro Gmail. Não enviei nenhum dado.');
    }
    const dbCount = Array.isArray(dbState?.items) ? dbState.items.length : 0;
    const tierCount = Array.isArray(tierState?.lists) ? tierState.lists.length : 0;
    const dbUnassigned = !dbLocal.cloudOwnerUid && dbCount > 0;
    const tierUnassigned = !tierStatus.ownerUid && tierCount > 0;
    const unassignedNote = (dbUnassigned || tierUnassigned)
      ? '\n\nAtenção: pelo menos um conteúdo local ainda não está identificado com um Gmail. Ao continuar, ele será associado à conta exibida acima.'
      : '';
    const accepted = confirm(
      `Salvar o estado atual deste aparelho na nuvem?\n\n` +
      `Conta: ${currentUser.email || 'Google'}\n` +
      `BuzzDataBase: ${dbCount} obras/capas\n` +
      `BuzzTier: ${tierCount} listas/tiers\n\n` +
      `Isso substituirá as cópias desta conta no Firestore pelo conteúdo atual do aparelho. Se um dos aplicativos estiver vazio, o backup correspondente desta conta também ficará vazio. Os dados de outros Gmail não serão alterados.` +
      unassignedNote +
      `\n\nDeseja continuar?`
    );
    if (!accepted) { setStatus('Confirmação cancelada. A nuvem não foi alterada.', 'info'); hideProgress(); return; }

    const failures = [];
    setConfirmProgress(3, 'Salvando obras e capas do BuzzDataBase…');
    try {
      const dbOk = await db.confirmState({ forceCurrentState: true, allowUnassignedLocalState: true });
      if (!dbOk) throw new Error('O BuzzDataBase não confirmou a gravação.');
    } catch (error) { failures.push(`BuzzDataBase: ${error.message || 'falha ao salvar'}`); }

    setConfirmProgress(54, 'Salvando listas, tiers e imagens do BuzzTier…');
    try {
      const tierOk = await tier.confirmState({ forceCurrentState: true, allowUnassignedLocalState: true });
      if (!tierOk) throw new Error('O BuzzTier não confirmou a gravação.');
    } catch (error) { failures.push(`BuzzTier: ${error.message || 'falha ao salvar'}`); }

    if (failures.length) throw new Error(`A confirmação foi parcial. ${failures.join(' · ')}. O conteúdo local continua preservado; tente novamente depois de corrigir o erro.`);
    setConfirmProgress(100, 'Estado atual dos dois aplicativos salvo e verificado na nuvem.');
    setStatus(`Estado confirmado para ${currentUser.email || 'esta conta'}: ${dbCount} obras/capas e ${tierCount} listas/tiers. 💜`, 'success');
    setTimeout(hideProgress, 6500);
  } catch (error) { console.error(error); setStatus(error.message || 'Não foi possível confirmar o estado dos aplicativos.', 'error'); }
  finally { setBusy(false); }
});

$('restartBtn').addEventListener('click', async () => {
  if (operationBusy) return;
  const accepted = confirm('Reiniciar o BuzzHub neste aparelho?\n\nIsso vai desconectar a conta Google e limpar os dados locais do BuzzDataBase e do BuzzTier.\n\nAs coleções e imagens já salvas no Firestore NÃO serão apagadas. Ao entrar novamente com o mesmo Gmail, os aplicativos poderão carregar as cópias da nuvem.\n\nExporte um backup antes, por segurança.');
  if (!accepted) return;
  setBusy(true); setStatus('Desconectando a conta e limpando somente os dados locais…');
  try {
    const { db, tier } = await getBridges();
    await db.resetForHub();
    await tier.resetLocalData();
    if (auth.currentUser) await signOut(auth);
    setAccount(null);
    setStatus('Aparelho reiniciado. As duas cópias na nuvem foram preservadas. Entre novamente com o Gmail para recuperá-las.', 'success');
  } catch (error) { console.error(error); setStatus(error.message || 'Não foi possível reiniciar com segurança. Os dados locais que não foram limpos continuam preservados.', 'error'); }
  finally { setBusy(false); }
});

window.addEventListener('message', event => {
  if (event.origin !== location.origin || event.source !== databaseFrame.contentWindow) return;
  if (event.data?.type === 'BUZZ_DB_PROGRESS') setConfirmProgress(event.data.percent, event.data.message);
});

window.BuzzHub = { setAppStatus, setConfirmProgress, setStatus, reportAccountSyncProgress };

function renderInstallButton() {
  const button = $('installHubBtn');
  if (!button) return;
  if (installedAsApp) {
    button.disabled = true;
    button.innerHTML = '<span class="install-hub-icon">✓</span><span>App instalado</span>';
    button.setAttribute('aria-label', 'BuzzHub já está instalado');
  } else {
    button.disabled = operationBusy;
    button.innerHTML = '<span class="install-hub-icon">⇩</span><span>Baixar App</span>';
    button.setAttribute('aria-label', 'Instalar BuzzHub como aplicativo');
  }
}

window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault();
  deferredInstallPrompt = event;
  renderInstallButton();
});

window.addEventListener('appinstalled', () => {
  installedAsApp = true;
  deferredInstallPrompt = null;
  renderInstallButton();
  setStatus('BuzzHub instalado com sucesso neste aparelho.', 'success');
});

$('installHubBtn')?.addEventListener('click', async () => {
  if (installedAsApp) return;
  if (deferredInstallPrompt) {
    const installPrompt = deferredInstallPrompt;
    deferredInstallPrompt = null;
    try {
      await installPrompt.prompt();
      const choice = await installPrompt.userChoice;
      if (choice?.outcome === 'accepted') {
        setStatus('Instalação do BuzzHub iniciada.', 'success');
      } else {
        setStatus('Instalação cancelada. Você pode instalar depois pelo navegador.', 'info');
      }
    } catch (error) {
      console.warn('BuzzHub: prompt de instalação indisponível.', error);
      showInstallInstructions();
    }
    return;
  }
  showInstallInstructions();
});

function showInstallInstructions() {
  const isAppleMobile = /iPhone|iPad|iPod/i.test(navigator.userAgent) && !window.MSStream;
  const instructions = isAppleMobile
    ? 'Para instalar no iPhone/iPad: abra o BuzzHub no Safari, toque em Compartilhar e escolha “Adicionar à Tela de Início”.'
    : 'Para instalar: abra o menu do navegador (⋮ ou ⋯) e escolha “Instalar app” ou “Adicionar à tela inicial”.';
  setStatus(instructions, 'warning');
}

renderInstallButton();

const persistenceReady = setPersistence(auth, browserLocalPersistence).then(() => {
  authReady = true;
  accountControl.disabled = false;
}).catch(error => {
  console.warn('BuzzHub: persistência local do login não pôde ser ajustada.', error);
  authReady = true;
  accountControl.disabled = false;
});
onAuthStateChanged(auth, user => {
  const nextUid = user?.uid || null;
  const previousUid = observedHubUid;
  const hadInitialAuthState = authInitialStateSeen;
  const accountChanged = nextUid !== previousUid;
  const isPostReload = !!(nextUid && consumeAccountReloadMarker(nextUid));
  observedHubUid = nextUid;
  authInitialStateSeen = true;
  setAccount(user);
  if (user) {
    if (accountChanged) beginAccountRefresh(user.uid, user.email || user.displayName || 'Google');
    const pending = pendingAccountProgress.get(user.uid);
    if (pending) {
      pendingAccountProgress.delete(user.uid);
      applyAccountSyncProgress(pending.appKey, user.uid, pending.percent, pending.message, pending.state);
    }
    for (const uid of pendingAccountProgress.keys()) if (uid !== user.uid) pendingAccountProgress.delete(uid);
    setStatus(`Conectado como ${user.email || user.displayName || 'Google'}. Atualizando os backups dos dois aplicativos…`, 'success');
    // Covers account changes initiated outside this page's Google popup too.
    // Initial page startup is intentionally excluded; only subsequent changes reload.
    if (hadInitialAuthState && accountChanged && !isPostReload) {
      forceAccountPageReload(user, 'firebase-auth-state-change');
    }
  } else {
    pendingAccountProgress.clear();
    clearAccountSyncProgress();
    if (authReady) setStatus('Sem conta conectada. Toque no perfil para entrar com Google.');
  }
});
persistenceReady.catch(() => {});

// Both apps stay loaded in their own isolated frames so the same-origin Google
// session can be observed by each Firebase Auth instance.
window.addEventListener('load', () => {
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    navigator.serviceWorker.register('./sw.js', { updateViaCache: 'none' })
      .then(registration => registration.update().catch(() => {}))
      .catch(error => console.warn('BuzzHub: service worker indisponível.', error));
  }
});
