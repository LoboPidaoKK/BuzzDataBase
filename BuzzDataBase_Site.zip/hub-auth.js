/* BuzzHub 2.0 — edição exclusivamente local, sem contas ou sincronização remota. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const homeView = $('homeView');
  const appView = $('appView');
  const databaseFrame = $('databaseFrame');
  const tierFrame = $('tierFrame');
  let activeApp = null;
  let operationBusy = false;
  let pendingRestore = null;
  let deferredInstallPrompt = null;
  let installedAsApp = window.matchMedia?.('(display-mode: standalone)').matches || navigator.standalone === true;

  function setStatus(message, kind = 'info') {
    const el = $('hubStatus');
    if (!el) return;
    el.textContent = String(message || '');
    el.className = `status ${kind}`;
  }
  function setAppStatus(appKey, message, kind = 'info') {
    if (activeApp === appKey || !activeApp) setStatus(message, kind);
  }
  function setBusy(value) {
    operationBusy = !!value;
    for (const id of ['exportBackupBtn', 'importBackupBtn']) {
      const button = $(id);
      if (button) button.disabled = operationBusy;
    }
    renderInstallButton();
  }
  function openApp(key) {
    activeApp = key;
    homeView.hidden = true;
    homeView.style.display = 'none';
    appView.classList.add('active');
    const isDb = key === 'database';
    databaseFrame.classList.toggle('active', isDb);
    tierFrame.classList.toggle('active', !isDb);
    document.title = `${isDb ? 'BuzzDataBase' : 'BuzzTier'} · BuzzHub 2.0`;
    history.pushState({ buzzApp: key }, '', `#${key}`);
  }
  function goHome(fromPopState = false) {
    activeApp = null;
    appView.classList.remove('active');
    databaseFrame.classList.remove('active');
    tierFrame.classList.remove('active');
    homeView.hidden = false;
    homeView.style.display = 'flex';
    document.title = 'BuzzHub 2.0 — Central de aplicativos';
    if (!fromPopState && location.hash) history.replaceState({}, '', location.pathname + location.search);
  }
  document.querySelectorAll('[data-open-app]').forEach(button => {
    button.addEventListener('click', () => openApp(button.dataset.openApp));
  });
  window.addEventListener('popstate', event => {
    if (event.state?.buzzApp) openApp(event.state.buzzApp);
    else goHome(true);
  });
  window.addEventListener('keydown', event => {
    if (event.key === 'Escape' && activeApp) goHome();
  });

  async function waitForBridge(frame, bridgeName, timeoutMs = 30000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      try {
        const bridge = frame.contentWindow?.[bridgeName];
        if (bridge && typeof bridge.getBackupState === 'function') {
          if (typeof bridge.ready === 'function') await bridge.ready();
          if (typeof bridge.getBackupState === 'function') return bridge;
        }
      } catch (_) { /* iframe ainda inicializando */ }
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    throw new Error(`O ${bridgeName === 'BuzzApp' ? 'BuzzDataBase' : 'BuzzTier'} não terminou de carregar. Reabra o aplicativo e tente novamente.`);
  }
  async function getBridges() {
    const [db, tier] = await Promise.all([
      waitForBridge(databaseFrame, 'BuzzApp'),
      waitForBridge(tierFrame, 'BuzzTierBridge')
    ]);
    return { db, tier };
  }
  function downloadJson(payload, filename) {
    const json = JSON.stringify(payload, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
  $('exportBackupBtn').addEventListener('click', async () => {
    if (operationBusy) return;
    setBusy(true);
    setStatus('Preparando backup local do BuzzDataBase e do BuzzTier…');
    try {
      const { db, tier } = await getBridges();
      const payload = {
        app: 'BuzzHub', schemaVersion: 3, hubVersion: '2.0',
        exportedAt: new Date().toISOString(),
        storage: 'local-only',
        apps: { buzzdatabase: db.getBackupState(), buzztier: tier.getBackupState() }
      };
      downloadJson(payload, `BuzzHub-2.0-backup-${new Date().toISOString().slice(0, 10)}.json`);
      setStatus('Backup completo exportado. Guarde o arquivo em um local seguro.', 'success');
    } catch (error) {
      console.error('BuzzHub export:', error);
      setStatus(error.message || 'Não foi possível exportar o backup.', 'error');
    } finally { setBusy(false); }
  });
  $('importBackupBtn').addEventListener('click', () => { if (!operationBusy) $('backupFile').click(); });

  function setRestoreOption(id, enabled, checked, summary) {
    const option = $(id + 'Option');
    const checkbox = $(id + 'Check');
    option.classList.toggle('disabled', !enabled);
    checkbox.disabled = !enabled;
    checkbox.checked = !!checked;
    $(id + 'Summary').textContent = summary || 'Não encontrado neste arquivo.';
  }
  function closeRestoreDialog() {
    const dialog = $('restoreDialog');
    if (dialog.open) dialog.close();
    pendingRestore = null;
  }
  $('cancelRestoreBtn').addEventListener('click', closeRestoreDialog);
  $('applyRestoreBtn').addEventListener('click', async () => {
    if (!pendingRestore || operationBusy) return;
    const restoreDb = $('restoreDbCheck').checked && pendingRestore.hasDb;
    const restoreTier = $('restoreTierCheck').checked && pendingRestore.hasTier;
    if (!restoreDb && !restoreTier) {
      setStatus('Marque pelo menos um aplicativo para restaurar.', 'warning');
      return;
    }
    const operation = pendingRestore;
    closeRestoreDialog();
    setBusy(true);
    const parts = [];
    try {
      if (restoreDb) {
        setStatus('Restaurando o BuzzDataBase neste aparelho…');
        const result = await operation.db.importBackupState(operation.apps.buzzdatabase);
        parts.push(`${result.items} obras do BuzzDataBase`);
      }
      if (restoreTier) {
        setStatus('Restaurando o BuzzTier neste aparelho…');
        const result = await operation.tier.importBackupState(operation.apps.buzztier);
        parts.push(`${result.lists} listas do BuzzTier`);
      }
      setStatus(`Backup restaurado localmente: ${parts.join(' e ')}. Nenhuma conta ou nuvem foi acessada.`, 'success');
    } catch (error) {
      console.error('BuzzHub restore:', error);
      setStatus(error.message || 'Não foi possível restaurar o backup. Os dados anteriores do aplicativo com falha foram preservados.', 'error');
    } finally { setBusy(false); }
  });
  $('backupFile').addEventListener('change', async event => {
    const file = event.target.files?.[0];
    if (!file || operationBusy) return;
    setBusy(true);
    setStatus('Lendo e verificando o arquivo de backup…');
    try {
      const raw = JSON.parse(await file.text());
      let apps = raw?.app === 'BuzzHub' && raw.apps && typeof raw.apps === 'object' ? raw.apps : null;
      if (!apps) {
        apps = {};
        if (raw?.app === 'BuzzDataBase' && Array.isArray(raw.items)) apps.buzzdatabase = raw;
        else if (raw?.app === 'BuzzTier' && Array.isArray(raw.lists)) apps.buzztier = raw;
        else if (Array.isArray(raw?.lists)) apps.buzztier = raw;
      }
      const hasDb = !!apps?.buzzdatabase && Array.isArray(apps.buzzdatabase.items);
      const hasTier = !!apps?.buzztier && Array.isArray(apps.buzztier.lists);
      if (!hasDb && !hasTier) throw new Error('Esse arquivo não contém dados válidos do BuzzDataBase ou do BuzzTier.');
      const { db, tier } = await getBridges();
      const dbReport = hasDb ? db.validateBackupState(apps.buzzdatabase) : null;
      const tierReport = hasTier ? tier.validateBackupState(apps.buzztier) : null;
      pendingRestore = { apps, db, tier, hasDb, hasTier };
      setRestoreOption('restoreDb', hasDb, hasDb && !hasTier, hasDb ? `${dbReport.items} obras · ${dbReport.sections} tópicos (marque para substituir)` : 'Não encontrado neste arquivo.');
      setRestoreOption('restoreTier', hasTier, hasTier, hasTier ? `${tierReport.lists} listas · ${tierReport.images} imagens` : 'Não encontrado neste arquivo.');
      $('restoreDialog').showModal();
      setStatus('Backup verificado. Escolha o que deseja restaurar.', 'success');
    } catch (error) {
      console.error('BuzzHub import:', error);
      setStatus(error.message || 'Arquivo de backup inválido.', 'error');
    } finally {
      event.target.value = '';
      setBusy(false);
    }
  });

  function renderInstallButton() {
    const button = $('installHubBtn');
    if (!button) return;
    if (installedAsApp) {
      button.disabled = true;
      button.innerHTML = '<span class="install-hub-icon">✓</span><span>App instalado</span>';
      button.setAttribute('aria-label', 'BuzzHub já está instalado');
    } else {
      button.disabled = operationBusy;
      button.innerHTML = '<span class="install-hub-icon">⇩</span><span>Baixar App</span>';
      button.setAttribute('aria-label', 'Instalar BuzzHub como aplicativo');
    }
  }
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault(); deferredInstallPrompt = event; renderInstallButton();
  });
  window.addEventListener('appinstalled', () => {
    installedAsApp = true; deferredInstallPrompt = null; renderInstallButton();
    setStatus('BuzzHub instalado com sucesso neste aparelho.', 'success');
  });
  $('installHubBtn')?.addEventListener('click', async () => {
    if (installedAsApp) return;
    if (deferredInstallPrompt) {
      const promptEvent = deferredInstallPrompt; deferredInstallPrompt = null;
      try {
        await promptEvent.prompt();
        const choice = await promptEvent.userChoice;
        setStatus(choice?.outcome === 'accepted' ? 'Instalação do BuzzHub iniciada.' : 'Instalação cancelada. Você pode instalar depois pelo navegador.', choice?.outcome === 'accepted' ? 'success' : 'info');
      } catch (error) { console.warn('BuzzHub: prompt de instalação indisponível.', error); showInstallInstructions(); }
      return;
    }
    showInstallInstructions();
  });
  function showInstallInstructions() {
    const isAppleMobile = /iPhone|iPad|iPod/i.test(navigator.userAgent) && !window.MSStream;
    setStatus(isAppleMobile
      ? 'Para instalar no iPhone/iPad: abra no Safari, toque em Compartilhar e escolha “Adicionar à Tela de Início”.'
      : 'Para instalar: abra o menu do navegador (⋮ ou ⋯) e escolha “Instalar app” ou “Adicionar à tela inicial”.', 'warning');
  }
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    navigator.serviceWorker.register('./sw.js', { updateViaCache: 'none' })
      .then(registration => registration.update().catch(error => console.warn('BuzzHub: verificação de atualização falhou.', error)))
      .catch(error => console.warn('BuzzHub: Service Worker indisponível.', error));
  }
  window.BuzzHub = { setAppStatus, setStatus };
  renderInstallButton();
})();
