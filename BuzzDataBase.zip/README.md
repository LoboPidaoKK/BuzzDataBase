BuzzHub 2.7 — Tema colorido

Projeto estático para GitHub Pages. Inclui BuzzDataBase, BuzzTier e BuzzLinks.
A aparência é compartilhada localmente entre o Hub e os aplicativos, com três estilos: Escuro com detalhes, Cor em todo o site e Preto total.
