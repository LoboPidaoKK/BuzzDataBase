# BuzzDataBase v2.1

## Novidades

- Avaliação por estrelas de 1 a 10. A nota aparece nos cartões; use o ícone de edição para atribuir ou alterar a nota. "Sem nota" remove a avaliação.
- Duas novas ordenações: **Recente → mais antigo** e **Antigo → mais recente**. A data de inclusão é preservada ao editar o título, tópico ou capa.
- A exportação de backup inclui a nota e a data de inclusão. Backups JSON antigos continuam sendo aceitos; se não tiverem datas, a ordem antiga dos IDs é usada como aproximação cronológica.
- IndexedDB mantém metadados e capas em stores separados.
- Cache do PWA atualizado para v2.1.

## Publicação pelo ZIP (configuração única)

O GitHub Pages não descompacta um ZIP automaticamente. Este pacote inclui um workflow do GitHub Actions para permitir que, depois da configuração inicial, cada nova versão seja publicada enviando somente um ZIP versionado.

1. No repositório, abra **Settings → Pages → Build and deployment → Source** e selecione **GitHub Actions**.
2. Extraia este pacote e envie o conteúdo extraído para a raiz do repositório `BuzzDataBase`. Os arquivos do site ficam diretamente na raiz; a única pasta adicional é `.github/workflows`. O pacote inclui `BuzzDataBase_V2.1_Site.zip`.
3. Faça o commit e aguarde a execução do workflow **Publish BuzzDataBase ZIP to Pages**, que extrai e publica o pacote do site.
4. Nas próximas versões, basta enviar um ZIP com nome de versão novo, como `BuzzDataBase_V2.2_Site.zip`, para a raiz do repositório e fazer commit. O workflow escolhe a versão mais alta e publica o conteúdo sem você precisar extrair ou separar os arquivos do site.

Se não quiser configurar Actions, use o ZIP do site normalmente: extraia-o e envie os arquivos que estão na raiz do arquivo ZIP para a raiz do repositório, mantendo a estrutura plana.

## Dados e backup

- A coleção fica no armazenamento local de cada navegador/dispositivo, não no GitHub.
- Exportar backup regularmente. A importação substitui a coleção daquele navegador.
- Atualizar o código do site não sincroniza automaticamente os dados entre celulares.
- Não apague o backup original até confirmar que a restauração funciona.
